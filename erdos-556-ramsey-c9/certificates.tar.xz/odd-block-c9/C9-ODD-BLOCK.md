# Cycles impairs courts dans le grand bloc

On suppose qu’un graphe à 33 sommets sans cycle de longueur 9 a au
moins 176 arêtes et un nombre d’indépendance au plus 13. La
[réduction précédente](../mono-extremal/C9-MONO-EXTREMAL.md) fournit
un plus grand bloc 2-connexe non biparti $B$, d’ordre $b\in[25,33]$,
sans $K_{12,11}$, dont la maille impaire (longueur du plus court
cycle impair) appartient à $\{3,5,7\}$. L’indépendance de tout
sous-graphe induit de $B$ vaut au plus 13. En contractant $B$,
les autres blocs apportent au plus $f(34-b)$ arêtes, où
$f(n)=\operatorname{ex}(n,C_9)$. On pose $m=176-f(34-b)$.
[Théorème 1 de Füredi et Gunderson](https://arxiv.org/pdf/1310.6766#page=3).

La maille impaire 7 est exclue partout. La maille impaire 5 est
exclue aux ordres 25 à 28. Il reste les blocs contenant un triangle,
et les blocs de maille impaire 5 aux ordres 29 à 33.

| $b$ | $m$ | Cœur non vide | Circonférence minimale | Maille 7, borne si $H$ non biparti | Maille 7, borne si $H$ biparti |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 25 | 147 | 10 | 16 | 91 | 106 |
| 26 | 148 | 9 | 16 | 100 | 116 |
| 27 | 155 | 9 | 16 | 109 | 127 |
| 28 | 161 | 9 | 16 | 119 | 138 |
| 29 | 166 | 8 | 16 | 129 | 150 |
| 30 | 170 | 8 | 16 | 140 | 162 |
| 31 | 173 | 8 | 16 | 151 | 151 |
| 32 | 175 | 8 | 15 | 163 | 158 |
| 33 | 176 | 7 | 14 | 175 | 166 |

## Exclusion complète de la maille impaire 7

Fixons un plus court cycle impair $C$ de longueur 7. Il est sans
corde, car une corde donnerait un cycle impair plus court. On pose
$H=B-V(C)$, $h=b-7$. Un sommet de $H$ qui a deux voisins
sur $C$ doit les voir à distance circulaire 2. En effet, l’arc
impair entre ces voisins doit avoir au moins cinq arêtes. Aucun
triplet du cycle n’est deux à deux à distance 2, donc un sommet
a au plus deux voisins sur $C$. Soient $D,S,Z$ les classes des
sommets de $H$ ayant respectivement deux, un et zéro voisins
sur $C$. Notons $d,s,z$ leurs tailles.

Un chemin simple dans $H$ dont les deux extrémités voient $C$
se ferme avec deux arêtes d’attachement et un arc de $C$. Si
le chemin est une arête, seuls des labels à distance 3 sont
compatibles. Les distances 0, 1 et 2 produisent respectivement
un $C_3$, un $C_9$ et un $C_5$. Pour un chemin de deux
arêtes, les seuls labels compatibles sont égaux ou à distance 3.
Les distances 1 et 2 produisent respectivement un $C_5$ et un
$C_9$. Pour les deux labels $0,2$ d’un sommet de $D$, les
listes des labels atteignables par un chemin de deux arêtes sont
$\{0,3,4\}$ et $\{2,5,6\}$, qui sont disjointes.
La même incompatibilité vaut pour un chemin d’une arête.
Il n’y a donc aucune arête de $D$ vers $D\cup S$, et tout
sommet de $Z$ touche au plus un sommet de $D$.
Mantel, appliqué à $H-D$, donne
$$
e(B)\le 7+s+2d+z+e(H-D)\le 7+h+d+\lfloor(h-d)^2/4\rfloor. \tag{1}
$$

Si $H$ est non biparti de maille impaire 7, on applique (1) à
$H$ lui-même. Pour $0\le d'\le h-7$, on a
$d'+\lfloor(h-7-d')^2/4\rfloor\le\lfloor(h-7)^2/4\rfloor$
sur les ordres considérés. Si $H$ a une maille impaire $g\ge11$,
on compte les arêtes de son plus court cycle impair, au plus deux
attachements par sommet extérieur, puis les arêtes restantes par
Mantel. La règle des deux attachements découle toujours de l’arc
impair de longueur au moins $g-2$. Le vérificateur calcule le
maximum de $g+2(h-g)+\lfloor(h-g)^2/4\rfloor$ sur les $g$ impairs
de 11 à $h$. Dans les deux cas $e(H)\le h+\lfloor(h-7)^2/4\rfloor$.
La borne qui en résulte $7+2h+e(H)$ est strictement sous $m$
pour les neuf ordres.

Si $H$ est biparti, (1) exclut directement $b\le30$ et impose
$d\le b-31$ ensuite. Chaque partie indépendante a taille au
plus 13. Une partie de taille $a$ doit voir un ensemble
d’étiquettes $\Lambda\subseteq C$ pour lequel
$\alpha(C-\Lambda)\le13-a$. Pour $a=11,12,13$, la taille
minimale $\ell(a)$ de $\Lambda$ vaut $3,5,7$, respectivement.
On le vérifie parmi les 128 sous-ensembles de $C$.

Soient $a_1,a_2$ les tailles des deux parties, $p_1,p_2$
leurs nombres de sommets attachés et $d_1,d_2$ leurs nombres
de doubles attachements. Pour chaque sommet attaché de la
première partie, au plus deux labels de la seconde partie
sont compatibles avec une arête de $H$. Il doit manquer
au moins $\ell(a_2)-2-d_2$ sommets attachés de la seconde
partie. On retranche $d_2$ car deux labels peuvent
correspondre au même sommet. Le nombre $M$ d’arêtes
manquantes entre les parties vérifie donc
$$
 M\ge\max(0,p_1(\ell(a_2)-2-d_2),p_2(\ell(a_1)-2-d_1)).
$$
Le vérificateur maximise $7+a_1a_2-M+p_1+p_2+d$ sous ces
bornes, sous (1) et avec $p_i+d_i\ge\ell(a_i)$. Aucune
des valeurs du tableau n’atteint $m$.

## Maille impaire 5 aux ordres 25 à 28

Le plus court cycle impair $C$ est un pentagone sans corde.
Posons $H=B-V(C)$, $h=b-5$, et gardons $D$ pour les doubles
attachements. Il y a au plus deux voisins sur $C$ par sommet
de $H$ puisque $B$ est sans triangle. À $b=25$, Mantel
donne $e(B)\le5+40+100=145<147$.

Il n’existe aucun chemin simple de longueur 4 dans $H$ entre
deux sommets distincts de $D$. Les deux labels de chaque
extrémité sont distants de 2 sur le pentagone. Avec les labels
$0,2$ à une extrémité, seuls les labels qui ne sont à distance
2 d’aucun des deux peuvent apparaître à l’autre extrémité.
Un arc de longueur 3 fermerait un $C_9$. Il ne reste qu’un
label, ce qui est impossible pour un double attachement.

Dans un sous-graphe induit biparti de $H$, supposons qu’il y
ait $D_0\ge3$ doubles attachements et $M$ arêtes manquantes
entre les parties. Une partie contient au moins
$j=\lceil D_0/2\rceil$ de ces doubles attachements. Les deux
qui ont le moins d’arêtes manquantes dans cette partie
en manquent ensemble au plus $\lfloor2M/j\rfloor$.
Ils ont donc au moins $q-\lfloor2M/j\rfloor$ voisins communs,
où $q$ est la taille de la partie opposée. Si cette borne
est $u\ge2$, toute autre ligne de la même partie doit manquer
au moins $u-1$ de ces voisins communs. Sinon, deux voisins
communs et cette autre ligne relient les deux doubles par un
chemin simple de longueur 4. Il faut donc
$M\ge(a-2)(u-1)$, où $a$ est la taille de la première
partie. Le calcul utilise la plus petite des deux tailles
pour borner $a$ et $q$.

Si $H$ est biparti, on énumère ses tailles de parties au
plus 13, le nombre $d$ de doubles et
$M\le a_1a_2+5+h+d-m$. La borne précédente exclut tous
les cas, sauf deux à $b=28$, avec parties de tailles
12 et 11, un ou deux doubles et au plus une arête manquante.
Au moins 22 des 23 sommets sont alors attachés et il existe
une paire attachée sur une arête entre les parties. Cette
paire est aussi reliée par des chemins de longueurs 3 et 5
dans $H$. En effet, on choisit les sommets internes dans
les deux parties en évitant les extrémités et les sommets
de l’arête manquante. L’arête interdit des labels égaux
sur le pentagone, le chemin de longueur 3 interdit la
distance 1 et celui de longueur 5 interdit la distance 2.
Il ne reste aucune paire de labels compatible.

Si $H$ est non biparti, on le réduit en retirant un plus court
cycle impair à chaque couche non bipartie, jusqu’à obtenir un
reste biparti $J$. Une couche triangle-libre non bipartie
d’ordre $r$ a au plus $\lfloor(r-1)^2/4\rfloor+1$ arêtes.
En effet, pour son plus court cycle impair de longueur $g\ge5$
le comptage donne $g+2(r-g)+\lfloor(r-g)^2/4\rfloor$, décroissant
en $g$ et maximal à 5. Les seuils d’arêtes imposent que chaque
cycle retiré à partir de $H$ est un pentagone. Soit $j$
le nombre de ces pentagones et $S_j$ la somme des coûts
$5+2r'$ de leur retrait, où $r'$ est à chaque étape l’ordre
de la couche après retrait. Alors
$$
e(J)\ge m-5-2h-S_j,\qquad
|D\cap V(J)|\ge m-5-h-S_j-e(J)-5j .
$$
Les bornes non biparties forcent un reste biparti au plus tard
à $j=1,1,2$, respectivement à $b=26,27,28$. Pour chaque
reste biparti possible, le vérificateur énumère les tailles
de parties et le nombre d’arêtes compatibles avec ces deux
inégalités. La contrainte de chemin de longueur 4 exclut
chacun des cas.

## Cœurs et circonférence

Si $B$ est $d$-dégénéré, on retire des sommets de degré
au plus $d$ jusqu’à ce qu’il en reste $s$. Il en résulte
$e(B)\le d(b-s)+f(s)$ pour chaque $1\le s\le b$.
Par exemple, $d=6,s=9$ donne $6b-25$, inférieur à $m$
aux neuf ordres. Le minimum calculé sur $s$ donne les
cœurs du tableau, sauf le cas d’égalité $b=32,d=7$.

Dans ce cas l’ordre inverse de la suppression part d’un
graphe à 14 sommets et 49 arêtes. Chaque nouveau sommet
a exactement sept voisins antérieurs. Les deux graphes
extrémaux possibles sont $K_{7,7}$ et deux cliques
$K_8,K_7$ recollées en un sommet. [Classification de Füredi
et Gunderson](https://arxiv.org/pdf/1310.6766#page=3).

- Le sommet ajouté voit au plus un sommet du $K_8$, puisque
  deux voisins dans cette clique sont reliés par un chemin de
  longueur 7. Il doit voir les six sommets propres au $K_7$
  et un sommet du $K_8$. Si ce dernier n’est pas le sommet
  commun, un chemin de longueur 3 dans $K_8$, puis de longueur
  4 dans $K_7$, le relie à l’un des six voisins, donnant un
  $C_9$. S’il s’agit du sommet commun, on obtient deux $K_8$
  recollés. Le sommet suivant voit au plus un voisin dans
  chaque clique, en contradiction avec ses sept voisins.
- À partir de $K_{7,7}$, au cours de l’extension bipartie
  chaque nouveau sommet a un voisin dans la partie opposée
  du $K_{7,7}$ initial. En effet, cette partie contient au
  plus six sommets ajoutés puisque c’est un stable de taille
  au plus 13. Toute paire d’extrémités opposées est alors
  reliée par un chemin de longueur 7. Si les deux sont dans
  le noyau, le chemin reste dans le noyau. Si les deux sont
  ajoutées, on les relie chacune à un voisin du noyau puis
  on prend un chemin de longueur 5 dans le noyau. Si une seule
  extrémité est ajoutée, soit elle a un voisin du noyau autre
  que l’autre extrémité et on prolonge par un chemin de
  longueur 6 dans le noyau, soit elle a un voisin ajouté
  que l’on relie au noyau et on prolonge par une longueur 5.
  Ainsi, un nouveau sommet ayant des voisins dans les deux
  parties fermerait un $C_9$. L’extension reste bipartie
  et ne peut atteindre 27 sommets sous $\alpha\le13$.

Pour la circonférence, on utilise
$h(n,k,a)=\binom{k-a}{2}+a(n-k+a)$ dans les théorèmes
de Kopylov et de stabilité de Füredi, Kostochka et Verstraëte.
Les seuils sont vérifiés dans le certificat entier.
[Théorèmes 1.3 et 1.4](https://arxiv.org/pdf/1507.05338#page=2).

- Avec $k=14$, Kopylov donne $c(B)\ge14$ pour $b\le32$.
  À $b=33$, la stabilité impose, si $c(B)<14$, une forêt
  d’étoiles après retrait d’au plus six sommets. Cette forêt
  a un stable de taille au moins 14.
- Avec $k=15$, pour $b\le32$, si $c(B)<15$ la stabilité
  impose un sous-graphe de $H_{b,15,7}$, dont un stable
  a taille $b-8>13$.
- Avec $k=16$, pour $b\le31$, si $c(B)<16$ on retire au
  plus sept sommets pour obtenir une forêt d’étoiles. On peut
  compléter l’ensemble retiré $A$ à sept sommets et le reste
  $F$ reste une forêt d’étoiles. Posons $u=b-7$.
  $e(F)\le\alpha(F)\le13$, donc $e(A,F)\ge m-21-13$.
  Pour $\delta_0=\max(14,\lceil(u+5)/2\rceil)$, cette borne
  est supérieure à $3u+4(\delta_0-1)$. Il existe donc un
  ensemble $L\subseteq A$ d’au moins quatre sommets de
  degré dans $F$ au moins $\delta_0$.

  Soit $xy$ une arête d’un couplage maximum de $F$.
  Si $x,y$ admettent deux voisins distincts dans $L$,
  on prend ces voisins pour extrémités d’une liste de
  quatre sommets distincts de $L$. Chaque paire consécutive
  a au moins cinq voisins communs dans $F$. Après exclusion
  de $x,y$, on choisit trois représentants distincts. Ils
  donnent un chemin alterné de longueur 8 de $x$ à $y$
  qui, avec $xy$, ferme un $C_9$. Ainsi chaque arête du
  couplage contribue au plus $|L|$ arêtes vers $L$.
  La même borne vaut pour chaque sommet non couvert.
  Le couplage a $u-\alpha(F)$ arêtes, car $F$ est une
  forêt d’étoiles. On obtient
  $\delta_0|L|\le e(L,F)\le\alpha(F)|L|\le13|L|$,
  une contradiction.

## Branche du triangle

Les chemins de longueurs 5 et 6 dans $H=B-V(C_3)$ sont
effectivement exclus entre des extrémités attachées à des
labels distincts du triangle. Cette restriction n’impose
pas $c(H)\le6$, même avec la 2-connexité et $\alpha(B)\le13$.

Le témoin du certificat a cinq cliques disjointes de tailles
$8,8,8,7,2$. Dans chaque clique on choisit une entrée et
une sortie distinctes. On relie chaque sortie à l’entrée
suivante dans un ordre cyclique. Tout cycle qui utilise
une de ces cinq arêtes doit utiliser les cinq et au moins
une arête de chacune des cliques. Il a donc longueur au
moins 10. Un cycle interne à une clique a longueur au
plus 8. La suppression d’un sommet laisse le graphe
connexe. Après suppression d’un triangle disjoint des
entrées et sorties, on peut traverser successivement les
cinq cliques pour obtenir un cycle de longueur 30.
Le vérificateur contrôle les 111 arêtes, l’indépendance 5,
la 2-connexité, l’absence de $C_9$ et le cycle de longueur
30. Ce témoin est sous le seuil de densité requis. Les 117
arêtes de l’essai local précédent demeurent une borne
inférieure expérimentale pour sa classe de recherche.

## Rejeu

Le certificat combine les démonstrations ci-dessus et des
vérifications finies en arithmétique entière. À partir du
répertoire `odd-block-c9`, lancer
`python3 -B verify-c9-odd-block.py | cmp - odd-block-certificate.json`.
L’archive inclut le module de contrôle du résultat précédent.
