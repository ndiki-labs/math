# Exclusion des noyaux laissant douze sommets à l’extérieur

Soit $B$ un bloc de la
[réduction d’Erdős #556](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est 2-connexe, non biparti, sans $C_9$ et d’indépendance au
plus 13. Son ordre $b$ est compris entre 25 et 33 et son nombre
d’arêtes est au moins $m_b=176-\operatorname{ex}(34-b,C_9)$.

On exclut la présence dans $B$ d’un noyau biparti induit $D$
qui laisse exactement douze sommets à l’extérieur, sous la
condition de chemins d’[answer-15](../eleven-exterior-c9/C9-ELEVEN-EXTERIOR.md).
Dans une même partie de $D$, chaque paire distincte est reliée
par des chemins simples de longueurs $2,4,6$. Entre parties
opposées, chaque paire est reliée par des chemins simples de
longueurs $3,5,7$. Avec les exclusions précédentes, un noyau
qui satisfait cette condition doit laisser au moins treize
sommets à l’extérieur.

## 1. Oreille minimale et sites d’attachement

Une oreille a ses extrémités distinctes dans $D$ et ses sommets
intérieurs hors de $D$. Sa parité est incorrecte si elle est
impaire sur un même côté ou paire entre côtés opposés. La
2-connexité et la non-bipartition donnent une telle oreille
par le lemme d’answer-13. Les chemins prescrits dans $D$
excluent les longueurs au plus sept. On choisit donc dans
tout $B$ une oreille de mauvaise parité de longueur minimale,
$$
P=(x=v_0,v_1,\ldots,v_{\ell-1},v_\ell=y),
\qquad 8\le\ell\le13.
$$
Les ancres $x$ et $y$ sont opposées pour $\ell$ paire et dans
la même partie pour $\ell$ impaire. Notons $a,c$ les tailles
des parties de $D$, avec $x$ dans celle de taille $a$.
Un label supplémentaire désigne un sommet de $D$ autre
que les ancres. Soit $W=V(B)\setminus(V(D)\cup V(P))$.
Il contient $k=13-\ell$ sommets.

On applique d’abord les deux règles de position d’answer-15.

- Seuls $v_1$ et $v_{\ell-1}$ peuvent avoir des voisins parmi
  les labels supplémentaires et ceux-ci doivent être du côté
  de l’ancre correspondante.
- Si $w\in W$ touche un label supplémentaire $z$, ses voisins
  dans $D$ sont tous du côté de $z$. Il a au plus deux voisins
  à l’intérieur de $P$. Il y en a au plus un dans
  $\{v_1,v_2\}$ et un dans $\{v_{\ell-2},v_{\ell-1}\}$.

En effet, une attache de $v_i$ donne des oreilles vers les
ancres de longueurs $i+1$ et $\ell-i+1$. Les deux longueurs
sont strictement inférieures à $\ell$ pour
$2\le i\le\ell-2$ et l’une a forcément une parité incorrecte.
Le raisonnement pour un voisin $v_i$ de $w$ utilise les
longueurs $i+2,\ell-i+2$. La parité à chaque extrémité impose
le choix d’au plus une position proche de cette extrémité.
Enfin deux voisins de $w$ sur des côtés opposés donneraient
une oreille incorrecte de longueur deux.

## 2. Arêtes à l’extérieur de l’oreille

Répartissons les sommets de $W$ en trois groupes. Les deux
premiers sont les sommets qui touchent au moins deux
sommets de $D$, dont un label supplémentaire, sur
chacune des deux parties. Notons leurs tailles $r_a,r_c$.
Le troisième groupe contient les autres.

Un sommet du premier ou du deuxième groupe envoie
normalement au plus $a+2$ ou $c+2$ arêtes vers $D\cup P$.
Un sommet du troisième groupe en envoie au plus $\ell+1$.
S’il touche un label supplémentaire, il a un seul voisin
dans $D$ et au plus deux voisins intérieurs sur $P$.
Sinon ses seuls voisins possibles dans $D\cup P$ sont
les $\ell+1$ sommets de $P$, ancres comprises.

Aucune arête ne joint deux sommets d’un même des deux
premiers groupes. Chaque sommet y a deux attaches au
noyau sur le même côté. On peut donc choisir deux
labels distincts, un pour chaque sommet. L’arête les
relierait par une oreille incorrecte de longueur trois.
Le nombre d’arêtes internes à $W$ est au plus
$$
\binom{k}{2}-\binom{r_a}{2}-\binom{r_c}{2}.
$$

### Raffinement à longueur huit

Pour $\ell=8$, un sommet du premier groupe a pour
seuls voisins possibles à l’intérieur de $P$ les
positions 2 et 7. Pour le deuxième groupe, ce sont
les positions 1 et 6. Considérons le premier groupe,
de taille $r>0$, sur la partie de taille $a$.

- Si aucun sommet du groupe n’utilise les deux positions,
  le budget d’attaches du groupe vaut au plus $r(a+1)$.
- Sinon, choisissons un sommet $w$ qui utilise les deux.
  L’arête $wv_2$ fabrique une oreille de longueur huit
  entre chaque voisin de $w$ dans le noyau et l’ancre
  opposée $y$. Ces paires doivent manquer comme arêtes du
  noyau. De plus, $wv_7$ fournit un chemin de longueur
  sept entre $w$ et $v_1$. Leurs ensembles de voisins
  dans $D$ sont donc disjoints, car un voisin commun
  fermerait un $C_9$. En particulier $w$ ne touche pas
  $x$. Les pertes du noyau imposées par $w$ sont ainsi
  disjointes de celle de la non-arête $xy$ et des pertes
  déjà comptées pour les attaches de $v_1$.
  On peut payer toutes les attaches de $w$ au noyau
  et compter au plus deux arêtes vers l’oreille pour
  ce sommet. Les autres sommets du groupe contribuent
  au plus $(r-1)(a+2)$.

On prend donc le maximum de $r(a+1)$ et
$2+(r-1)(a+2)$ pour le premier groupe. Le deuxième
groupe est symétrique, en échangeant les ancres et
en renversant l’oreille. Les pertes payées sur les
deux côtés sont distinctes, car chaque paiement
relie un label supplémentaire à l’ancre opposée.
Le programme maximise le budget total sur les
valeurs de $r_a,r_c$ et le compte du troisième groupe.

## 3. Noyau et arêtes sur l’oreille

On énumère les graphes induits sur l’oreille et ses
ancres, en réservant l’arête éventuelle $xy$ au compte
du noyau. Toute extension qui crée entre les ancres
un chemin plus court de même parité est exclue.
Ce contrôle est monotone sous ajout d’arêtes et
permet une énumération par inclusion et exclusion.

Pour une partie de $D$, tous les sommets intérieurs
qui n’ont ni voisin parmi ses ancres ni position
permettant un contact supplémentaire ne touchent
pas cette partie. On calcule exactement le plus
grand stable sur ces sommets dans le graphe énuméré.
Il s’ajoute à la partie entière. Les tailles des
parties doivent respecter $\alpha(B)\le13$.

Si $\ell=8$, les attaches supplémentaires des deux
sommets extrêmes de l’oreille se paient comme dans
answer-15. Chaque contact force une non-arête
vers l’ancre opposée et les pertes sont distinctes.
L’arête $xy$ manque aussi. Avec $e_P$ le nombre
d’arêtes du graphe énuméré, on utilise donc
$ac+e_P-1$ avant les contributions de $W$.

Si $\ell=9$, les deux sommets extrêmes de l’oreille
ne peuvent partager un voisin du noyau. Le chemin
entre eux à l’intérieur de $P$ a exactement sept
arêtes et un voisin commun fermerait un $C_9$.
Les deux ancres étant dans le même côté, les
attaches supplémentaires contribuent au plus $a-2$,
ce qui est plus strict que le budget $2(a-2)$
utilisé aux longueurs impaires supérieures.

Pour les longueurs paires supérieures à huit,
le budget d’attaches supplémentaires reste
$a+c-2$. Le programme ajoute dans chaque cas
le budget de $W$ de la section 2.

## 4. Contrôle exact

| Longueur de l’oreille | Arêtes facultatives admissibles individuellement | Graphes sans raccourci de même parité |
| ---: | ---: | ---: |
| 8 | 15 | 216 |
| 9 | 20 | 864 |
| 10 | 24 | 1 296 |
| 11 | 30 | 5 184 |
| 12 | 35 | 7 776 |
| 13 | 42 | 31 104 |

| Ordre $b$ | Seuil $m_b$ | Majorant ou exclusion |
| ---: | ---: | ---: |
| 25 | 147 | 110 |
| 26 | 148 | 117 |
| 27 | 155 | 125 |
| 28 | 161 | 134 |
| 29 | 166 | 144 |
| 30 | 170 | 154 |
| 31 | 173 | 165 |
| 32 | 175 | 174 |
| 33 | 176 | Indépendance incompatible |

Les six longueurs donnent 46 440 graphes à contrôler.
Les majorants sont strictement sous les seuils aux ordres
25 à 32. À l’ordre 33, les stables écartent toutes les tailles
possibles des deux parties. Le cas des douze sommets est
donc clos, sous la condition donnée sur le noyau.

## Rejeu

Depuis `twelve-exterior-c9` dans le ZIP extrait, exécuter
`python3 -B verify-twelve-exterior.py | cmp - twelve-exterior-certificate.json`.
Le vérificateur compile le calculateur avec un compilateur
`c++` prenant en charge C++17. Il contrôle la table des
positions et des longueurs de paiement, les effectifs de
l’énumération et les comparaisons avec les seuils.
