# Deux passages bipartis et huit triangles à l’ordre 31

Le bloc candidat $B$ de la [réduction monochrome](../mono-extremal/C9-MONO-EXTREMAL.md)
est sans $C_9$, vérifie $\alpha(B)\le13$ et satisfait
$e(B)\ge m_b=176-\operatorname{ex}(34-b,C_9)$ à l’ordre $b$.
On reprend le [retrait à l’ordre 31](../order31-and-core-contacts-c9/C9-ORDER-31-AND-CORE-CONTACTS.md)
et les [contraintes sur neuf triangles](../nine-triangles-c9/C9-NINE-TRIANGLES.md).

## 1. Un sous-graphe biparti dense à 19 sommets

Un noyau est un graphe biparti dont les parties ont au
moins quatre sommets et dont les paires de sommets distincts
admettent des chemins simples de longueurs $2,4,6$ du même
côté et $3,5,7$ de côtés opposés. Dans un bloc candidat
d’ordre 31, un [noyau induit](../twelve-exterior-c9/C9-TWELVE-EXTERIOR.md)
d’ordre au moins 19 est impossible.

On affine le critère d’[answer-24](../degree-peeling-and-nine-c9/C9-ORDER-30-AND-NINE-TRIANGLES.md).
Dans un graphe biparti de degré minimal au moins deux, supposons
qu’un côté possède au moins trois sommets universels et que toute
paire distincte de ce côté ait un voisin commun. Ce graphe est un
noyau si les parties ont au moins quatre sommets.

Pour les chemins pairs, la seule difficulté supplémentaire par
rapport à quatre sommets universels concerne une paire universelle
du même côté au moment de construire un chemin de longueur six.
On utilise un sommet de ce côté hors des trois universels avec
deux voisins distincts, puis le troisième sommet universel avec
un autre sommet du côté opposé. Si quatre sommets universels
sont disponibles, on reprend directement le critère d’answer-24.

Pour un chemin de longueur sept dont le départ $x$ est universel,
on dispose de deux autres sommets universels. Prendre un sommet
$w$ du côté de $x$ hors de ces trois sommets. Si $w$ a deux voisins
distincts différents de l’arrivée $y$, on traverse $w$ en premier
et on termine par les deux autres sommets universels. Sinon
$w$ est adjacent à $y$ et à un autre sommet. On traverse les
deux sommets universels d’abord et on termine par $w,y$. Dans
les deux ordres, quatre sommets du côté opposé suffisent.
Pour un départ non universel, les trois autres sommets universels
suffisent directement. Les chemins de longueur trois ou cinq
ne demandent qu’un ou deux sommets universels distincts du départ.

Considérons maintenant un biparti de 19 sommets avec au plus
12 arêtes manquantes et un degré minimal d’au moins deux. S’il
ne possède pas de noyau et si les deux parties ont taille au moins
quatre, une paire du même côté doit avoir des voisinages disjoints.
En effet, si tous les codegrés valent au moins trois, answer-24
donne un noyau. Sinon, une paire de codegré au plus deux dans le
côté de taille $a$, face au côté de taille $c$, concentre au moins
$c-2$ arêtes manquantes. Le nombre de sommets universels dans son
côté est au moins $a-2-(12-(c-2))=3$. Si toutes les paires de ce
côté ont un voisin commun, le nouveau critère donne un noyau.

## 2. Rejeu des passages bipartis à 21 et 20 sommets

Les comparaisons par degré minimal d’answer-25 donnent les
tailles, degrés et nombres d’arêtes pour un premier passage
biparti à 21 sommets. Dans chacune de ces hypothèses, retirer
un sommet de degré minimal trois, puis un sommet de degré minimal
dans le graphe à 20 sommets. Le graphe à 19 sommets manque d’au
plus onze arêtes et son degré minimal est au moins deux.
Il possède donc une paire aux voisinages disjoints.

Le vérificateur place cette paire dans les deux premiers sommets
d’un côté, à transposition près, et ses voisinages dans deux
intervalles disjoints de l’autre côté. Le premier intervalle est
le plus petit des deux. Il énumère les pertes restantes et toutes
les réinsertions qui respectent les degrés minimaux. Toute
réinsertion à 20 sommets qui passe les contraintes arithmétiques
contient déjà un noyau interdit sur 19 ou 20 sommets. Les chemins
du noyau sont contrôlés par masques et parcours simples. Le premier
passage biparti à 21 est donc exclu.

Ainsi le graphe à 21 sommets obtenu à partir de $B$ est
non biparti et possède au moins 85 arêtes. Pour un premier passage
biparti à 20, on recalcule les comparaisons de degrés et on retire
un sommet de degré minimal du biparti hypothétique. À 19 sommets,
il manque au plus douze arêtes. On utilise le même contrôle des
paires disjointes. Un degré minimal de zéro ou un est désormais
possible à 19, donc on énumère aussi les motifs où un sommet
de degré zéro ou un est fixé dans le premier côté. Ces deux familles
couvrent la totalité des enfants sans noyau permis.

Pour toute réinsertion bipartie à 20 sans noyau détecté, on teste
si elle peut provenir du graphe non biparti à 21 par retrait du
sommet v de degré minimal. Les voisins de v dans le biparti
doivent comprendre tout sommet dont le degré serait autrement
trop faible. Les voisins sur les deux côtés ne peuvent être reliés
par un chemin de longueur sept. Au moins une paire opposée doit
appartenir à la même composante, faute de quoi la bipartition
s’étendrait en permutant au besoin les côtés des composantes.
Dans le test, on choisit le voisinage de v dans une partie et
on calcule l’intersection des choix permis dans l’autre.

Un profil normalisé passe ces tests locaux et contient un
$K_{9,9}$. Or dans $B$, un $K_{9,9}$ est induit, puisqu’une arête
interne fermerait un chemin alterné de longueur huit. Aucun
sommet extérieur ne peut toucher les deux côtés, à cause d’un
chemin de longueur sept. Avec deux voisins du même côté, on
formerait un noyau d’ordre 19 en ajoutant ce sommet à la partie
opposée. Ce dernier point suit du critère d’ajout dans la
[preuve d’answer-25](../order31-and-core-contacts-c9/C9-ORDER-31-AND-CORE-CONTACTS.md),
puisque toutes les arêtes entre les parties sont présentes.
Chaque sommet extérieur a donc au plus une attache. Il y en a
treize, et même avec toutes leurs arêtes internes on obtient
$$
e(B)\le81+13+\binom{13}{2}=172<173.
$$
Le passage à 20 est également exclu. À l’ordre 31, les retraits
gardent un graphe non biparti jusqu’à 20 sommets. L’ordre 31
reste candidat au-delà de cette réduction.

## 3. Huit triangles et trois projections du reste

Le reste $J$ d’une famille maximale en cardinalité de huit
triangles est sans triangle et d’ordre 7, 8 ou 9. On classe les
graphes sans triangle par ajout d’un sommet sur un voisinage
indépendant. Pour la réduction à isomorphisme près, on raffine
les classes de sommets par nombres de voisins, puis on énumère
les individualisations encore possibles. Deux sommets de la
même classe que leur transposition seule préserve peuvent
représenter le même choix. On écarte les restes contenant un
$C_9$ ou, conformément à answer-25, un noyau induit.

On partitionne le reste en trois groupes d’au plus trois sommets.
Les signatures de chemins se calculent dans $J$ tout entier et
les profils de contacts se projettent sur chaque groupe. Les
nouveaux contrôles locaux examinent les trois masques concrets
d’attaches à un triangle. Un chemin de longueur cinq ou six entre
deux sommets du reste interdit des attaches à deux labels
distincts du triangle. Un chemin de longueur sept interdit
un label commun. On réutilise ensuite les contraintes sur le
déficit des coupes, sur les triangles de réserve et sur les
chemins évitant un troisième sommet d’answer-23.

Chaque projection fournit une table du nombre maximal d’attaches
en fonction de son nombre de marques et du déficit global des
coupes. Une marque signifie au moins deux voisins dans un
triangle. Soit $S$ le nombre réel de coupes contenant une étoile
saturée. Pour toute union de groupes comprenant $r'$ sommets et
$D'$ marques, le graphe d’étoiles augmenté donne
$D'+S\le F(8+r')$. Le calcul maximise la somme des trois
plafonds d’attaches et du plafond sur les arêtes des triangles
en appliquant cette inégalité aux sept unions de groupes.

Le graphe biparti des marques ne contient pas de $C_6$. Un tel
cycle se relèverait en $C_9$ en choisissant, dans chacun des
trois triangles traversés, deux attaches à des labels distincts
et une arête entre ces labels. On calcule le plafond $Z(8,r')$
du nombre de marques en énumérant les masques des huit triangles
par cardinalité décroissante. L’ajout d’un masque ne peut fermer
un cycle de six dans le graphe des marques. À chaque étape, la
taille du plus grand masque restant borne la contribution de
tous les triangles restant à placer. En particulier
$Z(8,7)=24$. Les budgets de chaque union sont donc
$$
D'\le\min(F(8+r')-S,\ Z(8,r')).
$$
Pour chaque reste, on prend la plus petite borne sur toutes les
partitions en trois groupes et on ajoute ses arêtes internes.

## Résultats du calcul

| Ordre du bloc | Classes sans triangle au départ | Classes encore possibles | Majorant global certifié | Seuil |
|---:|---:|---:|---:|---:|
| 31 | 107 | 0 | 172 | 173 |
| 32 | 410 | 186 | 180 | 175 |
| 33 | 1 897 | 1 076 | 188 | 176 |

À l’ordre 31, le couple $(31,8)$ est exclu. Le bloc candidat
peut encore avoir au plus sept triangles disjoints. Aux
ordres 32 et 33, les majorants atteignent encore les seuils
respectifs. Les tables contrôlent 104 007 profils de
partitions et 304 780 390 profils locaux d’attaches sur
3 048 signatures. Le certificat contient une borne par
classe résiduelle. Onze des couples étudiés avec cinq
triangles ou plus demeurent ouverts, ainsi que le cas
général de $C_9$.

## Rejeu

Avec Python 3 et un compilateur C++17, depuis le dossier
de ce document dans le ZIP extrait

~~~sh
python3 -B verify-bipartite-transition-and-eight.py | cmp - bipartite-transition-and-eight-certificate.json
~~~
