# Fermeture du K₄ dans la réduction héréditaire

Soit $H$ un contre-exemple d’ordre minimal à la borne
d’answer-47, sur $23\le n\le33$ sommets. Il est sans $C_9$, de
degré minimal au moins 8, et vérifie $e(H)\ge7n-55$. D’après
[answer-49](../k5-minimum-degree-c9/C9-K5-MINIMUM-DEGREE.md),
il est aussi sans $K_5$. On montre qu’il est sans $K_4$.

Fixons une clique $Q$ de taille quatre, avec reste $R=H-Q$.
La coupe a au moins 23 arêtes par minimalité d’ordre.
Les attaches d’un sommet de $R$ sont ses voisins dans $Q$,
au plus trois. Les chemins simples de longueur 4, 5 ou 6
dans $R$ entre deux sommets qui peuvent choisir des attaches
distinctes à $Q$ donnent des oreilles de longueurs 6, 7 ou 8.
Ils sont interdits, car $Q$ offre le chemin complémentaire
dans un $C_9$.

Sur un noyau induit $S$ de huit sommets, le nombre d’arêtes
incidentes à $S$, à savoir $e(S)+e(S,H-S)$, est au moins
49 à l’ordre 23, 56 à l’ordre 24, et 57 ensuite. C’est le
comptage par retrait d’answer-49. À l’ordre 23, retirer
sept des huit sommets suffit.

## Une oreille de longueur 4 ou 5 est nécessaire

Supposons les deux longueurs absentes. Dans $R$, les chemins
de longueur 2 à 6 entre sommets qui peuvent choisir des
attaches distinctes sont alors interdits. Soient $D$ les
sommets ayant au moins deux attaches, et $Z$ ceux sans
attache. Un sommet $x\in D$ a au plus un voisin dans $D$,
sinon deux tels voisins seraient reliés à longueur 2.
Son degré dans $R$ est au moins cinq. Choisissons un de ses
voisins $y_x$ hors de $D$. Tous les voisins de $y_x$ dans
$R$ autres que $x$ sont sans attache, par l’interdiction de
longueur 2. Il y en a au moins six. Deux sommets de $D$
ne peuvent ni partager $y_x$ ni faire se recouper les
ensembles de six, car cela donne respectivement une
longueur 2 ou 4. Il suit que $|Z|\ge6|D|$ et
$$23\le e(Q,R)\le |R|-|Z|+2|D|\le29-4|D|.$$
En particulier $|D|\le1$.

Les sommets simplement attachés se répartissent entre
les quatre groupes $A_i$ selon leur label dans $Q$. Chaque
groupe compte au moins $5-|D|$ sommets. Une arête entre
deux groupes force tous les voisins simplement attachés
de chaque extrémité à être du groupe opposé, par
l’interdiction de longueur 2. Cette règle se propage.
Toute composante des simples attaches contenant une
arête croisée est donc bipartie sur deux groupes et sans
chemin de longueur 3, donc une étoile. Elle n’a aucune
arête vers $D$, car chaque sommet de la composante a un
voisin de l’autre groupe, ce qui donnerait un chemin
interdit de longueur 2 à partir de $D$. Une feuille de
l’étoile doit donc avoir au moins six voisins dans $Z$.

Si $D$ est vide, il y a au plus six sommets dans $Z$.
Si une telle étoile existe, tous les sommets de $Z$ sont
voisins d’une feuille. Chacun ne peut voir qu’un seul
groupe, par l’interdiction de longueur 2. Toutes les
feuilles des étoiles croisées appartiennent alors au
même groupe $A_i$. Les autres groupes ont chacun au
moins cinq sommets. On a donc $|A_i|\le29-6-15=8$.
Chaque centre a au moins sept feuilles distinctes.
Il ne peut y avoir qu’un centre. Chacun des trois
autres groupes a un sommet qui n’est pas ce centre
et doit donc avoir au moins sept voisins dans son
groupe. Au total il faudrait au moins $6+5+3\cdot8=35$
sommets dans $R$, une contradiction.

Si $D=\{x\}$, il y a au plus huit sommets dans $Z$.
Choisissons le voisin $y_x$ ci-dessus. Les au moins six
sommets de $Z_0=N_R(y_x)\setminus\{x\}$ ne peuvent
toucher aucune simple attache $a$ autre que $y_x$.
Sinon $x-y_x-z-a$ est un chemin interdit de longueur 3.
La seule feuille possible d’une étoile croisée serait
$y_x$, mais une étoile non triviale a au moins deux feuilles
(le cas d’une seule arête a aussi deux extrémités feuilles).
Les étoiles croisées sont donc impossibles dans les deux cas.

Il n’y a aucune arête entre groupes et un sommet de $Z$ ne
peut toucher deux groupes. Soit $Z_i$ la partie de $Z$ qui
touche $A_i$. Si $D$ existe, son sommet ne peut toucher
deux groupes, par l’interdiction de longueur 2. Pour au
moins trois groupes la réunion $A_i\cup Z_i$ contient donc
au moins huit sommets. Le quatrième en contient au moins
sept, même en comptant le voisin possible dans $D$. Les
quatre réunions, disjointes, consommeraient au moins 31
sommets dans $R$, en contradiction avec $|R|\le29$.

## Tests sur un noyau de huit sommets

Le vérificateur reprend le principe d’answer-49. Le noyau
est $Q$ et quatre sommets supplémentaires. Les permutations
des quatre labels de $Q$ sont éliminées en triant les quatre
masques décrivant leurs contacts avec les sommets de
l’oreille, dont l’ordre reste fixé. Les cordes possibles de
cette oreille sont testées dans les deux états. On rejette
les noyaux contenant un $K_5$. Les longueurs des chemins
simples sont vérifiées par deux méthodes indépendantes,
par parcours et par récurrence sur les sous-ensembles.

Soit $W=H-S$ le reste. Un profil extérieur est l’ensemble
des voisins d’un sommet de $W$ dans le noyau. Un profil
n’est permis que s’il ne ferme aucun chemin de longueur
7 dans $S$. Deux profils à distance extérieure $d$ le long
d’un chemin simple sont incompatibles si deux de leurs
labels distincts sont reliés avec longueur $7-d$ dans $S$.
Dans la branche sans oreille de longueur 5, on interdit
aussi tout profil ou couple qui donnerait une telle oreille
sur $Q$. Pour tester un couple, les seuls nouveaux sommets
sont ses deux extrémités et ceux de leur chemin extérieur,
avec uniquement les arêtes prescrites. Une interdiction
dans ce sous-graphe vaut pour le graphe entier.

Appelons $A_i$ les sommets de $W$ qui touchent le label $i$
du noyau. Ils existent car $|S|=8$ et $\delta(H)\ge8$. Si
aucun profil ne contient les labels $i,j$ ensemble et si
les simples profils $\{i\},\{j\}$ sont incompatibles à
longueur extérieure 1 et 2, les unions de $A_i$ et $A_j$
avec leurs voisinages respectifs dans $W$ sont disjointes.
Pour rendre ce test nécessaire, les profils simples
représentent ici les seules arêtes aux labels désignés.
D’éventuelles attaches supplémentaires ne peuvent éviter
un cycle ou une oreille déjà présents. Pour chaque label
$i$, si le plus grand profil le contenant a taille $m_i$,
son union de voisinages contient au moins $9-m_i$ sommets.

On pondère aussi les mêmes ensembles par leur déficit
d’attaches. Soit $c$ la taille maximale d’un profil.
Si un sommet dans $A_i$ porte le profil $P$, il a au moins
$8-|P|$ voisins dans $W$. Posons $c_P$ la taille maximale
d’un profil qu’on peut lui relier à longueur extérieure 1.
Le sommet et ces voisins imposent un déficit d’au moins
$$c-|P|+(8-|P|)(c-c_P)$$
sous le plafond brut $c|W|$. On minimise cette expression
sur les profils de $A_i$, puis on maximise la somme sur
les labels à unions disjointes. On soustrait le déficit
du plafond de la coupe. Les tests comparent tous les
plafonds au seuil incident de chaque ordre.

## Oreille de longueur 5

On prend $Q$ et les quatre sommets intérieurs de l’oreille.
Le recensement donne 15 191 noyaux. Les profils simples
en écartent 11 363, puis la taille des voisinages disjoints
en écarte 3 807. Sur les 21 noyaux restants, les profils
ont taille au plus trois et le contrôle fini établit trois
propriétés. Une triple attache ne peut être adjacente à
un profil multiple ni reliée à un profil non vide par un
chemin extérieur de longueur 2. Deux triples ne peuvent
être reliés par un chemin extérieur de longueur 4.

Pour chaque triple, on choisit un voisin dans $W$, qui doit
avoir un profil vide ou simple. Ses autres voisins dans
$W$ ont des profils vides et fournissent au moins six
sommets distincts. Ces ensembles sont disjoints entre
triples par les interdictions de longueur 2 et 4.
S’il y a $t$ triples, au moins $6t$ profils sont donc
vides. La coupe a au plus $2|W|+t-12t=2|W|-11t$ arêtes.
Pour $t\ge1$, c’est insuffisant. Sans triple, on rejoue
le déficit de degrés avec des profils de taille au plus
deux. Les 21 noyaux sont exclus.

## Oreille de longueur 4 en l’absence de longueur 5

Le noyau initial contient $Q$ et les trois sommets
intérieurs $u,v,w$ d’une oreille $a-u-v-w-b$.
Le sommet central $v$ a au moins un voisin extérieur au
noyau initial, puisqu’il n’a que six autres sommets à sa
disposition. On choisit un tel voisin $y$ comme huitième
sommet, avec toutes ses arêtes vers le noyau initial.
On rejette les noyaux qui contiennent le $K_5$ ou une
oreille de longueur 5 sur $Q$.

Il reste 2 716 noyaux avant le test de degrés. Le plafond
des attaches en écarte 550, les tailles de voisinages
disjoints 2 131 et les déficits 16. Dans les 19 noyaux
qui passent ce premier test, $y$ touche uniquement $v$
dans le noyau initial. Comme $y$ était un voisin extérieur
arbitraire de $v$, chaque sommet de $W$ qui touche $v$
ne touche que $v$ dans le noyau initial. Il peut en plus
toucher $y$. On réinjecte exactement cette restriction.
Le déficit exclut 17 noyaux sur les 19. Les deux derniers
satisfont les trois propriétés des triples, vérifiées
cette fois avec l’interdiction d’oreille de longueur 5.
Le même comptage exclut tout triple, puis le déficit
calculé avec les profils de taille au plus deux les exclut.

## Portée et rejeu

Dans tout contre-exemple minimal de la réduction ascendante,
le nombre de clique est donc exactement 3. Cette dernière
branche et le cas général de $R_3(C_9)=33$ restent ouverts.
Le calcul est fini et utilise uniquement des entiers.

Depuis ce dossier dans le ZIP extrait, avec Python 3 et
un compilateur C++20.

```sh
python3 -B verify-k4-minimum-degree.py | cmp - k4-minimum-degree-certificate.json
```
