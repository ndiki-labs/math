# Erdős #556 · Un stable de taille 15 force un C₉

**Résultat.** Dans tout 3-coloriage de `K₃₃` sans `C₉` monochromatique,
chaque graphe de couleur a un nombre d’indépendance au plus **14**.
En particulier, dans tout ensemble de 17 sommets, chaque couleur apparaît
sur au moins trois arêtes. Si une couleur apparaît sur trois arêtes
exactement, elles sont deux à deux disjointes.

## Deux cliques bleues dans un stable rouge

Supposons qu’un stable rouge contienne 15 sommets. Les arêtes sur cet
ensemble sont bleues ou vertes. Le théorème 2 de Nikiforov–Schelp, pour
`n = 9` et `β = 1/3`, donne après retrait d’un sommet `q` deux cliques
bleues réunies par une coupe entièrement verte. Les tailles sont
`(7,7)` ou `(6,8)`. Dans le second cas, une paire de voisins verts de
`q` sur des côtés opposés fermerait un chemin vert de longueur 7.
Le sommet `q` évite donc le vert sur un côté. Ce côté est celui de taille
6, car un `K₉` bleu est interdit. En ajoutant `q` à la clique de taille
6, on obtient deux cliques bleues de tailles `(7,8)`, avec au plus une
arête bleue entre elles. Deux voisins bleus de `q` dans le `K₈`
fermeraient en effet un chemin bleu de longueur 7.

On dispose donc de deux cliques bleues `A,B` de tailles `(7,7)` ou
`(7,8)`, séparées par une coupe verte complète à une arête près.
Dans cette coupe, toute paire d’extrémités opposées est jointe par un
chemin de longueur 7, et toute paire d’extrémités distinctes du même
côté par un chemin de longueur 6. Pour un chemin entre côtés opposés,
éviter un sommet incident à l’arête manquante si ce sommet est libre.
Lorsque les deux extrémités constituent cette arête, le chemin alterné
de longueur 7 les sépare. Pour le chemin de longueur 6 entre sommets
du même côté, éviter l’extrémité de l’arête manquante sur l’autre côté.

## Attaches bleues aux deux cliques

Un sommet extérieur a au plus un voisin bleu dans un `K₈` bleu.
Pour un `K₇` bleu, considérons deux sommets extérieurs qui ont chacun
au moins deux voisins bleus. Si l’on peut choisir deux paires distinctes,
chacune dans le voisinage correspondant, les deux paires peuvent être
des arêtes d’un même cycle bleu sur les sept sommets. Insérer les
deux sommets extérieurs dans ces deux arêtes donne un `C₉` bleu. Deux
arêtes distinctes dans un graphe complet, qu’elles se touchent ou
soient disjointes, prolongent toujours ici un cycle sur sept sommets.
Par conséquent, soit tous les sommets ayant au moins deux voisins bleus
ont exactement la même paire, soit il existe un unique sommet ayant
plus de deux voisins bleus et tous les autres en ont au plus un.

Écartons, pour chaque clique de taille 7, son éventuel unique sommet
extérieur à plus de deux voisins bleus. Il reste au moins 17 sommets
extérieurs disponibles. Prenons-en exactement 17. Chacun évite le vert
vers l’une des deux cliques, sinon il ferme un chemin vert de longueur 7.
Répartissons-les suivant un côté sans vert, en `X` pour `A` et `Y`
pour `B`. Échangeons les noms si nécessaire pour avoir `|X| ≥ 9`.

Dans chacun des groupes, deux sommets ont au moins quatre voisins rouges
communs dans la clique correspondante. Pour une clique de taille 7,
l’union des deux ensembles de voisins bleus a taille au plus trois.
Pour une clique de taille 8, elle a taille au plus deux. Ainsi un chemin
alterné rouge peut relier deux sommets du même groupe sur une suite
choisie de sommets extérieurs, en prenant jusqu’à quatre représentants
distincts dans les ensembles de voisins communs. En particulier `X`
est un stable rouge, et `Y` l’est aussi si `|Y| ≥ 5`. Une arête
rouge interne fermerait un chemin rouge de longueur 8 passant par
trois autres sommets du groupe et quatre sommets de la clique.

## Les sommets de X ayant au moins quatre voisins rouges dans B

Appelons `w` un tel sommet. Avec chaque sommet `y` de `Y`, il a au
moins deux voisins rouges communs dans `B`, car `y` y manque au plus
deux arêtes rouges.

- Si `x ∈ X` est distinct de `w` et `y ∈ Y`, l’arête `xy` ne
  peut être rouge. Relier `x` à `w` par un chemin rouge de longueur 6
  via `A` et deux autres sommets de `X`, puis `w` à `y` par
  l’un de leurs voisins rouges communs dans `B`.
- S’il existe deux tels sommets `w₁,w₂`, toute arête rouge entre
  deux sommets `y₁,y₂` de `Y` se ferme en `C₉`. Pour un nouveau
  sommet `x₀ ∈ X`, utiliser
  `y₁,b₁,w₁,a₁,x₀,a₂,w₂,b₂,y₂` avec des représentants distincts
  dans chaque clique. Les deux choix en `B` ont chacun au moins
  deux options. Les deux choix en `A` en ont chacun au moins quatre.
  Pour toute arête entre `X` et `Y`, on peut choisir un `w` distinct
  de son extrémité dans `X` et appliquer le point précédent. Les
  17 sommets extérieurs forment alors un stable rouge, ce qui contredit
  le résultat bicolore `R(C₉,C₉) = 17`.
- S’il existe exactement un tel sommet `w` et `|X| = 9`, on a
  `|Y| = 8`. Le groupe `Y` est un stable rouge. Pour une éventuelle
  arête rouge `wy`, choisir trois autres sommets de `Y` et les
  ordonner de `w` à `y`. Le premier couple offre au moins deux
  représentants dans `B`. Les trois couples suivants en offrent
  au moins quatre chacun. Choisir d’abord le premier représentant.
  Ces choix donnent un chemin rouge de longueur 8 qui ferme `wy`.
  Ici encore, les 17 sommets forment un stable rouge.

Dans les autres cas, au moins neuf sommets de `X` ont au plus trois
voisins rouges dans `B`. Chacun y a au plus deux voisins bleus, donc
au moins deux voisins verts. Une arête verte entre deux de ces
sommets se ferme en `C₉) par deux voisins verts distincts dans `B`
et le chemin vert de longueur 6 entre eux. Ils forment donc un
`K₉` bleu, dernière contradiction.

## Conséquence sur les ensembles de 17 sommets

Dans toute couleur, deux arêtes ou moins peuvent être couvertes en
supprimant au plus deux sommets, laissant un stable d’au moins 15.
Il faut donc au moins trois arêtes de chaque couleur. Si deux des
trois arêtes se touchent, les trois arêtes ont également une
couverture par deux sommets, ce qui donne la même contradiction.

Le cas général `R₃(C₉) ≤ 33` reste ouvert. La preuve combinatoire
s’appuie sur deux théorèmes publiés. Le vérificateur Python rejoue
les propriétés des chemins, des attaches et des tailles de groupes.

- Nikiforov et Schelp, *Cycles and stability*, théorème 2.
  [Texte](https://arxiv.org/pdf/math/0602627#page=2)
- Bondy et Erdős, *Ramsey numbers for cycles in graphs*, pour
  `R(C₉,C₉) = 17`. [Texte](https://doi.org/10.1016/S0095-8956(73)80005-X)
