# Coupes en étoile et attaches au reste des triangles

Soit $B$ un bloc candidat à la réduction monochrome
d’Erdős #556. Il est 2-connexe, sans $C_9$, d’ordre
$25\le b\le33$, d’indépendance au plus 13 et atteint
$m_b=176-\operatorname{ex}(34-b,C_9)$. Fixons une famille
de $q\ge1$ triangles sommet-disjoints. Une famille maximale
laisse un reste $H$ sans triangle. Les résultats suivants
s’appliquent à tout choix des triangles et d’un noyau induit
$D\subseteq H$ satisfaisant la condition de chemins ci-dessous.
Les seuils $m_b$ viennent d’[answer-7](../mono-extremal/C9-MONO-EXTREMAL.md).

## 1. Condition de chemins sur le noyau

Le noyau $D$ est biparti avec deux parties non vides.
Toute paire distincte d’une même partie est reliée dans
$D$ par des chemins simples de longueurs $2,4,6$. Toute
paire de parties opposées est reliée par des chemins simples
de longueurs $3,5,7$. Une condition suffisante est que chaque
partie ait au moins $M+4$ sommets, où $M$ est le nombre
d’arêtes manquantes dans la coupe. En effet, chaque partie
contient au plus $M$ sommets incidents à une arête
manquante. Pour le chemin de longueur sept, on choisit
trois sommets internes de chaque côté en évitant les
extrémités. Pour le chemin de longueur six, on choisit
deux sommets internes du côté des extrémités et trois
de l’autre. Les autres longueurs demandent moins de sommets.

Deux attaches distinctes de $D$ reliées par un chemin de
longueur $d$ entre les sommets extérieurs qui les portent
donnent un $C_9$ s’il existe dans $D$ un chemin de longueur
$7-d$ entre ces attaches. Le cas $d=0$ correspond à deux
attaches d’un même sommet. Ainsi, à attaches distinctes,
on interdit $d\in\{1,3,5\}$ du même côté et
$d\in\{0,2,4\}$ de côtés opposés. Pour des attaches opposées
adjacentes dans $D$, on interdit aussi $d=6$.

## 2. Deux triangles attachés et une coupe entre eux

Appelons attaché un triangle ayant un voisin dans $D$.
Ses arêtes vers $D$ forment une étoile. Deux arêtes
d’attachement disjointes se fermeraient par un chemin
de longueur cinq ou six dans $D$ et un chemin d’une
ou deux arêtes dans le triangle. Toutes les attaches
sont en outre dans la même partie de $D$. Pour deux
attaches de côtés opposés, le chemin interne au triangle
peut avoir longueur deux si les sommets qui les portent
sont distincts. Une même origine extérieure donnerait
le cas $d=0$. Les deux possibilités sont exclues.

Prenons une arête entre deux triangles attachés. Pour
un choix donné d’attaches aux deux extrémités, la
longueur $d$ est la somme de 1 et des deux longueurs
internes aux triangles. Un terme interne vaut 0 si
le sommet qui porte l’attache est déjà à l’extrémité
de l’arête. Sinon il vaut 1 ou 2.

- Si les deux triangles touchent le même côté de $D$,
  deux labels distincts conduisent à $d=1$ si les deux
  termes internes sont nuls et à $d=3$ sinon. Par
  conséquent, une liaison impose un même et unique
  label dans $D$ pour les deux triangles.
- Si les deux triangles touchent des côtés opposés,
  dès qu’un terme interne est non nul on réalise
  $d=2$ ou $d=4$. Une liaison n’est donc possible que
  si chaque triangle porte toutes ses attaches en un
  seul sommet et que l’arête joint ces deux sommets.
  C’est alors la seule arête de leur coupe.

Il reste une conséquence de la 2-connexité. Notons $W$
les sommets de $B$ hors de $D$ et des triangles attachés.
Un triangle attaché à plusieurs labels de $D$ doit
avoir un voisin de $W$ depuis l’un de ses deux sommets
sans attache. En effet il porte toutes ses attaches
sur un seul sommet. Les liaisons à des triangles du
même côté sont exclues et celles au côté opposé
passent par ce sommet. Sans lien vers $W$ depuis les
deux autres sommets, enlever le sommet d’attache
les déconnecterait.

La même obligation vaut pour chaque triangle incident
à une liaison entre côtés opposés. Si $a$ et $b$ portent
cette liaison, supposons qu’un autre sommet $c$ du
triangle de $a$ ait une arête vers un troisième
triangle attaché du même côté. Le troisième triangle
partage alors le label de $a$. Depuis un sommet qui
porte cette attache, on rejoint $c$ par une ou deux
arêtes en utilisant la coupe. On traverse ensuite
le triangle de $a$ jusqu’à $a$, par une ou deux
arêtes, puis on utilise $ab$. On peut choisir les
longueurs pour obtenir exactement quatre arêtes du
sommet qui porte l’attache du troisième triangle
jusqu’à $b$. Ce chemin entre côtés opposés est
interdit. Ainsi toutes les liaisons à d’autres
triangles attachés passent par $a$. Sans arête vers
$W$ depuis le reste de son triangle, $a$ serait un
sommet de coupure.

**Conséquence pour tout $q$.** Si $D=H$ et que tous les
triangles sont attachés, $W$ est vide. Les attaches
multiples dans $D$ et les liaisons de côtés opposés
sont alors exclues. Les seuls groupes de triangles
reliés entre eux partagent un même label dans $D$.
Chacun se sépare du noyau par ce label, ce qui
contredit la 2-connexité.

## 3. Trois triangles et un reste biparti vérifiant la condition

Supposons $q=3$ et $D=H$. Il doit y avoir exactement
deux triangles attachés, car avec zéro attache le graphe
serait disconnexe, avec un seul triangle attaché sa
coupe en étoile donnerait une coupure et avec trois on
vient d’exclure le cas. Écrivons $T_1,T_2$ pour les deux
triangles attachés et $Z$ pour le troisième.

Chacun de $T_1,T_2$ a une liaison vers $Z$. Sinon, soit
il n’a aucune liaison vers l’autre triangle attaché,
et sa coupe vers $D$ donne une coupure, soit la liaison
est du même côté et tous les triangles ne touchent
$D$ qu’en un label commun, soit elle est de côtés
opposés et le paragraphe précédent impose une liaison
depuis un sommet non attaché vers $Z$.

Fixons deux arêtes reliant $T_1,Z,T_2$ et choisissons
des sommets d’attache de $T_1$ et $T_2$ dont les labels
dans $D$ sont distincts. Il existe un tel choix,
puisque le bloc ne peut rencontrer $D$ en un seul
label. La longueur extérieure $d$ est maintenant
2, à laquelle s’ajoute un terme par triangle traversé.
Chaque terme vaut 0 si entrée et sortie coïncident
et vaut 1 ou 2 sinon. Le vérificateur énumère toutes
ces longueurs pour les deux parités et pour le cas
d’attaches opposées adjacentes.

- Du même côté de $D$, toute combinaison est interdite
  sauf si les trois termes sont nuls. En particulier,
  chaque couple de liaisons passe par le même sommet
  de $Z$. Comme chacun des deux triangles possède au
  moins une liaison, toutes les liaisons de $Z$ passent
  par ce sommet. Le retirer est une coupure.
- De côtés opposés, toute combinaison est interdite
  sauf si les trois termes sont non nuls et que les
  labels dans $D$ ne sont pas adjacents. Il en résulte
  que les ensembles de sommets de $Z$ touchés par les
  deux coupes sont disjoints. Aucune des deux coupes
  vers $Z$ ne touche un sommet qui porte une attache
  dans $D$.

Seul le deuxième cas reste à compter. Soit $A$ la
plus grande partie de $D$. Dans le triangle qui touche
$A$, choisissons un sommet $u$ lié à $Z$, donc sans
attache à $D$. Dans l’autre triangle, choisissons un
sommet d’attache $v$, donc sans voisin dans $A$ ni
dans $Z$. Il n’y a pas d’arête $uv$, car une liaison
entre côtés opposés doit passer par les sommets
d’attache. Les deux coupes vers $Z$ ont des supports
disjoints et non vides dans $Z$. Il existe donc un
sommet $w$ de $Z$ sans arête vers $u$, et sans
arête vers $v$. Le stable $A\cup\{u,v,w\}$ donne
$\alpha(B)\ge\lceil |D|/2\rceil+3$. Cela suffit si
$b\ge30$, puisque $|D|=b-9$.

Pour $25\le b\le29$, il reste le budget d’arêtes. Les
deux coupes d’attachement sont des étoiles vers des
côtés opposés. Elles ont au total au plus $|D|$ arêtes,
puisque chaque côté a au moins quatre sommets. Il y
a au plus une arête entre $T_1,T_2$ et au plus six
arêtes partant de $Z$. Chaque sommet de $Z$ ne touche
qu’un des deux triangles et y évite un sommet
d’attache. En ajoutant les neuf arêtes des triangles,
$$
e(B)\le \lfloor |D|^2/4\rfloor+|D|+16.
$$
Le contrôle entier donne au plus 136 à l’ordre 29 et
vérifie la comparaison au seuil $m_b$ aux cinq ordres.

## 4. Un ou deux triangles, avec quelques sommets du reste hors du noyau

Un chemin à extrémités distinctes dans $D$ et à sommets
intérieurs hors de $D$ est appelé ici une oreille du noyau.
Sa parité est correcte si elle est paire du même côté
et impaire de côtés opposés. Si $B$ n’est pas biparti,
il existe une oreille de parité incorrecte.

Pour voir cette dernière assertion, prenons une
composante du graphe extérieur à $D$. Si elle contient
un cycle impair, la 2-connexité et le théorème de Menger
donnent deux chemins sommet-disjoints entre ce cycle
et $D$, avec extrémités distinctes. On les arrête au
premier sommet de chaque ensemble, de façon qu’ils
n’aient aucun autre sommet du cycle ni du noyau.
Les deux arcs du cycle donnent alors deux oreilles
de parités opposées.

Si la composante extérieure est bipartie, chaque arête
d’attachement fixe l’orientation de ses deux couleurs.
Deux attaches de labels distincts imposant des
orientations incompatibles donnent une oreille incorrecte
par un chemin simple dans la composante. La composante
a au moins deux labels dans $D$, par 2-connexité.
Si les deux attaches incompatibles avaient le même
label, on les compare à une troisième de label distinct
et l’une des comparaisons donne encore une oreille
incorrecte. En l’absence de telles oreilles, toutes les
composantes se colorient de façon compatible avec $D$.

Une oreille incorrecte de longueur au plus sept forme
un $C_9$ avec un des chemins de $D$. Si le bloc a au
plus six sommets hors de $D$, toutes ses oreilles ont
cette longueur au plus. On exclut donc un bloc qui
contient un triangle. Cela couvre $q=1$ même si l’on a
retiré jusqu’à trois sommets supplémentaires de $H$
pour obtenir le noyau, et $q=2$ lorsque $D=H$.

Pour $q=2$ avec un sommet supplémentaire de $H$ en
dehors du noyau, il y a sept sommets extérieurs, dont
deux triangles disjoints. Une oreille incorrecte doit
alors avoir longueur huit, utiliser tous ces sommets
et relier des côtés opposés. On garde seulement les
arêtes du chemin et celles des deux triangles. Pour
les 70 placements des deux triangles sur les sept
positions, le vérificateur trouve un chemin simple
plus court de même parité et de longueur au plus sept.
Il suffit à fermer un $C_9$ avec le noyau.

Avec deux sommets supplémentaires de $H$ en dehors du
noyau, le même calcul réduit encore les possibilités.
À longueur neuf, les 280 placements ont une oreille
plus courte de même parité. À longueur huit, sur 280
placements, il en reste exactement douze sans
raccourci de ce type. L’oreille relie alors deux
sommets opposés non adjacents. Un des triangles occupe
trois positions consécutives. L’autre occupe deux
positions consécutives et le sommet extérieur hors de
l’oreille. Ces placements sont des conditions nécessaires
et leur prolongement reste ouvert.

## Portée et rejeu

Les coupes en étoile et les arêtes simples entre
triangles sont ainsi reliées à des contraintes
d’attachement dans le reste. Les cas certifiés
portent sur un noyau biparti satisfaisant la
condition du §1. Un reste sans triangle peut être
plus éloigné de cette condition, et l’exclusion
générale de $R_3(C_9)>33$ reste ouverte.

Après extraction du ZIP, depuis `star-cut-attachments-c9`,
exécuter
`python3 -B verify-star-cut-attachments.py | cmp - star-cut-attachments-certificate.json`.
