# Les grandes cliques de la branche du triangle

Soit $B$ un graphe 2-connexe sans $C_9$, d’ordre $b$
entre 25 et 33, et de taille au moins
$m_b=176-f(34-b)$, où $f(n)=\operatorname{ex}(n,C_9)$
et $f(0)=0$. C’est le seuil pour le grand bloc dans
[answer-7](../mono-extremal/C9-MONO-EXTREMAL.md). Dans cette
note la condition $\alpha(B)\le13$ n’est pas nécessaire.

Tout tel bloc est sans $K_7$. Il est aussi sans $K_6$ lorsque
$b\le31$. Aux ordres 32 et 33, si $K$ est une clique de taille
six, il existe un chemin de longueur trois à extrémités
distinctes dans $K$ et dont les deux sommets intérieurs sont
hors de $K$. Nous appelons un tel chemin une oreille de
longueur trois de $K$.

| Ordre $b$ | 25 | 26 | 27 | 28 | 29 | 30 | 31 | 32 | 33 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Seuil $m_b$ | 147 | 148 | 155 | 161 | 166 | 170 | 173 | 175 | 176 |
| Borne pour un bloc contenant $K_8$ | 93 | 98 | 104 | 111 | 119 | 128 | 138 | 149 | 160 |
| Borne avec un $K_7$ et sans $K_8$ | 96 | 102 | 109 | 117 | 126 | 136 | 147 | 158 | 170 |
| Borne pour un $K_6$ sans oreille de longueur trois, en l’absence de $K_7$ | 99 | 106 | 114 | 123 | 133 | 144 | 155 | 167 | 175 |

La dernière case est déduite par contradiction sous
l’hypothèse $e(B)ge176$, détaillée en section 3.

## 1. Un plus court chemin entre deux attaches

Pour une clique $K$ de taille $s$, posons $H=B-V(K)$.
Le profil d’un sommet de $H$ est l’ensemble de ses voisins
dans $K$. Deux sommets de $H$ peuvent réaliser des attaches
distinctes si l’on peut choisir un label de chaque profil
et que ces deux labels sont différents.

Supposons qu’aucun chemin de $H$ de longueur 1 à 6 ne relie
deux sommets qui peuvent réaliser des attaches distinctes.
Cette hypothèse tient pour $s=7,8$, car un tel chemin de
longueur $l$, ses deux attaches et un chemin de longueur
$7-l$ dans la clique formeraient un $C_9$. Pour $s=6$ le même
raisonnement couvre $l=2,\dots,6$. Le cas $l=1$ est
précisément l’absence d’oreille de longueur trois.

Si $H$ possède une arête, une de ses composantes possède au
moins deux sommets. Cette composante doit toucher au moins
deux sommets de $K$. Elle doit aussi rencontrer $K$ depuis
au moins deux sommets distincts de la composante. Dans le
premier cas contraire, l’unique sommet de $K$ touché serait
une coupure. Dans le second, l’unique sommet extérieur
attaché serait une coupure. Il existe donc un chemin de $H$
entre deux sommets réalisant des attaches distinctes.
Choisissons un plus court tel chemin dans tout $H$,
$P=(v_0,\ldots,v_d)$. Alors $d\ge7$.

Le chemin $P$ est sans corde. Aucun sommet intérieur de $P$
n’est attaché à $K$, car il aurait une attache différente
de l’une des extrémités choisies et fournirait un chemin
plus court. Posons $R=H-V(P)$, d’ordre $r=b-s-d-1$.
Les voisins d’un sommet $z$ de $R$ sur $P$ occupent au
plus trois positions consécutives. Sinon le détour de deux
arêtes via $z$ raccourcirait le chemin. Les attaches à $K$
resserrent cette borne.

- Un sommet avec un unique label ne peut toucher que les
  deux premières ou les deux dernières positions, selon
  l’extrémité de même label. Un voisinage plus éloigné
  raccourcit le chemin vers l’extrémité de label différent.
  Un label différent des deux étiquettes des extrémités
  ne permet aucun voisinage sur $P$.
- Un sommet avec plusieurs labels ne peut avoir aucun
  voisin sur $P$. Depuis une position voisine on rejoint
  l’extrémité la plus proche en moins de $d$ arêtes, et
  l’on peut choisir au départ un label différent de celui
  de cette extrémité.

Chaque sommet de $R$ envoie donc au plus trois arêtes
vers $P\cup K$, sauf pour les profils de taille au moins
quatre, qui envoient leurs arêtes uniquement vers $K$.
On contrôle maintenant ces profils.

## 2. Cliques de taille sept et huit

Pour $K_8$, un sommet hors de la clique ne peut avoir deux
attaches, puisqu’un chemin de longueur sept entre les
labels, plus les deux attaches, donnerait un $C_9$. Le
reste de la preuve donne
$$
e(B)\le28+d+2+3r+f(r).
$$

Pour $K_7$, supposons que deux sommets extérieurs aient
plusieurs attaches chacun. On pourrait insérer chacun
sur une arête différente d’un cycle hamiltonien de la
clique et obtenir un $C_9$, si les deux arêtes étaient
distinctes. En effet, deux arêtes distinctes de la clique
s’étendent toujours à un cycle hamiltonien. Les deux
profils doivent par conséquent être la même paire.
S’il y a plusieurs profils non simples, ils ont tous
exactement cette paire. Il reste le cas d’un seul
profil non simple, dont la taille est au plus six
puisque la branche $K_8$ est déjà exclue. Si ce sommet
est une extrémité du chemin, les extrémités envoient
au plus sept arêtes à la clique. S’il est dans $R$,
les extrémités en envoient au plus deux et il ajoute
au plus trois au budget $3r$. Dans tous les cas
$$
e(B)\le21+d+7+3r+f(r).
$$
Dans les deux formules, $e(R)\le f(r)$ vient du théorème
de Füredi et Gunderson. Le vérificateur maximise sur
$7\le d\le b-s-1$ et traite séparément $H$ sans arête,
cas où les seules contributions hors de $K$ viennent
des profils. Les bornes sont sous $m_b$ à tous les
ordres. [Théorème 1](https://arxiv.org/pdf/1310.6766#page=3).

## 3. Clique de taille six sans oreille de longueur trois

En l’absence de $K_7$, les profils ont taille au plus cinq.
Il ne peut y avoir trois profils de taille au moins quatre.
On choisirait dans les deux premiers profils deux arêtes
disjointes de la clique, puis dans le troisième une arête
distincte des deux autres. Ces trois arêtes forment une
réunion disjointe de chemins et s’étendent à un cycle
hamiltonien de $K_6$. Insérer les trois sommets extérieurs
sur ces trois arêtes donnerait un $C_9$. L’existence du
choix est aussi vérifiée dans le certificat.

Avec $P$ et $R$ comme en section 1, les profils de taille
au plus trois coûtent au plus six arêtes vers $K$ pour
les deux extrémités de $P$ et au plus trois par sommet
de $R$ vers $P\cup K$. Les deux exceptions possibles
ajoutent quatre arêtes au plus. Ainsi
$$
e(B)\le15+d+6+3r+4+f(r).
$$
L’énumération entière ne laisse que $b=33,d=7,r=19$.
Le reste $R$ doit alors avoir au moins 87 arêtes.
Le théorème d’Erdős–Gallai donne une circonférence
au moins neuf. Comme $87>(19-1)^2/4+1$, le théorème
de Brandt implique que $R$ est biparti. Sinon il
contiendrait toutes les longueurs de 3 à sa
circonférence. Ses parties ont chacune au moins
huit sommets et il manque au plus trois arêtes.
[Brandt](https://doi.org/10.1016/S0166-218X(97)00032-2) ·
[Erdős et Gallai](https://combinatorica.hu/~p_erdos/1959-10.pdf).

Dans ce reste, on peut construire un chemin de longueur
sept entre deux sommets de parties opposées et un chemin
de longueur six entre deux sommets distincts d’une même
partie. En choisissant les sommets internes, on évite
les extrémités et tout sommet incident à une arête
manquante. Il reste au moins trois sommets disponibles
dans chaque partie.

Un sommet de $P$ ne peut voir les deux parties de $R$,
car il fermerait un $C_9$ avec un chemin de longueur
sept. Si deux positions consécutives sur $P$ partagent
un voisin $z$ dans $R$, chacune a $z$ comme unique voisin
dans $R$. En effet, tout voisin additionnel serait de la
même partie que $z$, et le chemin de longueur six
fermerait un $C_9$ avec les deux attaches et l’arête de $P$.

Tout sommet $z$ de $R$ qui contribue au moins trois
arêtes vers $P\cup K$ et touche $P$ utilise deux positions
consécutives de $P$. Pour un profil vide, ses trois
voisins sur $P$ sont consécutifs. Pour un profil simple,
il utilise les deux positions à une extrémité. Ces
positions sont propres à $z$ par le paragraphe précédent.
Il y a donc au plus quatre tels sommets. Enfin il y a
au plus un profil non simple dans $R$, puisque deux tels
sommets seraient reliés par un chemin de longueur deux
ou trois et contrarieraient les attaches distinctes.
Ce profil ajoute au plus trois au budget de deux arêtes
par sommet de $R$. Au total la borne améliorée vaut
$$
15+7+10+2(19)+4+3+90=167<176.
$$

## 4. Clique de taille six avec une oreille de longueur trois

Fixons une oreille de longueur trois de la clique $K_6$.
Le graphe induit $S$ par la clique et les deux sommets
intérieurs a huit sommets. Les sommets intérieurs sont
adjacents, et les deux ensembles de leurs voisins dans
la clique sont non vides et permettent deux attaches
distinctes. Chaque ensemble a taille au plus cinq.
Leur intersection a taille au plus quatre, car sinon
leurs sommets, joints à cinq voisins communs, donnent
un $K_7$.

Le vérificateur énumère les tailles des deux ensembles
et la taille de leur intersection, qui déterminent
le graphe à permutation de la clique près. Il calcule
les longueurs de tous les chemins simples entre chaque
paire de sommets de $S$. Pour un sommet du reste $J$,
les paires autorisées dans un profil d’attachement
à $S$ sont celles dont les sommets ne sont reliés
par aucun chemin de longueur sept dans $S$.
La relation des paires autorisées est sans triangle.
Deux cas en résultent.

- Sans paire autorisée, chaque extérieur a au plus
  une attache et $e(S)\le26$.
- Avec une paire autorisée, chaque extérieur a au plus
  deux attaches et $e(S)\le22$.

Dans tout modèle $S$, chaque paire distincte est reliée
dans $S$ par des chemins de longueurs quatre et cinq.
Ainsi, dans $J$, aucun chemin de longueur deux ou
trois ne joint deux sommets permettant des attaches
distinctes à $S$. En particulier, les voisinages dans
$J$ des $d$ sommets à double attachement sont deux
à deux disjoints. Les arêtes de $J$ incidentes à
ces sommets sont au plus $r=|V(J)|$. Les deux budgets
sont donc
$$
e(B)\le26+r+f(r),\qquad
e(B)\le22+r+d+\min(f(r),\,r+f(r-d)).
$$
Ils excluent tous les ordres 25 à 30. À l’ordre 31,
le second budget impose $d\le2$. Les deux cas exigent
alors au moins 124 arêtes dans $J$, d’ordre 23.
Brandt et Erdős–Gallai donnent encore que $J$ est
biparti. Pour toute taille possible des parties, la
plus petite dépasse d’au moins deux le nombre d’arêtes
manquantes. Il existe donc un chemin de longueur deux
pour chaque paire d’une même partie et un chemin de
longueur trois pour chaque paire de parties opposées.
Toutes les attaches de sommets distincts de $J$ doivent
par conséquent être égales. Or la 2-connexité impose
au moins deux sommets de $J$ attachés à $S$ et au moins
deux labels dans $S$. Si toutes les arêtes entre
les ensembles passent par un seul sommet d’un côté,
ce sommet est une coupure. Contradiction.

## Portée et rejeu

Tout grand bloc qui reste dans la réduction contient un
triangle et a un nombre de clique au plus six. Si ce
nombre vaut six, l’ordre est 32 ou 33 et chaque clique
de taille six porte une oreille de longueur trois.
Les nombres de clique trois à cinq restent ouverts.

Le ZIP contient cette preuve et les contrôles entiers.
Après extraction, depuis `clique-ears-c9`, exécuter
`python3 -B verify-clique-ears.py | cmp - clique-ears-certificate.json`.
