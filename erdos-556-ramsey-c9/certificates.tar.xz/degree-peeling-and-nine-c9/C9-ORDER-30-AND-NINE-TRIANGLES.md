# Ordre 30 et familles de neuf triangles

Le bloc candidat $B$ de la [réduction monochrome](../mono-extremal/C9-MONO-EXTREMAL.md)
est sans $C_9$ et vérifie $\alpha(B)\le13$. À l’ordre $b$, il
doit avoir au moins $m_b=176-\operatorname{ex}(34-b,C_9)$ arêtes.
Par [answer-16](../twelve-exterior-c9/C9-TWELVE-EXTERIOR.md)
et les exclusions antérieures, $B$ ne contient aucun noyau
biparti induit d’ordre au moins $b-12$. Un noyau a deux parties
de taille au moins quatre. Il relie les paires distinctes
d’une même partie par des chemins simples de longueurs $2,4,6$
et celles de parties opposées par des chemins de longueurs
$3,5,7$.

## Deux conditions suffisantes pour les chemins du noyau

Supposons d’abord que chaque paire d’une même partie ait au
moins **trois** voisins communs. Pour un chemin pair entre
deux sommets d’une même partie, choisir jusqu’à deux sommets
internes dans cette partie, puis des voisins communs distincts
pour les paires successives.

Pour un chemin impair de $x$ à $y$ dans des parties opposées,
on prolonge un chemin pair évitant $y$ par une dernière arête
vers $y$. Pour la longueur 3 ou 5, choisir un dernier voisin
de $y$ différent de $x$ et, au besoin, un sommet intermédiaire
du côté de $x$. Il reste au moins deux candidats pour chaque
voisin commun après retrait de $y$. Pour la longueur 7, on
cherche une suite de quatre sommets distincts du côté de $x$
commençant en $x$ et se terminant en un voisin de $y$. Si $y$
n’est pas universel, on inclut un non-voisin de $y$ dans la
suite. Au moins un des trois ensembles de voisins communs
évite déjà $y$ et a donc taille au moins trois. Les deux
autres ensembles ont taille au moins deux après retrait de
$y$. Ces trois ensembles admettent des représentants
distincts.

Si $y$ est universel et qu’aucune suite de quatre sommets
ne fonctionne, les trois ensembles de voisins communs privés
de $y$ sont les mêmes deux sommets sur toute suite commençant
en $x$. En comparant les suites $(x,u,v,w)$ et $(x,v,u,w)$,
on voit que toutes les paires contenant $x$ ont le même
ensemble privé de $y$. Toute paire ne contenant pas $x$ figure
à son tour dans une suite commençant en $x$ et possède le
même ensemble. Il reste un quatrième sommet du côté de $y$.
Son degré est au moins trois par l’hypothèse sur les voisins
communs. Il appartient donc aux voisins communs d’une paire
du côté de $x$, contradiction. Cela établit le noyau.

Une seconde condition suffit quand un côté possède quatre
sommets universels, que chaque sommet de ce côté a degré
au moins deux et que chaque paire de ce côté a un voisin
commun. Pour une paire de ce côté, le voisin commun donne
la longueur 2. Pour les longueurs 4 et 6, choisir d’abord
des voisins distincts aux deux bouts, puis un ou deux
sommets universels qui ne sont pas les bouts. La longueur 6
demande en plus un troisième sommet de l’autre côté. Pour
une paire du côté opposé, utiliser jusqu’à trois sommets
universels. Entre côtés opposés, commencer par une arête
vers un sommet différent du but, puis alterner à l’aide
d’au plus trois sommets universels distincts du départ.

En particulier, pour des parties de tailles $a,c\ge4$
d’ordre total au moins 17, le graphe est un noyau si
$M\le\min(a,c)-1$ arêtes manquent et que le degré minimal
est au moins deux. En effet, si la première condition
échoue, une paire d’un côté de taille $a$ a au plus deux
voisins communs dans le côté de taille $c$. Au moins $c-2$
arêtes manquent sur cette paire, donc il en manque au plus
une sur les autres sommets de son côté. Le côté de la
paire a au moins sept sommets. Sinon $c\ge11$ et
$c-2>M$. Le côté de la paire possède donc au moins quatre
sommets universels. Les deux sommets de chaque paire
gardent un voisin commun puisque $M<c$. La seconde
condition s’applique. Le cas $M\le\min(a,c)-2$ garantit
déjà le degré minimal deux.

## Retraits successifs à l’ordre 30

On retire un sommet de degré minimal à chaque étape.
Soit $H_n$ le graphe induit obtenu à l’ordre $n$.
À partir de 170 arêtes à l’ordre 30, les minorants
indiqués ci-dessous dépassent toujours $4(n-1)$.
La circonférence est donc au moins 9 par Erdős–Gallai.
Tant que $H_n$ est non biparti, Brandt–Faudree–Goddard
impose $\delta(H_n)\le\lfloor(n+1)/3\rfloor$ sous peine
de contenir toutes les longueurs de sa maille (3 ou 4)
à sa circonférence. Le minorant suivant s’obtient en
retranchant ce plafond. [Erdős–Gallai](https://web.vu.lt/mif/s.jukna/tropical/Erdos-Gallai-1959.pdf),
[Brandt–Faudree–Goddard, théorème 1.7](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf#page=5).

### Jusqu’à 20 sommets

Dans tout $H_n$ biparti, les deux parties ont taille
au plus 13. Pour calculer le plafond d’arêtes à tailles
fixées sans noyau induit d’ordre au moins 18, on utilise
le produit des tailles si une partie a moins de quatre
sommets ou si l’ordre est inférieur à 18. Sinon l’absence
de noyau force au moins $\min(a,c)-1$ arêtes manquantes.
Elle donne aussi une paire du même côté avec au plus
deux voisins communs, donc un sommet de degré au plus
$\lfloor(c+2)/2\rfloor$ dans ce côté, ou
$\lfloor(a+2)/2\rfloor$ dans l’autre côté.

On retire ce sommet et on récurre. Si le graphe obtenu
a encore des parties d’au moins quatre sommets, un ordre
d’au moins 18 et un degré minimal au moins deux, il lui
manque au moins le minimum des deux tailles. S’il a un
sommet de degré 0 ou 1, le graphe parent avait un sommet
de degré au plus 2, que l’on peut retirer à la place.
Les deux orientations de retrait sont prises en compte.
On maximise sur ces possibilités, puis on prend le
minimum avec le plafond global du nombre d’arêtes
manquantes.

| $n$ | Minorant d’arêtes | Plafond biparti |
|---:|---:|---:|
| 30 | 170 | Impossible par les tailles des parties |
| 29 | 160 | Impossible par les tailles des parties |
| 28 | 150 | Impossible par les tailles des parties |
| 27 | 141 | Impossible par les tailles des parties |
| 26 | 132 | 124 |
| 25 | 123 | 117 |
| 24 | 115 | 110 |
| 23 | 107 | 103 |
| 22 | 99 | 96 |
| 21 | 92 | 90 |
| 20 | 85 | 84 |

### À 19 sommets

Supposons $H_{19}$ biparti. Il possède au moins 78 arêtes.
Avec un degré minimal d’au moins 6, il contient un noyau
induit d’ordre au moins 18, comme suit.

- Pour $(6,13)$, le graphe est complet. Pour $(7,12)$,
  il manque au plus six arêtes. Les paires du côté de
  taille 7 gardent au moins six voisins communs. Du
  côté de taille 12, elles en ont au moins $12-7=5$
  par la borne de degré minimal.
- Pour $(8,11)$, il manque au plus dix arêtes et les
  paires du côté de taille 11 ont au moins quatre
  voisins communs. S’il y a une paire du côté de taille
  8 avec au plus deux voisins communs, elle concentre
  au moins neuf arêtes manquantes. Retirer un membre de
  cette paire. L’autre membre partait avec au plus cinq
  arêtes manquantes, et il en manque au plus une
  ailleurs de son côté. Toutes les paires gardent au
  moins trois voisins communs après le retrait.
- Pour $(9,10)$, un couple déficient $u,v$ ne peut se
  trouver que dans le côté de taille 9. Chacun des deux
  sommets a degré 6 et les deux ensembles de quatre
  voisins manquants sont disjoints. Il manque au plus
  quatre arêtes ailleurs de ce côté. Si ces quatre
  pertes ne sont pas toutes sur un même troisième
  sommet $w$, retirer $u$ suffit pour donner trois
  voisins communs à toute paire de ce côté. Si $w$ porte
  les quatre pertes, son ensemble de pertes ne peut
  être disjoint des deux ensembles de $u,v$. En gardant
  le membre dont l’ensemble rencontre celui de $w$,
  on obtient le même résultat. Avant retrait, les
  paires du côté de taille 10 ont au moins trois voisins
  communs. Celles qui en ont exactement trois ont six
  sommets non communs dans le côté de taille 9. Au
  plus quatre de ces sommets se trouvent hors de $u,v$,
  donc ni $u$ ni $v$ n’était un voisin commun. Le retrait
  conserve au moins trois voisins communs pour toutes
  les paires de ce côté également.

S’il n’y a pas de paire déficiente dans les deux derniers
cas, $H_{19}$ lui-même est un noyau. Par conséquent
l’hypothèse bipartie exigerait $\delta(H_{19})\le5$. Le
sommet retiré de $H_{20}$ avait degré minimal, donc au
plus $\delta(H_{19})+1\le6$. Il reste alors au moins
$85-6=79$ arêtes. Un nouveau retrait d’un sommet de degré
au plus 5 **dans ce graphe biparti hypothétique** donnerait
un graphe biparti de 18 sommets et au moins 74 arêtes.
Chaque bipartition admissible manque alors au plus
$\min(a,c)-2$ arêtes et donne un noyau interdit. Ainsi
$H_{19}$ est non biparti.

### À 18 sommets

Si $H_{18}$ est biparti, il a au moins 72 arêtes, donc
au plus $\min(a,c)$ arêtes manquantes. Supposons que son
degré minimal soit au moins 5. Pour les tailles $(6,12)$
et $(7,11)$, la condition avec au plus $\min(a,c)-1$
pertes s’applique. Pour $(8,10)$ et $(9,9)$, une paire
déficiente laisse au plus deux pertes hors de ses deux
sommets et fournit ainsi au moins quatre sommets universels
de son côté. Aucune paire n’a des voisinages disjoints.
Le contraire concentrerait au moins la taille du côté
opposé en arêtes manquantes et force les deux degrés à
s’additionner en au plus 9, puisque les pertes totales
sont au plus $\min(a,c)\le9$. La seconde condition
s’applique. Le graphe biparti hypothétique a donc
$\delta(H_{18})\le4$.

Le dernier sommet retiré de $H_{19}$ avait degré au plus 5,
et il reste au moins $78-5=73$ arêtes. La borne des pertes
passe à $\min(a,c)-1$. Sans noyau il faut donc
$\delta(H_{18})\le1$. En revenant de nouveau au retrait
depuis $H_{19}$, il reste au moins $78-2=76$ arêtes.
Cette fois il manque au plus $\min(a,c)-2$ arêtes,
contradiction. Ainsi $H_{18}$ est non biparti.

### À 17 sommets

Il reste au moins 66 arêtes. Si $H_{17}$ est non biparti,
le plafond de Brandt est 65, et la circonférence est au
moins 9 puisque $66>4(17-1)=64$. L’article de Brandt donne
donc un $C_9$. [Brandt](https://www.sciencedirect.com/science/article/pii/S0166218X97000322).

Si $H_{17}$ est biparti, les seules tailles possibles
sont $(6,11),(7,10),(8,9)$, avec au plus 0, 4 ou 6 arêtes
manquantes. Chaque cas satisfait la condition du noyau.
Le sommet retiré de $H_{18}$ ne peut toucher les deux
parties de ce noyau. Un chemin de longueur 7 entre ses
deux attaches fermerait un $C_9$. Il est donc possible de
prolonger cette bipartition à $H_{18}$, déjà établi non
biparti. Les deux branches sont contradictoires.
L’ordre 30 est exclu pour tout nombre de triangles.

## Neuf triangles aux ordres 31 et 32

Le vérificateur réutilise les bornes et les placements
d’[answer-23](../nine-triangles-c9/C9-NINE-TRIANGLES.md).
Il classe les restes de quatre et cinq sommets et les
complète par des sommets fictifs isolés pour utiliser
les mêmes vingt projections. Tout profil où un sommet
fictif touche un triangle est supprimé avant le calcul.
Dans une réalisation, ses comptes de marques sont
donc nécessairement nuls. Il ne contribue à aucun
chemin ni à aucune attache. Les bornes du graphe
d’étoiles prises sur les sous-ensembles de sommets
réels restent applicables. Les termes supplémentaires
avec des sommets fictifs bornent le même graphe après
ajout de sommets isolés. Le seuil comparé est propre
à chaque ordre.

| Ordre | Graphes résiduels à isomorphisme près | Majorant total | Seuil |
|---:|---:|---:|---:|
| 31 | 7 | 172 | 173 |
| 32 | 14 | 174 | 175 |

## Cas qui restent ouverts

Les ordres possibles sont 31, 32 et 33, avec au plus huit
triangles sommet-disjoints. Le certificat répertorie les
douze couples avec cinq à huit triangles et l’ordre de
leur reste sans triangle. Il fournit aussi les plafonds
bipartis pour les couples avec au plus quatre triangles
en appliquant la récurrence ci-dessus avec le seuil de
noyau $b-12$.

Pour $(31,1),(32,1),(33,1),(33,2)$, le reste dépasse 26
sommets et ne peut être biparti. Il est sans triangle par
maximalité de la famille et doit contenir un cycle impair.
La seule borne d’indépendance n’impose pas que ce cycle
ait longueur cinq. Le cas général de $C_9$ reste ouvert.

## Rejeu

Avec Python 3 et un compilateur C++17, depuis le dossier
de ce document dans le ZIP extrait

~~~sh
python3 -B verify-degree-peeling-and-nine.py | cmp - order30-and-nine-certificate.json
~~~
