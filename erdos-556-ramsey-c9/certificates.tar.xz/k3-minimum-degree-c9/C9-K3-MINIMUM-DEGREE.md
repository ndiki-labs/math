# Dernière branche et preuve de (R_3(C_9)=33)

Soit (H) un contre-exemple d’ordre minimal à la borne de
densité d’[answer-47](../hereditary-density-c9/C9-HEREDITARY-DENSITY.md).
Il a (23\le n\le33), est 3-connexe et sans (C_9), avec
(delta(H)\ge8) et (e(H)\ge7n-55). Les acquis 48 à 50
imposent (omega(H)=3). Nous excluons ce dernier cas.

Fixons un triangle (T) et posons (R=H-V(T)). Comme (H)
est sans (K_4), chaque sommet de (R) a au plus deux voisins
dans (T). Par conséquent (delta(R)\ge6). Par le comptage
des retraits d’answer-49, la coupe (e(T,R)\ge19). Un sommet
de (R) est dit marqué s’il touche (T), et ses marques
sont ses voisins dans (T). Deux sommets peuvent choisir des
marques distinctes si les deux ensembles sont non vides
et leur réunion contient au moins deux labels.

Une oreille sur (T) relie des labels distincts par une
voie dont tous les sommets intérieurs sont dans (R).
Les oreilles de longueurs 7 et 8 sont interdites, car elles
se ferment grâce à un chemin complémentaire dans (T).
On classe par la plus grande longueur d’oreille présente
parmi 3, 4, 5 et 6. Si aucune n’existe, on traite le cas
directement à la fin.

Pour tout noyau induit (S) à huit sommets, le nombre
d’arêtes incidentes est au moins (L(n)), avec (L(23)=49),
(L(24)=56), et (L(n)=57) ensuite. C’est la même borne
par retraits qu’aux acquis 49 et 50. Tout sommet de (S)
doit avoir un voisin dans (W=H-S).

## Tests finis, communs aux quatre longueurs

Le recensement du noyau utilise le triangle et les sommets
intérieurs ordonnés d’une oreille, avec toutes les cordes
possibles. On trie les trois masques de contacts des labels
du triangle. S’il manque des sommets pour atteindre huit,
on choisit librement des voisins extérieurs d’un sommet
intérieur distingué. On conserve toutes leurs attaches,
y compris entre les voisins ajoutés. Le degré minimal 8
garantit assez de voisins pour ces choix. Les noyaux qui
contiennent (K_4) ou une oreille explicitement absente
dans la branche sont éliminés.

Pour chaque forme, le programme calcule les longueurs des
chemins simples dans (S) par deux méthodes indépendantes.
Comme dans answer-50, un profil (Psubseteq S) de sommet
de (W) ne peut contenir deux labels joints dans (S)
par un chemin de longueur 7. Un chemin extérieur de
longueur (d) entre deux profils ne peut pas se coupler
à un chemin dans (S) de longueur (7-d). Ces règles
sont nécessaires. Le programme rejette aussi les profils
qui donnent (K_4) ou une oreille absente de la branche.

Soit (c) la taille maximale d’un profil dans le domaine.
Pour un sommet de profil (P), dont les voisins dans (W)
ont tous des profils de taille au plus (c_P), le sommet
et son voisinage imposent un déficit d’au moins
[
c-|P|+(8-|P|)(c-c_P)
]
par rapport au plafond (c|W|) de la coupe. On peut retirer
un profil si ce seul déficit suffit à empêcher d’atteindre
(L(n)), aux onze ordres. On peut aussi faire la somme de
ces déficits minimisés pour des labels dont les voisinages
fermés extérieurs sont disjoints. Un label (i) visible
par des profils de taille au plus (m_i) exige un tel
voisinage d’au moins (9-m_i) sommets. Ces règles reprennent
answer-50.

Pour le test des familles de profils, deux profils
multiples distincts ne coexistent que si leur ajout à
(S), sans arête entre les deux nouveaux sommets, évite
les interdictions. On parcourt les cliques maximales du
graphe de coexistence entre types multiples, en ajoutant
les profils vides et simples à chaque famille. Toute
famille réelle est contenue dans une famille ainsi
parcourue. Les contraintes de distance 1 à 4 sont testées
en ajoutant les deux sommets avec leurs profils et un
chemin simple de la longueur prescrite. Les sommets
intermédiaires sont seulement munis des arêtes de ce
chemin. Une interdiction dans le graphe ainsi construit
vaut dans n’importe quel prolongement.

## Oreilles de longueurs 6 et 5

Pour la longueur 6, le triangle et l’oreille ont huit
sommets. Sur 43 590 noyaux, il reste 128 formes après les
premiers plafonds. Pour la longueur 5, on ajoute un
voisin extérieur arbitraire du deuxième sommet intérieur
de l’oreille. Parmi 3 999 noyaux, neuf passent les premiers
tests. Dans ces neuf formes, le voisin ajouté a pour
seul voisin dans le noyau initial le sommet dont il a
été choisi voisin. Cette restriction vaut donc aussi
pour tous les autres voisins extérieurs de ce sommet.

Sur chacun de ces noyaux, le contrôle garantit que les
profils de taille au moins trois sont séparés par
distance au moins cinq dans (W), puisque toutes les
longueurs 1 à 4 sont interdites entre eux. Leurs contacts
au premier et au deuxième pas extérieur ont au plus
deux labels. Pour un sommet portant un profil élevé,
choisissons un voisin (y) dans (W). Le sommet, (y)
et tous les autres voisins de (y) constituent une
région d’au moins huit sommets dans la boule de rayon
deux. Les régions sont disjointes. Il y a donc au plus
trois profils élevés dans (W), qui compte au plus
25 sommets.

Pour un profil de taille quatre, (y) et tous ses
autres voisins ont le profil vide. Sa région perd
au moins 16 attaches, tandis que le profil initial
en gagne deux au-dessus du plafond de deux. Les autres
profils de taille trois en gagnent au plus une chacun.
En présence d’un profil de taille quatre, la coupe
a donc au plus (2|W|-12) arêtes. Le programme compare
ce plafond à (L(n)-e(S)) aux onze ordres et supprime
tous les profils de taille quatre.

Pour un profil de taille trois (P), si les maxima
à distance un et deux valent (c_1,c_2\le2), sa région
contribue, par rapport à deux attaches par sommet, au
plus
[
1+(c_1-2)+(7-c_1)(c_2-2).
]
En effet, si (y) a (j\le c_1) attaches, au moins
(7-j) autres sommets de la région ont au plus
(c_2) attaches. Le membre de droite est le maximum
de cette borne pour (j\le c_1). Si un profil de
taille trois est présent, on additionne sa borne
et au plus deux contributions supplémentaires,
bornées par le plus grand excédent positif. Cela
donne une coupe nécessaire pour chaque profil de
taille trois individuellement. En réitérant les
suppressions puis en utilisant les familles de
coexistence, on ferme les deux longueurs. À la
longueur 6, les onze derniers noyaux représentent
217 familles. Les neuf noyaux de longueur 5 sont
écartés par suppression des profils nécessaires.

## Oreille de longueur 4

On ajoute deux voisins extérieurs arbitraires du
sommet intérieur central (v). Sur 1 021 noyaux,
17 passent les premiers tests. Leurs deux voisins
ajoutés touchent uniquement (v) dans le noyau
initial. Comme le choix des deux était arbitraire
et qu’il y en a au moins deux, cette condition
vaut pour tous les voisins extérieurs de (v).
Les quatre formes où les deux voisins ajoutés
sont adjacents sont exclues par les familles de
coexistence. Par conséquent, tous les voisins
extérieurs du milieu forment un stable. On impose
aux profils de (W) qui touchent (v) de ne voir
ni les autres labels du noyau initial ni les deux
voisins ajoutés. Les treize formes restantes sont
alors exclues par le test des familles.

## Oreille de longueur 3

On a une arête (xy) dans (R) entre deux sommets
qui ont des marques distinctes disponibles. On
ajoute trois voisins arbitraires de (x) hors de
(T\cup\{x,y\}), ce qui est possible par le degré
minimal. Sur les 54 noyaux, 42 passent les plafonds
initiaux. Chaque voisin ajouté y touche uniquement
(x) dans le noyau initial. En inversant l’orientation
de l’oreille, la même propriété vaut pour les
voisins de (y). Donc
[
X=N_R(x)\setminus\{y\},\qquad Y=N_R(y)\setminus\{x\}
]
sont disjoints et sans marques. Ils ont chacun au
moins cinq sommets. Aucune arête ne relie (X) et
(Y), sinon (x-X-Y-y) est un chemin de longueur
trois dans (R), qui donne une oreille de longueur 5.

Plus généralement, soit (Z) l’ensemble des sommets
sans marque, et (D) celui des sommets doublement
marqués. Dans cette branche et dans le cas sans
oreille courte, il n’y a pas de chemin de longueur
2 à 6 entre sommets pouvant choisir des marques
distinctes. Un (a\in D) a au plus un voisin dans
(D), et au moins six dans (R). Choisissons un
voisin (b\notin D). Le voisinage de (b) dans
(R), hors de (a), a au moins six sommets et est
inclus dans (Z). Ces réserves sont disjointes
pour différents (a), car toute intersection
donnerait un chemin de longueur 4 ou un voisin
(b) commun de longueur 2. Donc (|Z|\ge6|D|).
Le degré de coupe donne
[
19\le |R|-|Z|+|D|\le30-5|D|.
]
Ainsi (|D|\le2) et (|Z|\le13).

Un sommet (z\in X) ne peut toucher un autre
sommet marqué que (x). Pour un marqué (w)
distinct de (x,y), le chemin (x-z-w) interdit
toute paire de marques distinctes. Si (x,w) ont
exactement la même marque unique, alors
(y-x-z-w) est interdit. Enfin (z) ne touche
pas (y) par la pureté établie ci-dessus.
Par conséquent (z) a au moins sept voisins
dans (Z\setminus Y). Cela donne
(|Z|\ge |Y|+8\ge13). Symétriquement
(|Z|\ge |X|+8). Comme (|Z|\le13), l’égalité
impose (|X|=|Y|=5) et tout (z\in X) touche les
sept autres sommets de (Z\setminus Y). En
particulier (X) est une clique, contradiction.

## Aucune oreille de longueur 3 à 6

Chaque composante de (R) touche les trois sommets
de (T), sinon au plus deux sommets sépareraient
cette composante de (T). Une composante a au
moins deux sommets, par (delta(R)\ge6), et au
moins deux de ses sommets touchent (T), car un
unique sommet attaché serait un séparateur.
Il existe donc un chemin dont les extrémités
peuvent choisir deux marques distinctes.
Choisissons-en un de longueur minimale (d).
On a (d\ge7), puisque les longueurs 1 à 6
sont interdites dans cette branche.

Le chemin est sans corde. Tous ses sommets
intérieurs sont dans (Z), sinon une marque
intérieure ferait un chemin plus court avec au
moins une des extrémités. Un sommet extérieur
au chemin ne peut voir plus de trois positions,
sous peine de le raccourcir par un détour
deux arêtes. Aucun sommet marqué extérieur ne
peut voir les positions 2 à (d-2), numérotées
à partir de 0. Depuis une de ces positions, les
deux extrémités sont joignables en moins de (d)
arêtes à partir de ce sommet extérieur. Une
extrémité fournit une marque distincte de l’une
des siennes. Chacune des (d-3) positions
centrales exige au moins six voisins parmi les
sommets de (Z) hors du chemin, par le degré
minimal 8 et l’absence de corde. Il y a au plus
(13-(d-1)=14-d) de ces sommets. L’inégalité
(6(d-3)\le3(14-d)) est impossible pour (d\ge7).

## Composition de la borne de Ramsey

La dernière branche de la réduction d’answer-47 est
ainsi fermée. Les acquis utilisés pour remonter au
coloriage sont les suivants.

1. Answer-33 donne (alpha\le12) pour chaque
   couleur d’un coloriage sans (C_9) monochromatique.
   Une couleur possède au moins (\binom{33}{2}/3=176)
   arêtes.
2. Answer-7 impose un bloc d’ordre au moins 25.
   Les exclusions d’ordres des acquis 19, 22, 24
   et 27 laissent les ordres 32 et 33. Leurs seuils
   sont 175 et 176, respectivement.
3. Answer-11 et answer-35 donnent, dans ce bloc,
   l’absence de (K_6) et de (K_{4,4}) induit.
   Le bloc est un contre-exemple à la borne
   (T(32)=168), (T(33)=175) d’answer-47 dans la
   classe héréditaire. On prend un contre-exemple
   minimal dans cette classe, en considérant les
   ordres 16 à 33. Answer-47 impose l’ordre au
   moins 23, la 3-connexité et le degré minimal 8.
4. Les acquis 47 à 50 imposent (omega=3) pour
   ce contre-exemple. La preuve ci-dessus l’exclut.
   La borne supérieure (R_3(C_9)\le33) suit.

Pour la borne inférieure, partitionner (K_{32}) en
quatre blocs de huit sommets. La première couleur
est interne aux blocs. La deuxième relie les deux
blocs de chaque moitié, et la troisième relie les
deux moitiés. Les composantes de la première couleur
ont huit sommets et les deux autres couleurs sont
biparties. Il n’y a donc aucun (C_9)
monochromatique. En combinant les deux bornes, on
obtient (R_3(C_9)=33). Dans le problème #556 sur
tous les ordres, cette conclusion règle le cas
(C_9).

## Rejeu

Le ZIP contient la preuve de la dernière branche
et son vérificateur exact. La composition de la
borne s’appuie sur les résultats précédents du
même run. Depuis le dossier de la preuve dans le
ZIP extrait, avec Python 3 et un compilateur C++20.

```sh
python3 -B verify-k3-minimum-degree.py | cmp - k3-minimum-degree-certificate.json
```
