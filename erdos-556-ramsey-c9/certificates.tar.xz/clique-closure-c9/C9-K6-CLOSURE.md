# Exclusion du K₆ aux ordres 32 et 33

Soit $B$ un bloc 2-connexe sans $C_9$, de taille $b\in\{32,33\}$,
qui atteint le seuil $m_b=176-f(34-b)$ avec
$f(n)=\operatorname{ex}(n,C_9)$ et $f(0)=0$. Les valeurs de $m_b$
sont 175 et 176. Selon [answer-10](../clique-ears-c9/C9-CLIQUE-EARS.md),
$B$ ne contient pas de $K_7$ et chaque hypothétique $K_6$ possède
un chemin de trois arêtes à extrémités distinctes dans la clique
et à sommets intérieurs en dehors. Nous l’appelons une oreille.
On montre que cette branche est impossible. La preuve locale
emploie la 2-connexité et les seuils, sans hypothèse d’indépendance.

## 1. Spectre des chemins dans la clique et une oreille

Fixons une clique $K$ de taille six et une première oreille.
Le graphe induit $S$ sur ses huit sommets est déterminé par les
deux tailles $a,b'$ des voisinages des sommets intérieurs dans
$K$, et la taille $c$ de leur intersection. Le vérificateur
reprend les formes de answer-10 et calcule toutes les longueurs
de chemins simples entre chaque paire distincte de sommets de $S$.

Pour deux labels distincts de $S$, un chemin de longueur $d$
dans $B-S$ entre des sommets attachés à ces labels formerait un
$C_9$ s’il existe dans $S$ un chemin de longueur $7-d$ entre les
labels. Le cas $d=0$ correspond à un sommet ayant deux attaches.
Voici les résultats du contrôle exact.

- Les paires compatibles avec $d=0$ n’ont pas de triangle.
  Chaque sommet extérieur envoie donc au plus deux arêtes vers $S$.
- Aucun $d=2,3,4$ n’est compatible.
- Quand $d=5$ est possible, $e(S)\le22$.
- Le cas $d=1$ n’est possible que pour les formes
  $(a,b',c)=(1,1,0),(1,2,1),(2,2,2)$.
  Dans chacune il n’existe qu’une paire compatible, $\{x,y\}$,
  et les deux sommets de l’oreille n’ont dans $K$ que des voisins
  dans $\{x,y\}$, leur union étant $\{x,y\}$.

## 2. Agrandir le noyau quand il subsiste une arête extérieure

S’il existe dans $B-S$ une arête entre deux sommets réalisant
des attaches distinctes à $S$, ces deux attaches sont donc $x$
et $y$. Chacun des deux sommets n’a dans $S$ que des attaches
dans $\{x,y\}$. Une autre attache donnerait une seconde paire
distincte pour $d=1$. On obtient alors une seconde oreille sur
la même paire de sommets de $K$.

Appelons famille attachée à $\{x,y\}$ un ensemble d’oreilles
dont les arêtes intérieures sont deux à deux disjointes en
sommets. Chaque arête intérieure a des extrémités dont les
voisinages dans $K$ sont des sous-ensembles non vides de
$\{x,y\}$ qui couvrent la paire. Il n’existe aucune arête
entre les sommets intérieurs de deux oreilles différentes.
En effet, supposons une telle arête $uv$. Depuis $u$ on
rejoint en deux arêtes une attache de son partenaire.
Depuis $v$ on rejoint l’autre attache en une ou deux arêtes,
car son oreille couvre les deux labels. Ces trajets et
l’arête $uv$ donnent une oreille sur $K$ de longueur quatre
ou cinq. Tout tel chemin ferme un $C_9$ avec un chemin de
longueur complémentaire dans $K$.

Pour $t\ge2$ oreilles, le graphe induit $S_t$ sur leur réunion
avec $K$ a donc $6+2t$ sommets et au plus $15+5t$ arêtes.
Il conserve les propriétés suivantes.

- Tout couple de labels distincts est relié par des chemins
  de longueurs quatre et cinq.
- Tout couple de labels distincts autre que $\{x,y\}$
  est aussi relié par un chemin de longueur six.
- Les seules paires qui peuvent manquer un chemin de longueur
  sept sont $\{x,y\}$ et des paires entre un label de $\{x,y\}$
  et un sommet intérieur d’oreille. Un sommet intérieur ne
  peut manquer ce chemin vers les deux labels $x,y$ à la fois.

Pour les vérifier, il suffit de prendre la clique et deux
oreilles. Si les deux labels sont dans des oreilles différentes,
on prend ces deux oreilles. Sinon on en complète une par une
autre quelconque. Le vérificateur contrôle les 49 choix ordonnés
des deux profils, et toutes les paires. Les chemins ainsi trouvés
restent présents dans $S_t$. Les trois conclusions interdisent
respectivement les longueurs extérieures 2 et 3, limitent la
longueur extérieure 1 à $\{x,y\}$ et imposent au plus deux
attaches à $S_t$ par sommet extérieur.

On agrandit la famille tant qu’une arête du reste réalise
deux attaches distinctes. Elle doit encore réaliser la paire
$\{x,y\}$ et n’avoir d’autres attaches ni à la clique ni aux
oreilles antérieures, d’après la deuxième propriété. Le
procédé se termine par un $S_t$ sans arête extérieure de
ce type. Si la première oreille ne permettait déjà aucune
telle arête, on s’arrête simplement avec $t=1$.

## 3. Comptage dans le reste

Notons $h=b-|V(S_t)|$ et supposons que le reste possède
une arête. Dans toute composante extérieure d’au moins
deux sommets, la 2-connexité impose deux attaches distinctes
dans $S_t$ et deux sommets extérieurs attachés distincts.
Sinon un unique sommet d’un côté serait une coupure.
On peut donc choisir un plus court chemin $P$ dans le reste
entre deux sommets permettant des attaches distinctes.
Sa longueur $d$ est au moins cinq pour $t=1$, et au moins
quatre pour $t\ge2$.

Comme dans answer-10, $P$ est sans corde et ses sommets
intérieurs n’ont pas d’attache à $S_t$. Pour chaque sommet
du reste $R$ après retrait de $P$, les voisins sur $P$ occupent
au plus trois positions consécutives. Avec une attache
unique, les positions disponibles se réduisent aux deux
premières ou aux deux dernières. Avec deux attaches,
aucune position de $P$ n’est permise, car on pourrait
rejoindre l’extrémité la plus proche en moins de $d$ arêtes
avec des labels distincts. Ce dernier argument vaut pour
$d\ge4$. Si $r=h-d-1$, le décompte donne
$$
e(B)\le e(S_t)+d+4+3r+f(r).
$$
Pour $t=1$ avec un seul label possible par sommet extérieur,
on remplace le 4 par 2. Si le reste avant retrait est
sans arête, on compte simplement $e(S_t)+2h$.

Pour $t\ge2$, le maximum entier est 156 à l’ordre 32 et 168
à l’ordre 33, strictement sous les seuils. Pour $t=1$ le
cas $d\ge6$ est aussi exclu. À $d=5$ le contrôle des formes
donne $e(S)\le22$ et le seul cas qui nécessite un raffinement
est $b=33$, avec $r=19$ et $e(R)\ge88$.

Ce reste à 19 sommets est biparti. Avec au moins 88 arêtes,
le théorème d’Erdős–Gallai donne une circonférence au moins
neuf, et le théorème de Brandt imposerait un $C_9$ s’il
était non biparti, comme dans answer-10. Ses parties ont
taille au moins huit et il manque au plus deux arêtes entre
elles. Il y a un chemin simple de longueur sept entre
côtés opposés et un chemin de longueur six entre deux
sommets d’un même côté. Pour construire ces chemins, on
choisit les sommets internes en dehors des extrémités et
des sommets incidents aux arêtes manquantes.

Un sommet de $P$ ne peut voir les deux côtés, et deux
positions consécutives de $P$ qui partagent un voisin
dans $R$ ne peuvent voir un autre sommet de $R$. Dans
le premier cas un chemin de longueur sept fermerait un
$C_9$. Dans le second cas on le ferme avec un chemin de
longueur six et l’arête entre les positions. Par conséquent,
chaque sommet de $R$ qui envoie trois arêtes à $S\cup P$
occupe deux positions consécutives qui lui sont propres.
Il y a au plus trois tels sommets car $P$ a six sommets.
On remplace donc $3r$ par $2r+3$ dans la borne, qui tombe
au plus à 162 dans chacun des cas où ce raffinement est
nécessaire. Le vérificateur rejoue l’ensemble des inégalités.

## Conclusion et rejeu

Combiné à answer-10, le résultat exclut tout $K_6$ du grand
bloc aux neuf ordres. Les nombres de clique restants sont
3, 4 et 5. Une oreille de référence peut coexister avec
d’autres oreilles de longueur trois sur la même paire.
Le raisonnement ci-dessus contrôle leur union par la densité
du reste et la 2-connexité.

Après extraction du ZIP, depuis le dossier
`clique-closure-c9`, exécuter
`python3 -B verify-clique-closure.py | cmp - clique-closure-certificate.json`.
