# Triangles disjoints et existence d’un noyau biparti

Soit $B$ un bloc de la
[réduction d’Erdős #556](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est 2-connexe, non biparti, sans $C_9$, d’indépendance au plus 13,
d’ordre $25\le b\le33$, et satisfait
$e(B)\ge m_b=176-\operatorname{ex}(34-b,C_9)$.
Il contient un triangle et $\omega(B)\le5$.
Un noyau désigne ici un sous-graphe biparti induit dont les deux parties
ont au moins quatre sommets. Il doit relier chaque paire distincte
d’une même partie par des chemins simples de longueurs $2,4,6$ et
chaque paire de parties opposées par des chemins de longueurs $3,5,7$.

## 1. Un noyau maximal perd des arêtes à chaque grande attache

Si un noyau existe, choisissons-en un maximal pour l’inclusion, avec
parties $A,C$ de tailles $a,c$. Un sommet extérieur ne touche qu’une
partie, puisque deux attaches sur des parties opposées ferment un
$C_9$ avec un chemin de longueur 7 dans le noyau.

Une partie de taille 13 impose à chaque sommet extérieur au moins
un voisin dans cette partie, par $\alpha(B)\le13$. Si deux sommets
extérieurs sont adjacents, ils ont nécessairement la même attache
unique. Deux attaches distinctes ferment un $C_9$ avec un chemin
interne de longueur 6. Toute composante extérieure contenant une
arête ne toucherait donc le noyau qu’en un sommet, ce qu’interdit la
2-connexité. Le reste est alors indépendant et $B$ est biparti, une
contradiction. Il suffit de traiter $4\le a\le c\le12$.

Soit $M$ le nombre d’arêtes manquantes de $A$ à $C$ et soient
$s=\max_{v\in C}(a-d(v))$ et $t=\max_{u\in A}(c-d(u))$, avec les
degrés pris dans le noyau. Chaque sommet du noyau a degré au moins
deux, car il faut un chemin de longueur 3 vers chaque sommet du
côté opposé, y compris vers un voisin du sommet de départ. Ainsi $s\le a-2$ et $t\le c-2$. Une ligne de $s$
pertes et une colonne de $t$ pertes se recouvrent en au plus une
arête, d’où
$$
\max(s,t,s+t-1)\le M\le\min(cs,at).
$$

Si un sommet extérieur $w$ a au moins deux voisins dans $A$ et
partage un voisin avec chaque sommet de $C$, on peut l’ajouter à $C$.
Vers un sommet $u\in A$, on choisit un voisin de $w$ distinct de $u$
et on préfixe aux chemins internes de longueurs $2,4,6$ l’arête issue
de $w$. Vers un sommet $v\in C$, le voisin commun donne la longueur
2 et les chemins internes de longueurs 3 et 5 préfixés donnent les
longueurs 4 et 6. Les anciens chemins sont conservés. Par maximalité,
tout $w$ ayant plusieurs voisins dans $A$ doit donc avoir son
voisinage disjoint de celui d’au moins un $v\in C$. Il a au plus $s$
attaches. L’argument symétrique donne $t$ pour une grande attache à
$C$. Si les deux classes de sommets à attaches multiples ont des tailles
$x,y$, leur contribution aux arêtes du noyau et à ses attaches est
majorée par
$$
ac+xs+yt-\max(s,t,s+t-1).
$$
Il reste à compter les attaches uniques et les arêtes extérieures.

### Majorants pour les arêtes extérieures

Notons $R_A,R_C,Z$ les sommets touchant $A$, touchant $C$, ou sans
attache. Les tailles dans $R_A$ sont $x,i,p$ pour les sommets à
attaches multiples, ceux à attache unique isolés dans $R_A$, et les
autres. Les tailles dans $R_C$ se notent $y,j,q'$. Posons $z=|Z|$
et $r=|R_A|+|R_C|+z$. La lettre $q'$ concerne ici les attaches,
et non le nombre de triangles de la section suivante. Soit
$F(n)=\operatorname{ex}(n,C_9)$.

- Toute arête interne à une classe $R_A$ ou $R_C$ relie deux
  sommets qui ont la même attache unique. Ainsi
  $x+i+\mathbf 1_{p>0}+c\le13$ et
  $y+j+\mathbf 1_{q'>0}+a\le13$. Les groupes d’un même label ne
  contiennent pas de chemin sur huit sommets, qui se fermerait en
  $C_9$ par ce label. Le théorème d’Erdős–Gallai
  majore leurs arêtes en somme par $3p$ et $3q'$.
  [Article d’Erdős et Gallai](https://combinatorica.hu/~p_erdos/1959-10.pdf)
- Un chemin extérieur de longueur 2 entre $R_A$ et $R_C$ fermerait
  un $C_9$ avec deux attaches et un chemin interne de longueur 5.
  Par conséquent, une arête entre $R_A,R_C$ relie des sommets
  isolés dans leurs classes respectives. Un sommet de $Z$ ne peut
  toucher les deux classes. Si $z=0$, la 2-connexité impose
  $p=q'=0$, car toute composante non triviale d’une classe dépendrait
  de son unique label du noyau.

On obtient donc le majorant extérieur
$$
(x+i)(y+j)+z\max(|R_A|,|R_C|)+F(z)+\min(F(p),3p)+\min(F(q'),3q').
$$
On le combine avec un second majorant. Soient $X,Y$ les ensembles
de tailles $x,y$ à plusieurs attaches. Ils sont indépendants.
Parmi les autres sommets extérieurs, ceux qui touchent $X$, ceux
qui touchent $Y$, et ceux qui ne touchent ni l’un ni l’autre
forment trois groupes disjoints de tailles $u,v,w$. Un voisin
des deux ensembles donnerait le chemin extérieur de longueur 2
interdit. Si $x+c=13$, tout sommet de $Z$ touche $X$, car il
est non adjacent à $C$ et $X\cup C$ est indépendant. On a donc
$u\ge z$ dans ce cas. Symétriquement, $v\ge z$ si $y+a=13$.

Toute arête dans le groupe qui touche $X$ relie deux sommets ayant
le même voisin unique dans $X$. Deux voisins distincts dans $X$
donneraient un chemin extérieur de longueur 3 dont les extrémités
ont des attaches distinctes sur $A$, puis un $C_9$ avec un chemin
interne de longueur 4. Si ce groupe a $n$ sommets dont $k$
non isolés en son sein, il contribue au plus $F(k)+k+x(n-k)$
arêtes internes ou vers $X$. Posons
$$
G(d,n)=dn+\max_{k\in\{0,2,\ldots,n\}}(F(k)-(d-1)k).
$$
Le second majorant est ainsi $xy+G(x,u)+G(y,v)+F(w)+uv+uw+vw$,
maximisé sur les trois tailles admissibles. On prend le minimum
de ces deux majorants et de $F(r)$, puis on ajoute $i+j+p+q'$
pour les attaches uniques.

Le vérificateur maximise ce total sur des paramètres entiers. Pour
$r\le12$ on reprend les exclusions d’[answer-16](../twelve-exterior-c9/C9-TWELVE-EXTERIOR.md)
et des résultats qui le précèdent. Pour $r\ge13$, voici les
cinq ordres où tous les majorants sont sous le seuil du bloc.

| Ordre de $B$ | Majorant avec un noyau maximal et $r\ge13$ | Seuil |
| ---: | ---: | ---: |
| 25 | 123 | 147 |
| 26 | 135 | 148 |
| 27 | 144 | 155 |
| 28 | 154 | 161 |
| 29 | 165 | 166 |

Comme chaque noyau s’étend en un noyau maximal, à ces cinq ordres
le bloc candidat ne contient aucun noyau au sens indiqué.

## 2. Famille maximale de taille un à l’ordre 25

Soit $q$ le maximum de triangles sommet-disjoints et $H$ le
reste après retrait d’une famille de taille $q$. Il est sans
triangle. On calcule un majorant pour $e(H)$ qui tient compte de
l’absence de noyau. Soit $d$ un ordre à partir duquel les noyaux
sont exclus dans $B$. On prend $d=8$ aux ordres 25 à 29.
Aux autres ordres, si $r_0$ est le plus petit complément d’un
noyau maximal que la section 1 laisse ouvert, on prend
$d=b-r_0+1$.

Un graphe biparti de parties de taille au moins quatre et où toute
paire d’une même partie a au moins quatre voisins communs est un
noyau s’il est induit dans $B$. Pour joindre deux sommets du
même côté en $2,4,6$ pas, on intercale zéro, un ou deux autres
sommets de ce côté et on choisit des voisins communs distincts
pour les paires successives. Vers une destination de l’autre côté,
on choisit d’abord un voisin de celle-ci distinct de la source,
on le rejoint par le chemin pair voulu en évitant la destination,
puis on ajoute la dernière arête. Les quatre voisins communs
permettent d’éviter la destination et les deux choix antérieurs.

Dans un graphe biparti induit sans noyau, si les tailles $a,c$
sont toutes deux au moins quatre et $a+c\ge d$, deux sommets
d’un des côtés partagent au plus trois voisins. Leurs degrés
s’additionnent en au plus $c+3$ si la paire est dans le côté
de taille $a$, ou $a+3$ sinon. On peut supprimer un sommet
de degré au plus la moitié arrondie à l’entier inférieur, puis
récurrer. Le cas de base est $ac$.

Dans un graphe sans triangle mais non biparti, un plus court
cycle impair de longueur $g\ge5$ est sans corde et chaque
sommet extérieur y a au plus deux voisins. Entre deux voisins,
l’arc impair doit avoir longueur au moins $g-2$, faute de quoi
il donnerait un cycle impair plus court avec ce sommet, donc
l’arc pair a longueur deux. Le graphe des pas de deux sur le
cycle impair n’a pas de triangle, ce qui interdit trois voisins.
La somme des degrés sur le cycle est donc au plus $2|V(H)|$.
On peut supprimer un sommet de degré au plus
$\lfloor2|V$H$|/5\rfloor$. On combine les deux récurrences avec
la borne de Mantel et la taille maximale 13 pour chaque partie
du cas biparti. À $b=25,q=1$, cela donne $e(H)\le97$.

Fixons maintenant le triangle $T$ à ces paramètres. Si le
voisinage dans $H$ de l’un des sommets de $T$ contient trois
arêtes disjointes, les deux autres voisinages sont indépendants.
Une arête dans l’un des deux éviterait l’une des trois et
donnerait deux triangles disjoints. Il y a alors au plus
$22+2\cdot13=48$ attaches de $T$ vers $H$.
Sinon, chacun des trois voisinages a un couplage de taille
au plus deux. S’il est biparti, le théorème de König donne
une couverture par deux sommets, donc une taille au plus 15.
S’il est non biparti, son plus court cycle impair est un $C_5$.
Toute arête hors de ce cycle ou incidente à un sommet extérieur
se prolonge par deux arêtes disjointes du $C_5$. Le voisinage
est donc un $C_5$ avec des sommets isolés, de taille au plus
16 puisque son indépendance est sa taille moins trois.
Le premier majorant 48 s’applique aussi dans ce cas.

Le seuil 147 impose maintenant $e(H)\ge96$. Un voisinage de
taille $n$ dans $H$ est sans chemin sur huit sommets, qui
se fermerait en $C_9$ par son sommet dans $T$. Par Erdős–Gallai
ses arêtes sont au plus $3n$. Comme $H$ est sans triangle,
ses degrés sont au plus 13. Ainsi $96\le3n+13(22-n)$ et
$n\le19$. Le cas du couplage à trois arêtes donne donc au plus
$19+26=45$ attaches. Dans l’autre cas, un voisinage de taille
16 serait un $C_5$ avec des isolés, d’où
$e(H)\le5+13(22-16)=83<96$. Les trois voisinages ont alors
taille au plus 15, et il y a de nouveau au plus 45 attaches.
Au total $e(B)\le97+3+45=145<147$.

## 3. Fermetures interdites entre coupes en étoile

Orientons chaque coupe de trois arêtes en étoile du triangle
qui contient le centre vers le triangle dont il atteint les
trois sommets. Supposons qu’un chemin dirigé visite $m$
triangles distincts et qu’une arête quelconque relie les deux
triangles extrêmes. Cette arête fixe les extrémités du chemin
à relever. Dans le premier triangle, le passage interne a
longueur 0 si l’extrémité est le centre, et longueur 1 ou 2
sinon. Dans chacun des $m-1$ autres triangles, l’insertion
d’un passage de longueur 0, 1 ou 2 est libre car l’étoile
entrante atteint tous les sommets. Les passages sont simples
et les triangles disjoints. Avec les $m$ arêtes entre
triangles, on obtient respectivement les intervalles
$[m,3m-2]$ et $[m+1,3m]$.

- Pour $4\le m\le8$, tous ces intervalles contiennent 9.
  La coupe entre les deux extrémités doit donc être vide.
- Pour $m=3$, toute arête entre les extrémités doit toucher
  le centre initial. En particulier, la coupe de fermeture
  ne peut être riche au sens d’answer-12. Un triangle dirigé
  d’étoiles est lui-même interdit, en faisant passer chaque
  triangle par un chemin interne de longueur 2.
  Par conséquent, le graphe non orienté des étoiles ne
  contient pas de $K_4$. Sur quatre tels triangles, le
  tournoi associé, sans triangle dirigé, serait transitif et
  aurait un chemin dirigé de longueur 3 dont les extrémités
  sont adjacentes.

Si deux triangles cibles ont deux sources communes, les deux
étoiles émises par chaque source vers ces cibles ont le même
centre. Sinon l’une des sources donne un passage de longueur
3 entre les cibles, et l’autre un passage de longueur 2 ou 3.
Les extrémités de ces passages dans les cibles sont libres.
On les choisit distinctes et on ferme par deux passages
internes de somme 4 ou 3, respectivement, pour obtenir un
$C_9$. Il ne peut y avoir trois sources communes. Leurs
centres toucheraient chacun les six sommets des deux cibles.
Dans la première cible, on utilise un chemin sur trois
sommets, et dans la seconde un chemin sur deux sommets et
un sommet seul. Les trois centres relient ces chemins
cycliquement, ce qui donne un $C_9$.

Si deux sources partagent au moins trois cibles, il n’y a
pas d’arête entre deux quelconques de ces cibles. Une telle
arête donnerait un chemin de longueur 3 entre quatre sommets
des deux triangles, en ajoutant une arête à chaque extrémité
de l’arête donnée. Sur une troisième cible on prend un
chemin de longueur 2. Les deux centres alignés relient
les deux chemins avec quatre arêtes supplémentaires.

### Portée du décompte des grandes familles

Pour $5\le q\le11$, soient $c_q=\binom q2$ et
$r_q=\operatorname{ex}(q;C_3,C_4)$. Au plus $r_q$ coupes
sont riches (answer-12), chacune a au plus huit arêtes
(answer-11), et au plus $\lfloor q^2/3\rfloor$ coupes sont
des étoiles complètes par Turán. Les autres ont au plus
deux arêtes. Pour $h=b-3q$, la borne combinée est
$$
3q+2c_q+6r_q+\min(\lfloor q^2/3\rfloor,c_q-r_q)+3qh+\lfloor h^2/4\rfloor.
$$
On peut mettre $r_q$ dans la formule parce que remplacer
une coupe non riche par une coupe riche coûte au plus une
étoile dans le terme minimum et ajoute six au terme précédent.
Le théorème 3.1 donne les valeurs de $r_q$ pour
$q=5,\dots,11$.
[Article de Garnick, Kwong et Lazebnik](https://bpb-us-w2.wpmucdn.com/sites.udel.edu/dist/3/7714/files/2022/02/ex34a_v2.pdf)

Le contrôle des 48 couples $(b,q)$ avec $q\ge5$ ne ferme
aucun de ces cas avec ce seul majorant. Il vaut encore 278
à $(33,11)$. Les interdictions de coupes ci-dessus
dépendent de la disposition des étoiles et des coupes
riches. Enfin, retirer deux arêtes disjointes entre les
deux triangles de $K_6$ donne une coupe de sept arêtes et
un graphe de nombre de clique quatre. Sept arêtes de coupe
ne suffisent donc pas à imposer un $K_5$.

## Reproduction

Depuis le répertoire de ce document dans l’archive extraite,
exécuter `python3 -B verify-packing-bridges.py | cmp - packing-bridges-certificate.json`.
Le calcul utilise des entiers. Le cas général de $C_9$ et
le stable de taille 13 restent ouverts.
