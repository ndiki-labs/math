# Tous les stables de taille 13 sont exclus

Dans tout 3-coloriage de \(K_{33}\) sans \(C_9\)
monochromatique, **chaque couleur a un nombre
d’indépendance au plus 12**. Le raisonnement
utilise [answer-5](../stable14-c9/C9-STABLE14.md)
pour la borne 13 à l’avance et
[answer-6](../stable13-c9/C9-STABLE13.md)
pour les sept formes sur un stable de taille 13.

## Deux stables qui se recoupent par leur structure

Supposons que \(S\) soit un stable rouge de taille
13. Nommez bleu et vert les deux autres couleurs
comme dans answer-6. Dans chacune des sept formes,
il y a deux cliques bleues \(A,B\) de tailles 5 et 7
dont toutes les arêtes croisées sont vertes.

- Dans une forme \((5,8)\), on retire le centre
  éventuel de l’étoile bleue de la clique de
  taille huit. Deux sommets de \(B\) sont reliés
  par un chemin bleu de longueur sept dans la
  clique initiale de taille huit.
- Dans la forme \((6,7)\), on retire le centre
  \(a_0\) de la clique de taille six. Il est bleu
  vers six des sept sommets de \(B\). Tout chemin
  hamiltonien bleu entre deux sommets de \(B\)
  contient une arête dont les deux extrémités
  voient \(a_0\) en bleu. Insérer \(a_0\) dans
  cette arête donne un chemin bleu de longueur
  sept.

Tout sommet hors de \(S\) a donc au plus un
voisin bleu dans \(B\). Il ne peut toucher en
vert les deux côtés de \(A,B\), car un chemin
alterné de longueur sept fermerait un \(C_9\)
vert. Soit \(G\) l’ensemble des sommets hors
de \(S\) ayant au moins deux voisins verts dans
\(B\), et soit \(X=V(K_{33})\setminus(S\cup G)\).
Aucun sommet de \(G\) ne voit \(A\) en vert.
Une arête verte à l’intérieur de \(G\) se
fermerait en \(C_9\) par deux attaches
distinctes dans \(B\) et un chemin vert de
longueur six. Ainsi \(Z=A\cup G\) est un stable
vert et \(|G|\le8\), donc \(|X|\ge12\).

Chaque \(x\in X\) a au moins cinq voisins rouges
dans \(B\). Pour deux sommets de \(X\), ces
voisinages rouges ont une intersection de taille au
moins trois. Pour quatre sommets distincts de
\(X\), au moins une paire a une intersection de
taille au moins quatre. Si l’un d’eux manque au
plus un voisin de \(B\), il forme une telle paire
avec n’importe lequel des trois autres. Sinon,
les quatre ensembles de voisins manquants ont
chacun taille deux et deux se recoupent.

Si \(uv\) était une arête rouge dans \(X\), choisir
quatre sommets auxiliaires dans \(X\setminus\{u,v\}\).
Retenir une paire \(w_1,w_2\) ayant une intersection
d’au moins quatre et un troisième auxiliaire \(w_3\).
Les quatre intersections le long de
\(v,w_1,w_2,w_3,u\) ont chacune au moins trois
éléments et l’une en a quatre. Toute sous-famille
de taille au plus trois vérifie Hall, et l’union
des quatre a au moins quatre éléments. Des
représentants distincts dans \(B\) donnent un
chemin rouge de longueur huit, que \(uv\) ferme
en \(C_9\). Donc \(X\) est rouge-indépendant et
\(|X|\in\{12,13\}\). Par ailleurs
\(|Z|=25-|X|\).

## Une arête rouge dans le stable vert

Deux sommets distincts de \(X\) sont reliés
par un chemin rouge de longueur six dans
\(X\cup B\). Pour cela, choisir deux
intermédiaires distincts dans \(X\). Les
trois intersections successives ont chacune
au moins trois éléments, ce qui donne trois
représentants distincts dans \(B\).

Soient \(u,v\in Z\) et supposons qu’ils aient
tous deux un voisin rouge dans \(X\). S’ils
peuvent en choisir deux distincts, ces attaches,
le chemin de longueur six et l’arête \(uv\)
formeraient un \(C_9\) rouge. Les ensembles
\(Z\) et \(X\cup B\) sont disjoints. Par conséquent,
**une arête rouge entre deux sommets de \(Z\)
qui touchent \(X\) exige que leurs voisinages
rouges dans \(X\) soient le même singleton**.

## Fermeture du cas \(|X|=12\)

Ici \(Z\) est un stable vert de taille 13. Par
answer-6, il admet deux cliques d’une même
couleur et les sept formes de coupe. Cette
couleur est bleue. En effet, deux cliques
rouges ne permettraient aucune clique bleue
de taille trois, alors que \(Z\) contient
la clique bleue \(A\) de taille cinq.

Comme pour \(S\), ôter le centre éventuel
donne deux cliques bleues \(P,Q\) de tailles
5 et 7 dont la coupe est entièrement rouge.
Dans chaque clique, au plus un sommet est
sans voisin rouge dans \(X\). Deux tels
sommets seraient indépendants en rouge et
prolongeraient \(X\) à 14. Il reste donc
au moins quatre sommets de \(P\) et six de
\(Q\) qui touchent \(X\) en rouge. Toutes
leurs arêtes croisées étant rouges, la
règle du singleton leur donne la même
attache rouge unique \(x\in X\).
Trois de ces sommets de \(P\), joints à
\(X\setminus\{x\}\), font un stable rouge
de taille 14, contradiction.

## Fermeture du cas \(|X|=13\)

Ici \(Z\) a 12 sommets. Chacun voit \(X\)
en rouge, car un sommet sans voisin rouge
prolongerait \(X\) à 14. Groupons les
sommets dont le voisinage rouge dans \(X\)
est le même singleton. Les autres sommets
forment chacun une partie singleton.

Un groupe associé à \(x\in X\) est une
clique rouge. Une paire non rouge de ce
groupe et \(X\setminus\{x\}\) formeraient
un stable rouge de taille 14. Le groupe
a au plus sept sommets, car huit avec
\(x\) donneraient un \(K_9\) rouge. Il y
a au moins cinq parties, car les cinq
sommets de \(A\) sont deux à deux non
rouges. Toutes les arêtes entre parties
sont bleues, par la règle du singleton et
parce que \(Z\) est vert-indépendant.

Il ne peut y avoir deux parties de taille
au moins cinq. Avec trois autres parties,
cela demanderait au moins 13 sommets. En
limitant chaque partie à quatre sommets,
on garde ainsi au moins \(12-(7-4)=9\)
sommets. En garder neuf donne un graphe
bleu multipartite complet de degré minimum
au moins cinq, donc un \(C_9\) par Dirac.
Le vérificateur construit également un
cycle sur les étiquettes des parties pour
chacune des 42 partitions possibles.
[Théorème de Dirac](https://doi.org/10.1112/plms/s3-2.1.69).

Les rôles des couleurs étant arbitraires,
la borne 12 est établie pour chaque couleur.

## Conséquences immédiates sur les noyaux

À l’ordre 32, le sommet extérieur du
bloc prolonge les stables qui évitent
son attache \(u_0\), comme en answer-32.
Cela donne maintenant
\(\alpha(B-u_0)\le11\). Un sous-graphe
biparti induit a alors ordre au plus
23, ou au plus 22 s’il évite la marque.
À l’ordre 33 son ordre maximal est 24.

Le tableau de
[answer-17](../packing-bridges-c9/C9-PACKING-BRIDGES.md)
est aussi recalculé avec la borne 12. Pour
les noyaux maximaux, un côté de taille
12 forcerait chaque sommet extérieur à
le toucher et donnerait la contradiction
de bipartition déjà utilisée dans cette
preuve. Les tailles des côtés sont donc
au plus 11. Les effectifs de sommets
extérieurs et les majorants d’arêtes
d’answer-17 s’appliquent avec la borne 12.
Combiné avec answer-16, le calcul donne
un ordre maximal de noyau de **16** dans
un bloc d’ordre 32 et de **17** à l’ordre
33. Les noyaux plus petits, dont le
\(K_{5,5}\), restent à traiter par cet
argument. Le cas général de \(C_9\)
reste ouvert.

## Rejeu

Depuis le dossier de cette preuve dans le ZIP, exécuter

```sh
python3 -B verify-stable13-closure.py | cmp - stable13-closure-certificate.json
```
