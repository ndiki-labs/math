# Réduction héréditaire par la densité et le degré minimal

Les acquis 11, 33 et 35 permettent de travailler dans la classe
héréditaire des graphes sans $C_9$ ni $K_6$, d’indépendance au plus 12
et sans $K_{4,4}$ induit. Tout bloc candidat aux ordres 32 et 33
appartient à cette classe. Il est non biparti puisque son ordre
dépasse 24. Ses seuils d’arêtes sont respectivement 175 et 176.

## Borne ascendante

Posons $T(16)=57$ et $T(n)=7n-56$ pour $n\ge17$. Le certificat
vérifie les inégalités arithmétiques qui suivent. Il utilise les
théorèmes cités dans la preuve combinatoire.

**Bipartis.** Pour des parties $a,b\le12$, le nombre d’arêtes $m$
vérifie $\sum_{x\in A}\binom{d(x)}4\le3\binom b4$ et l’inégalité
symétrique. Dans un graphe biparti, un $K_{4,4}$ serait induit.
Pour une somme fixée, l’équilibrage des degrés minimise le membre
de gauche par convexité discrète. On obtient les plafonds
52, 57, 64, 70, 78, 84, 91, 98, 107 pour les ordres 16 à 24.
Ils sont tous au plus $T(n)$. Après 24, l’indépendance exclut
un graphe biparti.

**Circonférence au plus 8.** Un bloc de taille $s\le8$ est borné
par le nombre d’arêtes du graphe de Turán à cinq parties. Pour
$9\le s\le11$, Kopylov donne $\max(2s+7,4s-5)$. Pour $s\ge12$,
la stabilité de Füredi, Kostochka et Verstraëte (théorème 2.1 dans
la source ci-dessous, avec $k=9,t=4$) donne $3s-3$ arêtes ou
l’inclusion dans $H_{s,9,4}$. Ce dernier a $4s-5$ arêtes. Hors de
sa clique de cinq sommets, au plus trois des $s-5$ sommets
indépendants peuvent conserver leurs quatre voisins communs.
Il manque donc au moins $s-8$ arêtes et le plafond est $3s+3$.
Pour passer au graphe entier, on additionne les plafonds des blocs
sous le budget $\sum_D(|D|-1)\le n-1$, valable aussi si le graphe
est non connexe. On obtient 56, puis 62, aux ordres 16 et 17.
Pour $n\ge18$, Erdős–Gallai donne directement
$4(n-1)<7n-55$.

À l’ordre 16, si le graphe est non biparti et sa circonférence
vaut au moins 9, Brandt donne $e\le\lfloor15^2/4\rfloor+1=57$.
On a donc $e\le T(16)$ dans tous les cas.

**Contre-exemple d’ordre minimal.** S’il existe un graphe de la
classe avec $e>T(n)$ entre les ordres 16 et 33, prenons le plus
petit ordre $n$. Le graphe n’est pas biparti et sa circonférence
vaut au moins 9, par les deux bornes précédentes. Retirer un sommet
de degré au plus $T(n)-T(n-1)$ conserverait la violation, ce qui
impose $\delta\ge7$ à 17 et $\delta\ge8$ ensuite. Jusqu’à l’ordre 22,
c’est au moins $\lceil(n+2)/3\rceil$. Brandt, Faudree et Goddard
imposent alors un $C_9$ par faible pancyclicité. On a donc
$23\le n\le33$. Le même théorème donne
$\delta\le\lfloor(n+1)/3\rfloor$. La suppression d’un sommet de
degré minimum donne aussi $\delta\ge e-7n+63$. Aux ordres 23, 24
et 25, ces inégalités forcent $\delta=8$ et $e=7n-55$.

## La 3-connexité découle du degré minimal

**Petit sous-graphe de degré minimal 7.** Aucun graphe de la
classe d’ordre au plus 16 ne satisfait $\delta\ge7$. Une
composante a au moins huit sommets. Une composante d’ordre huit
serait $K_8$, donc le graphe est connexe et d’ordre au moins neuf.
S’il a un point d’articulation, une composante après son retrait
contient au plus sept sommets. Avec le point d’articulation, le
degré minimum force un $K_8$. Le graphe est ainsi 2-connexe.
Dirac donne une circonférence d’au moins 9. Par Brandt, Faudree et
Goddard il est biparti. Le petit côté contient sept ou huit
sommets. Quatre sommets du grand côté ont au moins quatre voisins
communs, car chacun manque au plus un sommet du petit côté.
Cela donne un $K_{4,4}$ induit.

**Séparateurs.** Dans un graphe de la classe avec $\delta\ge8$
et $n\le33$, une séparation par zéro ou un sommet donne une
composante d’ordre au plus 16 et de degré minimum au moins 7.
Supposons donc qu’un séparateur soit formé de deux sommets $u,v$.
Une petite composante $R$ après leur retrait a $r\le15$ et
$\delta(R)\ge6$. Chacun de $u,v$ a au plus six voisins dans $R$,
sans quoi $R$ augmenté de ce sommet serait un sous-graphe
d’ordre au plus 16 et de degré minimum 7. Le budget d’arêtes
entre $R$ et le séparateur est donc 12.

- $r\le7$ est exclu par le degré ou par $K_6$. À $r=8$ le
  complément de $R$ est un couplage, d’au moins trois arêtes
  pour éviter $K_6$. Au moins six sommets de $R$ ont donc
  degré 6. Il faut au moins $8+6=14$ arêtes au séparateur.
- Si $r\ge9$ et $R$ est 2-connexe, Dirac garantit un cycle
  d’au moins neuf sommets. Avec $\delta(R)\ge6$ et $r\le15$,
  Brandt, Faudree et Goddard imposent que $R$ soit biparti.
  Le petit côté compte au moins six sommets. S’il en compte
  six, tous les sommets du grand côté y sont complets.
  S’il en compte sept, chacun du grand côté manque au plus
  un voisin. Pour éviter $K_{4,4}$, ils doivent tous manquer
  exactement un voisin, chacun différent. En effet, une
  absence de perte ou une perte répétée donne quatre sommets
  manquant au total au plus trois voisins distincts. Le
  seul cas restant a deux côtés de taille sept et un
  couplage parfait manquant. Ses 14 sommets ont degré 6
  et demandent 28 arêtes au séparateur.
- Si $r\ge9$ et $R$ a un point d’articulation, chacune de
  ses composantes après retrait de ce point a au moins sept
  sommets. Une composante d’au plus six sommets forcerait
  un $K_7$ ou violerait le degré minimum. Il faut donc
  $r=15$, avec deux composantes de sept sommets. Dans
  chacun des deux sous-graphes à huit sommets incluant
  l’articulation, au plus trois des sept autres sommets
  sont universels. Quatre universels forcent soit $K_6$
  via une arête parmi les quatre autres sommets, soit un
  degré 4 chez au moins un sommet hors de l’articulation.
  Chaque côté contient donc au moins quatre sommets de
  degré 6. Il faut au moins 16 arêtes au séparateur.

Ces budgets sont contradictoires. Le contre-exemple minimal est
3-connexe. Par le théorème 1.2 de Lin, Wang et Zhou appliqué
avec $k=\delta$, il possède $\delta$ longueurs consécutives.
L’exception complète est exclue par $K_6$. Ces longueurs sont
toutes au moins 10. En effet, elles évitent 9 et le segment
de 3 à 8 a seulement six éléments. En particulier, il a une
circonférence d’au moins 17 et quatre longueurs impaires
consécutives d’au moins 11.

## Maille impaire

Un plus court cycle impair est induit. Si sa longueur $g$ vaut
au moins 7, chaque sommet extérieur a au plus deux voisins
sur ce cycle. Deux voisins doivent être à distance deux, car
l’arc impair entre eux doit avoir longueur au moins $g-2$.
Pour $g\ge7$, aucun triplet n’a toutes ses distances égales à
deux. Ainsi $g\delta\le 2n$, qui exclut $g\ge9$.

Pour $g=7$, les arêtes qui sortent du cycle sont au moins
$7(\delta-2)\ge42$. Au moins $42-(n-7)=49-n\ge16$ sommets
touchent deux fois le cycle. Ils forment un stable. En effet,
si deux sommets extérieurs attachés au cycle sont adjacents,
toute paire de leurs marques doit être à distance trois.
Les distances zéro, un et deux ferment respectivement un
$C_3$, un $C_9$ par l’arc de longueur six, ou un $C_5$.
Sur $C_7$, les ensembles de points à distance trois de deux
marques distantes de deux sont disjoints. Cela exclut une
arête entre deux sommets à double attache. Le stable
contredit $\alpha\le12$.

La maille restante est donc 3 ou 5. Dans le cas sans
triangle, le théorème 1.8 de Brandt, Faudree et Goddard
donne, pour $\delta>n/3$, la faible pancyclicité jusqu’à
$\min(n,2(n-\alpha))\ge9$. Cette branche exige donc
$n\ge24$ et $8\le\delta\le\lfloor n/3\rfloor$.

## Portée

Chaque bloc candidat d’ordre 32 ou 33 fournirait un sous-graphe
induit minimal d’ordre 23 à 33 de la forme certifiée. Cette
réduction englobe la branche de l’heptagone sans supposer qu’un
contre-exemple minimal conserve le packing du bloc initial.
Elle laisse la maille 5 et les cliques maximales de tailles
3, 4 et 5. Le verdict sur $R_3(C_9)=33$ reste ouvert.

## Sources et rejeu

- [Füredi, Kostochka, Luo et Verstraëte, stabilité d’Erdős–Gallai et Kopylov](https://arxiv.org/pdf/1704.02866)
- [Brandt, condition de taille et cycles courts](https://doi.org/10.1016/S0166-218X(97)00032-2)
- [Brandt, Faudree et Goddard, théorèmes 1.7 et 1.8](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf)
- [Dirac, borne sur la circonférence](https://doi.org/10.1112/plms/s3-2.1.69)
- [Lin, Wang et Zhou, théorème 1.2](https://arxiv.org/html/2410.00648v2)

```sh
python3 -B verify-hereditary-density.py | cmp - hereditary-density-certificate.json
```
