# Noyaux bipartis et couches de pentagones sous la borne d’indépendance 12

Soit \(B\) un bloc candidat d’ordre \(b=32\) ou \(33\), sans
\(C_9\), non biparti, 2-connexe, avec au moins 175 ou 176
arêtes respectivement. Les réductions précédentes donnent
\(\omega(B)\le5\), \(\alpha(B)\le12\) et
\(\alpha(B-u_0)\le11\) à l’ordre 32.

## Majorants pour un noyau biparti maximal

On reprend le noyau d’[answer-17](../packing-bridges-c9/C9-PACKING-BRIDGES.md).
C’est un sous-graphe biparti induit de parties \(A,C\), de tailles
\(a,c\ge4\). Les longueurs de chemins garanties sont \(2,4,6\)
du même côté et \(3,5,7\) de côtés opposés. Tout noyau s’étend
en un tel noyau maximal par inclusion. D’après
[answer-33](../stable13-closure-c9/C9-STABLE13-CLOSURE.md), on
peut partir de l’interdiction des ordres 17 et plus dans le
bloc de taille 32, et 18 et plus dans le bloc de taille 33.

On conserve la notation d’answer-17. Les classes \(R_A,R_C,Z\)
touchent respectivement \(A\), \(C\) ou aucun côté. Leurs sous-classes
de tailles \(x,i,p\) et \(y,j,q'\) comptent les attaches multiples,
les attaches uniques isolées dans leur classe, puis les attaches
uniques non isolées. Les ensembles à attaches multiples sont
\(X,Y\) et les ensembles à attache unique isolée sont \(I,J\).
Il faut \(z=|Z|>0\). Si \(Z\) est vide, toute composante non
triviale de \(R_A\) ou \(R_C\) dépend d’une seule attache au
noyau, ce qu’interdit la 2-connexité. Le noyau s’étend alors en
une bipartition de \(B\).

Les deux stables disjoints obtenus à partir de \(C\cup X\cup I\)
et de \(A\cup Y\cup J\), en ajoutant au besoin un sommet des
classes internes non isolées, ont les tailles garanties
\(c+x+i+\mathbf1_{p>0}\) et \(a+y+j+\mathbf1_{q'>0}\).
À l’ordre 32, ils ne peuvent pas tous deux atteindre 12,
car un stable de taille 12 doit contenir \(u_0\).
Chaque côté du noyau a au plus 11 sommets. Un côté de taille
12 obligerait tous les sommets extérieurs à le toucher, donc
\(Z\) serait vide.

### Arêtes à distance deux du noyau

Parmi les sommets extérieurs autres que \(X\cup Y\),
soient \(U\) ceux qui touchent \(X\), \(V\) ceux qui
touchent \(Y\), et \(W\) les autres. Les deux premières
classes sont disjointes. Un voisin commun de \(X,Y\)
donnerait un chemin extérieur de longueur deux, puis un
\(C_9\) via un chemin de longueur cinq dans le noyau.

On a \(U\subseteq J\cup Z\) et \(V\subseteq I\cup Z\).
Une arête de \(X\) vers \(R_A\) est interdite. Une arête
de \(X\) vers une attache unique non isolée de \(R_C\)
se prolongerait en un chemin de longueur deux entre les
deux classes. Si \(u=|U|\) et \(v=|V|\), leurs nombres de
sommets dans \(Z\) sont donc au moins
\(\max(0,u-j)\) et \(\max(0,v-i)\).
Le sous-ensemble de \(Z\) évitant \(X\) s’ajoute au stable
\(C\cup X\), de sorte qu’il a indépendance au plus
\(12-c-x\). S’il reste zéro ou une unité, sa taille est
au plus zéro ou cinq respectivement. La borne cinq vient
de la clique maximale. Le même argument s’applique au
sous-ensemble de \(Z\) évitant \(Y\), et à \(Z\) entier
avec le stable \(C\).

Le sous-ensemble \(U\cap Z\) évite \(A\cup Y\), ce qui
limite son indépendance à \(12-a-y\). En particulier, parmi
ses sommets, au plus \(12-a-y\) sont isolés dans \(U\).
Si cette marge vaut un et si au moins deux sommets de
\(Z\) sont dans \(U\), ils sont tous non isolés dans \(U\).
On applique la borne symétrique dans \(V\cap Z\).
Pour les \(k_u\) sommets non isolés de \(U\), une arête
interne impose que ses extrémités touchent un même
sommet unique de \(X\). Sinon le chemin entre deux sommets
distincts de \(X\), avec leurs attaches et le chemin de
longueur quatre dans le noyau, donne un \(C_9\).
Les composantes ainsi attachées sont sans chemin sur huit
sommets. Leurs arêtes internes et vers \(X\) sont donc
majorées par
\(\min(F(k_u),3k_u)+k_u+x(u-k_u)\), où \(F(n)\) est le
nombre extrémal sans \(C_9\). On fait de même dans \(V\).

Un chemin extérieur de longueur quatre de \(X\) à \(Y\)
se ferme en \(C_9\) avec un chemin de longueur trois du
noyau. Une arête \(UV\) doit ainsi relier deux sommets isolés
dans leur propre classe, ce qui donne \((u-k_u)(v-k_v)\).
Chaque sommet de \(W\) touche au plus une de \(U,V\).
De plus, un sommet de la classe de taille \(p\) appartient
à \(W\) et évite \(U\). Une arête vers \(U\), prolongée
vers \(X\) et vers son voisin interne dans \(R_A\), donnerait
un chemin de longueur trois entre deux attaches de \(A\)
distinctes au choix. Avec le chemin de longueur quatre
dans le noyau, cela donne un \(C_9\). Symétriquement la
classe de taille \(q'\) évite \(V\). Les arêtes de \(W\)
vers \(U\cup V\) sont donc au plus
\(pv+q'u+(|W|-p-q')\max(u,v)\).

Le calcul minimise les plafonds de cette approche et
d’answer-17. Il utilise aussi le sous-graphe biparti induit
sur \(A\cup C\cup X\cup Y\cup I\cup J\). Enfin, pour un noyau
qui contient un \(K_{t,t}\) fixé, les arêtes manquantes sont
au plus \(ac-t^2\). Si \(a=t\), chaque sommet de \(A\) manque
au plus \(c-t\) voisins. Si \(c=t\), chaque sommet de \(C\)
manque au plus \(a-t\) voisins. Ces contraintes resserrent
le majorant d’attaches multiples du noyau maximal.

### Un plafond pour le graphe extérieur entier

Le graphe induit par les \(r\) sommets extérieurs hérite
des limites de taille des noyaux. S’il est biparti, on
prend le maximum du plafond biparti d’answer-25 sur ses
partitions, avec les nouvelles limites de noyau et
d’indépendance. S’il est non biparti, ses arêtes sont au plus
\[
\max\!\left(\left\lfloor (r-1)^2/4\right\rfloor+1,\;4(r-1)\right).
\]
En effet, au-delà de la seconde borne, Erdős–Gallai
impose une circonférence d’au moins neuf. Au-delà de la
première, Brandt impose tous les cycles entre trois et
la circonférence. Quand la circonférence atteint neuf, le théorème 1.7
de Brandt, Faudree et Goddard impose aussi un sommet de
degré au plus \(\lfloor(r+1)/3\rfloor\). Sinon le degré
minimal garantirait les cycles de longueur 4 à la
circonférence. Supprimer ce sommet donne une récurrence
pour le plafond extérieur. Le premier calcul, qui utilise
les limites de taille des noyaux d’answer-33, ramène ces
limites à 11 et 14. Le second réinjecte ces limites
dans le plafond par suppression, dont le cas de base
prend le nombre extrémal sur au plus huit sommets.
[Brandt, Faudree et Goddard, théorème 1.7](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf).
[Théorème de Brandt](https://www.sciencedirect.com/science/article/pii/S0166218X97000322) · [Théorème d’Erdős–Gallai](https://combinatorica.hu/~p_erdos/1959-10.pdf).

Le second passage donne, sur tous les noyaux maximaux
possibles, des plafonds de 163 arêtes à l’ordre 32 et
de 174 à l’ordre 33. Les seuils sont 175 et 176.
Les cas avec moins de 16 sommets extérieurs sont déjà
exclus par answer-33. Ainsi aucun des deux blocs
candidats ne contient de noyau du type prescrit.

Tout \(K_{4,4}\) induit fournit les chemins prescrits.
Un \(K_{4,4}\) d’un reste sans triangle est induit,
puisqu’une arête dans l’une de ses parties formerait
un triangle. Dans \(B\), tout \(K_{5,5}\) serait induit.
Une arête supplémentaire dans une partie se fermerait
en \(C_9\) par un chemin alterné de longueur huit.
Il contiendrait alors un \(K_{4,4}\) induit. Les deux
exclusions valent donc aux ordres 32 et 33.

## Le reste après retrait d’un triangle unique

Par [answer-34](../optimal-triangle-packing-c9/C9-OPTIMAL-TRIANGLE-PACKING.md),
si le nombre maximum de triangles disjoints vaut un, le
reste \(H\) a 29 ou 30 sommets, au moins 125 ou 123 arêtes
respectivement, et contient un pentagone.

### Un seul pentagone disjoint au maximum

Un pentagone retiré laisse 24 ou 25 sommets. Ce reste est
sans pentagone et non biparti, car son ordre dépasse la somme
des tailles autorisées des parties. Son plus court cycle
impair a donc longueur 7, 11, 13 ou davantage.

Pour le \(C_7\), le tableau d’answer-9 donne une coupe d’au
plus trois arêtes avec le pentagone. On retire les \(d\)
doubles attaches au \(C_7\) après avoir enlevé le \(C_5\).
Si \(r\) était le nombre de sommets après retrait des deux
cycles, le coût est au plus \(r+d\) pour les arêtes
d’attachements au \(C_7\) et les arêtes des doubles dans cette
couche, comme en answer-8. Il faut ajouter au plus \(2d\)
arêtes de ces sommets vers le \(C_5\). On majore le graphe
restant avec ses attaches au \(C_5\) par le comptage
d’answer-9 si le graphe est biparti, et par le plafond de
maille impaire au moins sept sinon.

Pour le \(C_{11}\) et le \(C_{13}\), le calcul exhaustif
borne les arêtes entre les deux cycles par neuf et dix.
Chaque sommet du cycle long a un masque de voisins
indépendants sur le pentagone. On interdit les paires de
masques qui ferment un \(C_3\) ou un \(C_9\) avec un arc
de chaque cycle. Pour les deux tailles, on fixe un
masque non vide au premier sommet à rotation près.
La recherche borne le total par la somme des maxima
des domaines restants. Elle utilise des entiers et
épuise les branches qui peuvent améliorer le maximum.
On réutilise les plafonds du reste biparti muni
d’attaches au pentagone, ou du reste non biparti dont
la maille impaire est au moins celle du cycle long.
Pour une longueur \(g\ge15\), en posant \(r=|H|-5-g\),
la borne \(5+3g+4r+\lfloor r^2/4\rfloor\) suffit.
Au total, aux deux ordres, un seul pentagone disjoint
au maximum est insuffisant.

### Deux pentagones disjoints à l’ordre 32

Choisir une paire maximisant sa coupe. Après retrait, le reste
\(L\) est sans triangle ni pentagone. On reprend le tableau
d’attaches d’answer-9. Si la coupe des deux cycles vaut une
ou deux arêtes, il y a au plus trois attaches par sommet
de \(L\), et les sommets \(D\) ayant trois attaches forment un
stable. Aucun chemin de longueur quatre dans \(L\) ne relie
deux sommets distincts de \(D\).

Si \(L\) est biparti avec parties de tailles \(a,c\), soient
\(p,q\) les tailles de \(D\) dans ses deux parties. Posons
\(J(s,t)\) le maximum de la coupe depuis \(s\) sommets
sans chemin de longueur quatre entre eux, dans un rectangle
à \(t\) colonnes, majoré par le comptage d’answer-18.
Le stable interdit les arêtes entre les deux parties de \(D\).
On obtient
\[
e(L)\le (a-p)(c-q)+J(p,c-q)+J(q,a-p).
\]
On intersecte ce plafond avec celui du noyau et on ajoute
\(2|L|+p+q\) pour les attaches. Si \(L\) est non biparti,
on utilise sa maille impaire au moins sept et l’indépendance
de \(D\). Pour les autres coupes entre les deux cycles, deux
attaches par sommet suffisent au calcul. Tous les plafonds
sont strictement sous 125 à l’ordre 32.

### Trois pentagones disjoints ou davantage à l’ordre 32

Choisir trois pentagones maximisant leurs arêtes croisées.
D’après answer-9, un sommet extérieur a au plus quatre
attaches à eux. Si tous en ont au plus trois, la coupe
entre les trois cycles est au plus 15. Si l’un en a
quatre, cette coupe est au plus 11.

Les 14 sommets restants forment un graphe sans triangle.
S’il est biparti, la nouvelle limite sur les noyaux
donne moins de 43 arêtes. S’il est non biparti, la borne
par le plus court cycle impair donne au plus 43.
L’égalité exigerait un pentagone, un \(K_{4,5}\) dans son
complément dans le reste et deux attaches au pentagone
pour chacun des neuf autres sommets. Deux sommets du
même côté de \(K_{4,5}\) ont un chemin de longueur quatre,
ce qui est interdit entre deux doubles attaches au même
pentagone. Il reste au plus 42 arêtes. Ainsi, même avec
quatre attaches par sommet, le plafond est
\(15+11+4\cdot14+42=124<125\). Ceci ferme entièrement
la branche d’un seul triangle à l’ordre 32.

## Huit triangles à l’ordre 33

On renforce le filtrage des sommets isolés d’answer-34.
Ses échanges impliquent que le graphe biparti entre les
sommets isolés du reste et les triangles portant au moins
deux marques a un couplage d’ordre au plus \(12-\alpha(H)\).
Par König, il a une couverture de sommets de cette taille
au plus. Si cette couverture prend \(i\) sommets isolés
et \(j\) triangles, tout sommet isolé hors couverture
dont le degré de marques vaut \(m\) doit occuper au moins
\(\max(0,m-j)\) triangles à marque unique. Ces besoins
doivent tenir dans les \(8-j\) triangles hors couverture.
Pour tester un vecteur de degrés avant son placement, il
suffit de retirer les \(i\) plus grands des degrés isolés
et de tester cette inégalité pour chaque \(i+j=12-\alpha(H)\).

Dans le rejeu des quinze classes, cinq passent encore
la relaxation et dix atteignent toujours le plafond de
trois millions de nœuds. Le cas général de \(C_9\) et
les ordres 32 et 33 restent ouverts.

## Rejeu

Depuis le répertoire de cette preuve extrait du ZIP, exécuter
avec Python 3 et un compilateur C++17.

~~~sh
python3 -B verify-independent-core-and-pentagons.py | cmp - independent-core-and-pentagons-certificate.json
~~~
