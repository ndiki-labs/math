# Erdős #556 · Réduction du problème extrémal à une couleur

Soit `G` un graphe de 33 sommets sans `C₉`, avec
`α(G) ≤ d`, où `d ∈ {12,13}`. Une couleur d’un éventuel
contre-exemple à `R₃(C₉) ≤ 33` doit posséder au moins 176 arêtes.
La borne `d=13` est acquise dans `answer-5`. La borne `d=12`
reste conditionnelle à l’exclusion du stable de taille 13.

**Résultats exacts.**

- Si un bloc de taille maximale est biparti, le maximum d’arêtes
  est 175 pour `d=13` et 159 pour `d=12`.
- Les mêmes maxima valent pour les graphes qui contiennent
  respectivement un `K₁₂,₁₁` ou un `K₁₁,₁₀` comme sous-graphe.
- Si `e(G) ≥ 176`, le plus grand bloc est unique, non biparti,
  a au moins 25 sommets et contient un `C₃`, un `C₅` ou un `C₇`.

## Taille et type du plus grand bloc

Inclure les ponts parmi les blocs, chacun comptant comme un bloc de
taille deux. Pour un graphe à 33 sommets, la somme des `|B|-1` des
blocs est au plus 32. Les ensembles d’arêtes de blocs sont disjoints.
L’égalité dans la somme des `|B|-1` vaut pour un graphe connexe.

Le théorème 1 de Füredi–Gunderson donne `f(n) = ex(n,C₉)`.
Pour `n≤8` on a `f(n)=C(n,2)`. Pour `9≤n≤13`, écrire
`n-1=7q+r` avec `0≤r<7`, puis utiliser
`f(n)=28q+C(r+1,2)`. Pour `n≥14`, on a
`f(n)=⌊n²/4⌋`.

Pour des blocs d’ordre au plus `b`, borner la somme des arêtes par
programmation dynamique sur le budget `t=Σ(|B|-1)≤32`.
Avec `F_b(0)=0`, prendre le maximum de `F_b(t-1)` et des
`F_b(t-s)+f(s+1)` pour `1≤s≤min(t,b-1)`. Le vérificateur
donne `F₂₄(32)=175` et `F₂₂(32)=159`.
Ainsi `e(G)≥176` impose un bloc d’ordre au moins 25. Il n’y
en a qu’un, car deux tels blocs dépasseraient le budget 32.

Si un bloc biparti contient au moins `2d-1` sommets, ses deux parts
ont taille au plus `d`, par indépendance. Un sommet ou une composante
extérieure au bloc se rattache à celui-ci par au plus un sommet.
En effet, un chemin extérieur joignant deux sommets distincts du
bloc élargirait ce sous-graphe 2-connexe. Si les deux parts ont
taille `d`, tout sommet extérieur agrandit l’une d’elles en
stable de taille `d+1`. Si les tailles sont `d` et `d-1`,
chaque sommet extérieur doit toucher la grande part. Toute la
petite part est donc sans arête vers l’extérieur, qui doit être
une clique. Pour `d=13` cette clique a huit sommets, tous voisins
du même sommet du bloc. Cela donne un `K₉`. Pour `d=12`, la
clique extérieure a dix sommets et contient déjà un `C₉).

Ainsi un bloc biparti de taille maximale a ordre au plus `2d-2`.
Les bornes `F₂₄(32)` et `F₂₂(32)` s’appliquent. Elles sont
atteintes par les deux constructions du feedback, avec
`K₁₂,₁₂`, `K₈` et `K₃` pour `d=13`, et avec
`K₁₁,₁₁`, `K₈` et `K₅` pour `d=12`. Les deux cliques
s’attachent à des sommets de parts opposées du noyau.

## Exclusion de la grande maille impaire

Soit `B` un bloc non biparti d’ordre `b≥25` dont le plus court
cycle impair a longueur `g≥11`. Ce cycle est sans corde, car une
corde formerait un cycle impair plus court. Un sommet hors du
cycle a au plus deux voisins sur celui-ci. En effet, entre deux
de ses voisins, l’arc impair doit avoir longueur `g-2`. Un arc
plus court, joint aux deux attaches, contredirait le choix de
`g`. L’autre arc a donc longueur deux. Trois points ne peuvent
être deux à deux à distance deux sur le cycle de longueur impaire
`g≥11`. Le graphe sur les `b-g` autres sommets est sans
triangle, et la borne de Mantel donne

```text
e(B) ≤ ⌊(b-g)²/4⌋ + 2(b-g) + g.
```

Les arêtes hors de `B` sont au plus `f(34-b)`. Pour obtenir
cette borne, prendre des copies disjointes des autres blocs et
en identifier un sommet par copie. Le graphe ainsi obtenu est encore sans
`C₉`, a le même nombre d’arêtes extérieures et au plus
`34-b` sommets. Le tableau vérifié compare ce budget à la
borne sur `e(B)` pour chaque `25≤b≤33`. Le seuil de 176
n’est atteint que dans le cas d’égalité `b=33,g=11`.

Dans ce cas d’égalité, le graphe extérieur au cycle est le
`K₁₁,₁₁` de Mantel. Sur le cycle, un sommet ne peut toucher
les deux parts de ce graphe, car cela donne un triangle.
L’une des deux parts ne touche donc qu’au plus cinq des onze
sommets du cycle. Parmi les six ou plus qu’elle ne touche pas,
on peut choisir trois sommets indépendants. Tout sous-graphe
induit propre d’un cycle est une réunion de chemins, et le
cycle lui-même a un stable de taille cinq. Avec la part de onze,
on obtient un stable de taille au moins 14, contradiction.

Ainsi le bloc non biparti d’ordre au moins 25 imposé par 176
arêtes doit contenir un cycle de longueur 3, 5 ou 7.

## Une exclusion à partir d’un sous-graphe biparti complet

On renforce la borne même lorsque le noyau biparti n’est
pas un bloc. Posons `m=d-1` et supposons que `G` contienne
`K_{m,m-1}`, avec parts `A,B` de tailles respectives
`m,m-1`. Une arête dans `A` ou `B` fermerait un chemin
alterné de longueur huit dans le noyau, donc les deux parts
sont des stables. Les `t=34-2m` sommets extérieurs se répartissent
en `X` (ils touchent `A` seulement), `Y` (ils touchent
`B` seulement) et `Z` (ils ne touchent ni l’une ni l’autre).
Un sommet ne peut pas toucher les deux parts, car deux attaches
et un chemin de longueur sept donnent un `C₉`.

Comme `α(G)≤m+1`, l’ensemble `Y∪Z` est une clique. Sinon,
une paire indépendante dans cet ensemble peut rejoindre `A`.
De même `α(X∪Z)≤2`. Un couple relié par une arête dans
`X` doit avoir la même attache unique dans `A`. En effet, deux
attaches distinctes dans `A` et un chemin de longueur six
entre elles fermeraient un `C₉` avec cette arête. La même règle
vaut pour `Y` et `B`. On utilise aussi deux variantes.

- Une arête entre `X` et `Y` est interdite si l’une des deux
  extrémités a un voisin dans son propre groupe. Le chemin
  extérieur de longueur deux, les deux attaches à des parts
  opposées, et un chemin de longueur cinq dans le noyau
  donnent alors un `C₉`.
- Un chemin extérieur de longueur trois entre deux sommets
  de `X` est interdit si ses extrémités peuvent choisir
  deux attaches distinctes dans `A`. Ces attaches et un
  chemin de longueur quatre dans le noyau le ferment.

### Les cas où Y est non vide

Si `Z` est non vide, il ne peut pas y avoir d’arête de
`X` à `Z`. Un tel sommet de `Z` est aussi adjacent à
tout `Y`, donnant le chemin extérieur de longueur deux
entre `X` et `Y` interdit par la même construction.
L’inégalité `α(X∪Z)≤2` rend alors `X` complet.
L’ensemble `X` contient au moins deux sommets puisque
`Y∪Z` a au plus huit sommets et `t≥10`. Il se rattache
par une attache unique et le groupe `X` a au plus sept
sommets. Il ne reste aucune arête entre `X` et `Y`.
Pour `|Y|≥2`, les sommets de `Y` ont une attache commune
unique. Si `|Y|=1`, il y a au plus `m-1` attaches.
On obtient les bornes 174 pour `m=12` et 158 pour `m=11`.

Si `Z` est vide et `|Y|≥2`, aucune arête ne relie
`X` et `Y`. Pour `|Y|=1`, seuls des sommets isolés
dans `X` pourraient avoir une arête vers `Y`. Or un
tel isolé obligerait le reste de `X) à être complet,
par `α(X)≤2`. Il resterait au moins huit sommets dans
cette clique, qui avec leur attache unique donneraient
un `K₉`. On peut donc borner séparément les deux groupes.

Dans `X`, les sommets qui ont plusieurs attaches sont
isolés dans `X). Les autres se répartissent par attache
unique, avec zéro arête entre groupes distincts. Il y a
au plus deux groupes non vides en comptant les isolés
à plusieurs attaches comme groupes. Si les deux groupes
existent, ils sont chacun complets, par `α(X)≤2`.
Un groupe qui est seul et a une attache unique se borne
avec `f(|X|+1)` en incluant cette attache. Deux groupes
à attache unique donnent deux cliques d’ordre au plus
huit en incluant les attaches. S’il y a un sommet à
plusieurs attaches, compter au plus `m` arêtes pour
ce sommet et la clique de l’autre groupe, avec son
attache unique. Comme `|Y|≤7` et `t≥10`, il y a
au moins trois sommets dans `X`, ce qui exclut le cas
de deux sommets à plusieurs attaches. Le vérificateur
additionne ces bornes pour obtenir 175 et 159.

### Le cas où Y est vide

Si toutes les attaches sont uniques, dès que `Z` est
non vide, on borne les arêtes extérieures par `f(t)`
et les attaches par `t-1`. Sinon, on retrouve le
décompte par un ou deux groupes à attache unique.

Deux sommets à plusieurs attaches seraient tous deux isolés
dans `X`. Alors `α(X)≤2` oblige `X` à n’avoir que ces
deux sommets. La clique `Z` a taille au moins huit. Au-delà
de huit elle contient un `C₉`. À huit, chacun des deux
sommets de `X` a au plus un voisin dans `Z`, car deux
voisins dans un `K₈` ferment un `C₉`. Un autre sommet
de `Z` et les deux sommets de `X` forment alors un
stable extérieur de taille trois.

S’il y a exactement un sommet `x` à plusieurs attaches,
le reste de `X` est une clique `P`, à nouveau par
`α(X)≤2`. Elle a au moins deux sommets. Le cas vide
laisserait dans `Z` une clique d’au moins neuf. Le cas
d’un singleton est écarté comme pour les deux isolés
dans le paragraphe précédent. Tous les sommets de
`P` partagent une attache unique. Tout sommet de
`Z` non adjacent à `x` est complet à `P`, car un
non-voisin dans `P` produirait un stable de taille trois.
À l’inverse, un voisin de `x` dans `Z` ne peut toucher
`P`, sinon un chemin extérieur de longueur trois
`x,z,p,p'` ferme un `C₉` par les deux attaches dans
`A`, toujours disponibles puisque `x` a plusieurs
attaches. De même la coexistence de voisins et de
non-voisins de `x` dans `Z` donne un tel chemin
`x,z,z',p` puisque `Z` est complet. Si aucun sommet
de `Z` ne voit `x`, la clique `P∪Z` a taille `t-1≥9`.
Sinon, tout `Z` voit `x` et aucun de ses sommets
ne voit `P`. Les cliques `P` avec son attache et
`Z∪{x}` ont alors chacune ordre au plus huit. Le
vérificateur effectue la maximisation entière de leurs
tailles, plus les `m` attaches possibles de `x`.
Les bornes 175 et 159 sont atteintes par les mêmes
témoins que pour le bloc biparti de taille maximale.

## Recherche locale bornée

L’algorithme effectue 500 perturbations par configuration et
par borne sur l’indépendance. Les configurations partent d’un
noyau biparti avec deux cliques rattachées, ou d’un anneau de
cinq cliques, avec ou sans maintien de la 2-connexité sur
les 33 sommets. Dans l’anneau chaque clique a deux points
d’attache distincts. Tout cycle passant d’une clique à l’autre
a longueur au moins dix. Après une suppression
aléatoire d’arêtes, chaque arête proposée est ajoutée
seulement en l’absence d’un chemin simple de longueur huit
entre ses extrémités. Une suppression est annulée si elle
fait apparaître un stable trop grand.

Les meilleurs nombres d’arêtes trouvés sont 175 et 159.
Le vérificateur indépendant contrôle les listes d’arêtes,
les nombres d’indépendance exacts et l’absence de `C₉`.
Ces valeurs donnent des bornes inférieures pour le problème
sans restriction sur les blocs. La borne supérieure générale
175 reste indéterminée pour les deux valeurs de `d`.

- Füredi et Gunderson, *Extremal numbers for odd cycles*,
  théorème 1. [Texte](https://arxiv.org/pdf/1310.6766#page=3)
