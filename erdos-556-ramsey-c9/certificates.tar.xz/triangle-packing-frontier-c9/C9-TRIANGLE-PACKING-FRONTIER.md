# Blocs d’ordres 26 à 29 et familles de dix triangles

Soit $B$ un bloc candidat de la [réduction à une couleur](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est sans $C_9$, vérifie $\alpha(B)\le13$ et $\omega(B)\le5$, et possède au moins
$m_b=176-\operatorname{ex}(34-b,C_9)$ arêtes à l’ordre $b$.
Soit $q$ le maximum de triangles sommet-disjoints dans $B$.

## Retrait successif de sommets de degré minimal

Aux ordres $26\le b\le29$, [answer-17](../packing-bridges-c9/C9-PACKING-BRIDGES.md)
interdit dans $B$ tout noyau biparti induit qui réalise les chemins
$2,4,6$ entre sommets distincts d’une même partie et $3,5,7$ entre parties.
L’interdiction s’applique donc à tout sous-graphe induit de $B$. Si un tel
sous-graphe est biparti, chacune de ses parties a taille au plus 13. On
peut ainsi appliquer le majorant biparti d’[answer-18](../mixed-cuts-c9/C9-MIXED-CUTS.md)
à ce sous-graphe. Le calcul de ce majorant utilise seulement le plafond
des tailles de parties et l’absence de noyaux. En particulier tout
rectangle $4$ par $4$ satisfait les contraintes de ce calcul, puisque
l’induction est transitive. On note $U(n)$ le plafond obtenu à l’ordre $n$.

Soit $H$ un sous-graphe induit à $n$ sommets avec un minorant d’arêtes
$M>U(n)$ et $M>4(n-1)$. Il est non biparti et sa circonférence est au
moins neuf par le théorème d’Erdős et Gallai. Le théorème de Brandt
implique alors que $M>\lfloor(n-1)^2/4\rfloor+1$ donne un $C_9$.
Tant que cette dernière inégalité échoue, le théorème 1.7 de Brandt,
Faudree et Goddard force $\delta(H)<(n+2)/3$. En effet, au-delà de ce
seuil, le graphe non biparti contiendrait tous les cycles de longueur
comprise entre sa maille (3 ou 4) et sa circonférence. On peut donc
retirer un sommet de degré au plus $\lfloor(n+1)/3\rfloor$ et continuer
avec le minorant $M-\lfloor(n+1)/3\rfloor$.
[Article d’Erdős et Gallai](https://combinatorica.hu/~p_erdos/1959-10.pdf),
[article de Brandt](https://doi.org/10.1016/S0166-218X(97)00032-2),
[théorème 1.7 de Brandt, Faudree et Goddard](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf#page=5).

Le rejeu calcule $U(n)$ et vérifie les deux premières inégalités à chaque
étape. Il s’arrête quand le minorant franchit aussi le plafond de Brandt.

| Ordre initial | Seuil initial | Ordre terminal | Minorant terminal | Plafond biparti | Plafond de Brandt |
|---:|---:|---:|---:|---:|---:|
| 26 | 148 | 23 | 123 | 90 | 122 |
| 27 | 155 | 22 | 113 | 83 | 111 |
| 28 | 161 | 21 | 103 | 76 | 101 |
| 29 | 166 | 19 | 84 | 64 | 82 |

Cela exclut les quatre ordres entiers, indépendamment du nombre de
triangles disjoints.

## Chemins courts entre triangles et sommets du reste

On fixe $q$ triangles d’une famille maximale en cardinalité et on
note $J$ le reste induit. Il est sans triangle. Pour un sommet $x$ de
$J$, notons $D_x$ les triangles qui contiennent au moins deux de
ses voisins. On examine des chaînes sur trois triangles distincts,
en choisissant une arête dans chacune des deux coupes.

- Si les deux extrémités appartiennent à $D_x$ et que les arêtes
  choisies touchent des sommets distincts du triangle médian, les
  passages internes de longueurs $2,1,2$ et les quatre autres
  arêtes donnent un $C_9$. C’est la contrainte à un sommet
  d’[answer-21](../ten-triangles-c9/C9-TEN-TRIANGLES.md).
- Si $xy$ est une arête de $J$, il suffit que $x$ et $y$ aient, dans
  les triangles extrêmes respectifs, des voisins différents des
  bouts choisis pour les coupes. Les passages internes $2,0,2$
  conviennent si les deux bouts médians coïncident, et $1,1,2$ sinon.
  Les cinq autres arêtes ferment un $C_9$.
- Si $x,z,y$ est un chemin dans $J$, le même choix des bouts sur
  trois triangles donne un $C_9$ avec les six arêtes externes et
  les passages $1,0,2$ ou $1,1,1$. Avec une seule coupe entre deux
  triangles, les deux passages internes de longueur 2 donnent
  aussi un $C_9$ avec les cinq arêtes externes, dès que les voisins
  de $x,y$ peuvent être choisis distincts des bouts de cette coupe.
  Cette dernière contrainte figure déjà dans les chemins de réserve
  d’answer-21.

Ainsi, pour chaque paire $x,y$ reliée dans $J$ par une arête ou par
un chemin de longueur deux, un triangle médian $V$ ne peut avoir
des coupes non vides vers deux triangles distincts, l’un dans
$A=D_x\setminus\{V\}$ et l’autre dans $C=D_y\setminus\{V\}$.
Les coupes non vides de $V$ vers $A\cup C$ se limitent donc à un
sous-ensemble de $A\setminus C$, un sous-ensemble de $C\setminus A$,
ou un seul membre de $A\cap C$. Au moins
$$
|A\cup C|-\max\bigl(|A\setminus C|,|C\setminus A|,\mathbf{1}_{A\cap C\ne\varnothing}\bigr)
$$
de ces coupes sont vides. Pour chaque $V$, on prend la plus forte
borne parmi les paires du reste, puis on somme sur les médiateurs.
Chaque coupe vide peut être comptée au plus deux fois et coûte deux
unités dans le déficit d’answer-21. La somme est donc un minorant
du déficit. On prend son maximum avec les autres déficits certifiés.

## Rejeu des coupes et des attaches

Le calcul réutilise les composantes lourdes, les chemins riches,
le budget d’étoiles et l’alternative selon la présence d’un $K_{2,3}$
d’[answer-20](../eleven-triangles-c9/C9-ELEVEN-TRIANGLES.md) et
d’answer-21. Les tables prennent le nombre réel $q$ de triangles,
avec $3q$ arêtes internes et une base de $2\binom q2$ pour les coupes.
Le graphe des étoiles augmenté possède $q+|J|$ unités. La preuve
par relèvement des cycles d’answer-21 s’applique à ces tailles.
La borne est calculée pour chacune des formes non isomorphes de $J$.
Les cases rejouées ont entre un et trois sommets dans le reste.

L’archive réutilise le vérificateur C++ d’answer-21. Dans ses tableaux
de capacité fixe, les sommets inactifs sont isolés et les positions
de triangles inactives n’ont aucun contact. Ils n’interviennent ni
dans les chemins de réserve, ni dans les appariements des paires
résiduelles, ni dans les pertes de coupes. Un décalage de $176-m_b$
dans la table permet au comparateur d’origine de tester exactement
le seuil $m_b$. Les profils qui violent déjà une condition
nécessaire sont écartés. Pour chaque profil admissible au premier
passage, le majorant est strictement inférieur à $m_b$.

| Ordre | Triangles | Sommets du reste | Seuil | Majorant certifié |
|---:|---:|---:|---:|---:|
| 26 | 8 | 2 | 148 | 147 |
| 27 | 8 | 3 | 155 | 154 |
| 29 | 9 | 2 | 166 | 165 |
| 30 | 9 | 3 | 170 | 169 |
| 31 | 10 | 1 | 173 | 172 |
| 32 | 10 | 2 | 175 | 174 |

Les trois premières lignes donnent un contrôle indépendant dans
des ordres déjà exclus ci-dessus. Aux ordres 30 et 33, les cas à
dix triangles ont été exclus dans answer-19 et answer-21. Le cas
de onze triangles a été exclu dans answer-20. Les seuls ordres
encore possibles pour le bloc candidat sont donc 30 à 33, avec
au plus neuf triangles disjoints. Parmi les 48 couples $(b,q)$
étudiés pour $q\ge5$, 19 restent ouverts. Le cas général de $C_9$
et le stable de taille 13 restent ouverts.

Depuis le répertoire de ce document dans le ZIP extrait, avec
Python 3 et un compilateur C++17, lancer

~~~sh
python3 -B verify-triangle-frontier.py | cmp - triangle-frontier-certificate.json
~~~
