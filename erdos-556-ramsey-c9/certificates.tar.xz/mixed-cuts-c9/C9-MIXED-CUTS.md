# Coupes mixtes et bicliques autour de triangles disjoints

Soit $B$ un bloc candidat de la
[réduction à une couleur](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est 2-connexe, non biparti, sans $C_9$, d’indépendance au plus 13,
d’ordre $25\le b\le33$, et a au moins
$m_b=176-\operatorname{ex}(34-b,C_9)$ arêtes. Son nombre
de clique est au plus cinq. On fixe une famille de taille
maximum $q$ de triangles sommet-disjoints, et on note $H$
le reste, qui est sans triangle.

## 1. Chemins mixtes et coupes adjacentes

Considérons un cycle de trois ou quatre triangles distincts.
Sur un segment non vide du cycle, les coupes sont des étoiles
saturées, orientées le long du segment. Chaque autre coupe
du cycle n’est pas contenue dans une étoile, et il y en a
au moins une. On choisit une arête de la dernière coupe
hors segment dont l’extrémité sur le premier triangle
diffère du premier centre. On remonte ensuite les coupes
hors segment. À chaque pas, on peut choisir une extrémité
différente de celle déjà utilisée, car les arêtes ne sont
pas toutes incidentes à un seul sommet. Sur le segment
dirigé, chaque centre touche les trois sommets du triangle
suivant. On choisit une entrée distincte de la sortie
prescrite, qu’elle soit un autre centre ou l’extrémité de
l’arête hors segment. Ce choix ferme le circuit avec
des entrées et sorties distinctes partout.

Chaque passage interne peut alors avoir longueur un ou
deux. Pour trois triangles, on prend trois passages de
longueur deux. Pour quatre, on en prend un de longueur
deux et trois de longueur un. On obtient un $C_9$ dans
les deux cas. Cela interdit notamment une étoile et deux
coupes riches sur un triangle, une étoile et trois coupes
riches sur un quadrilatère, ou deux étoiles dirigées
en série et deux coupes riches sur un quadrilatère.

Un second contrôle utilise trois triangles étiquetés,
avec des coupes successives de sept et quatre arêtes.
Pour chacun des $\binom97\binom94=4536$ choix, le vérificateur
trouve un $C_9$ dans les neuf sommets, même en supprimant
toute arête entre les triangles extrêmes. Il énumère les
chemins simples issus du premier sommet et vérifie
l’arête de fermeture. Par monotonie, une coupe de
sept arêtes ou plus ne partage donc aucun triangle avec
une autre coupe d’au moins quatre arêtes.

Les coupes d’au moins quatre arêtes sont riches et leur
graphe réduit est sans $C_3,C_4$ par
[answer-12](../triangle-packing-c9/C9-TRIANGLE-PACKING.md).
Soient $i$ le nombre de coupes de sept ou huit arêtes
et $j$ le nombre de coupes de quatre à six arêtes.
Les $i$ coupes forment un couplage isolé dans ce graphe.
Les $j$ autres sont portées par les $t=q-2i$ triangles
restants. On a $j\le\operatorname{ex}(t;C_3,C_4)$.
Chaque paire d’arêtes adjacentes parmi les $j$ force
une coupe d’au plus deux arêtes entre les deux extrémités.
Une troisième coupe riche donnerait un triangle riche,
et une étoile saturée donnerait le circuit mixte déjà
interdit. Les paires d’extrémités sont toutes distinctes
par l’absence de $C_4$. Leur nombre vaut
$\sum_v\binom{d(v)}2$. Il est au moins $D(t,j)$, le
résultat obtenu en équilibrant les $t$ degrés entiers
de somme $2j$.

Les coupes de trois arêtes hors des coupes riches sont
des étoiles saturées. Leur graphe est sans $K_4$ par
[answer-17](../packing-bridges-c9/C9-PACKING-BRIDGES.md).
Il y en a au plus $\lfloor q^2/3\rfloor$ par Turán.
Avec $N=\binom q2$, le nombre total d’arêtes entre
triangles est donc au plus
$$
2N+6i+4j+
\min\!\left(\lfloor q^2/3\rfloor,\ N-i-j-D(t,j)\right).
$$
Le vérificateur maximise cette expression sur les
couples entiers $(i,j)$ admissibles. Les bornes exactes
de girth au moins cinq utilisées ici sont celles du
théorème 3.1 de Garnick, Kwong et Lazebnik.
[Article de Garnick, Kwong et Lazebnik](https://bpb-us-w2.wpmucdn.com/sites.udel.edu/dist/3/7714/files/2022/02/ex34a_v2.pdf)

## 2. Bicliques et rectangles proches d’un noyau

Aux ordres 25 à 29, answer-17 exclut tout noyau biparti
induit muni des chemins prescrits. Le $K_{4,4}$ possède
ces chemins. Dans $H$, un $K_{4,4}$ serait induit, car
toute arête interne créerait un triangle. Dans $B$,
un $K_{5,5}$ serait induit, car toute arête interne
fermerait un chemin alterné de longueur huit en $C_9$.
Il contiendrait donc un $K_{4,4}$ induit. Ainsi $K_{4,4}$
est interdit dans $H$ et $K_{5,5}$ est interdit dans $B$.
Ces exclusions sont relatives aux ordres 25 à 29.

Le contrôle local va plus loin. Pour chaque rectangle
biparti $4$ par $4$ auquel il manque au plus trois
arêtes, on vérifie la présence des chemins simples de
longueurs $2,4,6$ entre sommets d’un même côté et
$3,5,7$ entre sommets opposés. Les seuls échecs sont les
32 configurations où les trois arêtes manquantes sont
sur la même ligne ou la même colonne. Tout rectangle
induit de $H$ ayant au moins 14 arêtes est donc exclu.
À 13 arêtes, les seules configurations encore permises
ont toutes leurs pertes sur un sommet.

Dans un sous-graphe biparti induit de $H$ avec parties
de tailles $a,c\ge4$, fixons quatre sommets de la
première partie. Pour chacun des $c$ sommets en face,
notons $j$ son degré dans ces quatre sommets. Il y a
au plus trois degrés égaux à quatre. La somme des
quatre plus grands degrés est au plus 13, et si elle
vaut 13, leurs valeurs ordonnées sont $(4,4,4,1)$ ou
$(4,3,3,3)$. Pour des coefficients $w_2,w_3,w_4$ entiers
entre 0 et 4, on calcule le maximum de
$\sum_v\sum_{\ell=2}^4 w_\ell\binom{j(v)}{\ell}$ sur les
effectifs vérifiant ces conditions. Pour le calcul
des scores, on peut remplacer les zéros par des uns.
La seule nouvelle liste des quatre plus grands degrés
qui peut atteindre 13 est alors $(4,4,4,1)$, qui est
autorisée dans la relaxation.

En sommant sur tous les choix de quatre sommets, un
sommet de degré $d$ contribue
$$
\sum_{\ell=2}^4 w_\ell\binom{d}{\ell}\binom{a-\ell}{4-\ell}.
$$
Les différences discrètes de ce terme sont croissantes.
À somme des degrés donnée, son total est donc minimal
lorsque les degrés des $c$ sommets diffèrent d’au plus un.
On impose cette inégalité dans les deux sens. On ajoute
la récurrence d’answer-17 qui retire un sommet de degré
au plus $\lfloor(c+3)/2\rfloor$ ou $\lfloor(a+3)/2\rfloor$.
Cette récurrence repose sur l’existence de deux sommets
du même côté ayant au plus trois voisins communs.
Pour des parties de tailles 9 et 10, ou 11 et 12, les
majorants combinés donnent respectivement 64 et 90 arêtes.

## 3. Reste sans triangle possiblement non biparti

Dans un reste sans triangle et non biparti, tout sommet
hors du plus court cycle impair a au plus deux voisins
sur le cycle, comme dans answer-17. On peut retirer
tout le cycle, ou en retirer un sommet dont le degré
est au plus $\lfloor2|H|/5\rfloor$. Ces deux majorants
récursifs, combinés au maximum sur les bipartitions dont
les parts ont taille au plus 13 et à la borne de Mantel,
donnent un premier majorant $U(n)$ sur $n$ sommets.

On sépare ensuite les couches de pentagones.

- S’il n’y a aucun pentagone et que le reste est non
  biparti, son plus court cycle impair a longueur 7 ou
  au moins 11. Pour 7, on utilise la formule d’answer-8
  en remplaçant la borne de Mantel sur la couche
  résiduelle par $U$. Avec $r=n-7$ et $d$ doubles
  attaches au cycle, le majorant est $7+r+d+U(r-d)$.
  Pour une longueur $g\ge11$, il vaut
  $g+2(n-g)+U(n-g)$.
- S’il y a deux pentagones disjoints, on choisit une
  paire qui maximise le nombre $w$ d’arêtes de leur
  coupe. Les plafonds d’attaches par sommet vers la
  paire sont $2,3,3,2,2,2$ pour $w$ de 0 à 5.
  Le vérificateur rejoue les contrôles d’answer-9 qui
  établissent ces valeurs. On ajoute $10+w$ et le
  majorant $U(n-10)$ aux attaches.
  [Certificat des couches de pentagones](../pentagon-layers-c9/C9-PENTAGON-LAYERS.md)
- Si une famille maximum de pentagones a taille un, on
  retire un pentagone. Le reste est sans pentagone.
  S’il est non biparti, le premier cas s’applique, avec
  au plus deux attaches au pentagone par sommet.
  S’il est biparti, on utilise le comptage suivant.

### Doubles attaches au pentagone dans un reste biparti

Marquons les sommets qui ont deux voisins sur le
pentagone. Aucun chemin simple de longueur quatre dans
le reste ne joint deux marqués. En effet, leurs deux
paires de labels contiennent deux labels reliés par un
arc de longueur trois sur le pentagone. Cet arc, les
deux attaches et le chemin de longueur quatre forment
un $C_9$. Pour vérifier l’existence de l’arc, on fait
tourner la première paire en $\{0,2\}$. Un label sans
arc de longueur trois vers 0 ni 2 doit être 1. La
seconde paire contient deux labels et ne peut donc
éviter les deux arcs possibles.

Fixons $p$ marqués dans une partie et $c$ colonnes de
l’autre partie. Si deux colonnes de degré au moins
deux vers les marqués ont un voisin commun, leurs
voisinages dans les marqués doivent être la même
paire. Sinon, on peut partir d’un marqué, traverser
la première colonne, le voisin commun, puis la
seconde colonne et atteindre un troisième marqué.
Ainsi les supports des colonnes de degré au moins
trois sont disjoints de tous les autres supports de
degré au moins deux. Si toutes les colonnes ont
degré au plus deux, le total est au plus $2c$. Avec
une colonne de degré au moins trois et aucune de
degré deux, le total est au plus $p+c-1$. Avec les
deux types, on réserve au moins deux lignes pour
les colonnes de degré deux. Les grandes colonnes
contribuent au plus $p-2$ et les autres au plus
$2(c-1)$, d’où $p+2c-4$. On prend le maximum de ces
trois expressions, plafonné par $pc$.

On applique la perte correspondante aux $p$ marqués
de la première partie et celle aux $q'$ marqués de
la seconde. Si ces pertes valent $L_A,L_C$, il manque
au moins $\max(L_A,L_C,L_A+L_C-pq')$ arêtes dans la
coupe bipartie. Pour chaque taille de parties et
nombre d’arêtes, le contrôle calcule donc un plafond
sur $p+q'$. Les attaches au pentagone sont au plus
la taille du reste plus ce plafond.

## 4. Retrait des triangles et contrôle des seuils

La maximalité en nombre de la famille garantit que,
pour chaque triangle $T$ choisi, le graphe induit
par $T\cup H$ n’a pas deux triangles disjoints.
On peut donc reprendre le comptage d’answer-17
indépendamment pour chaque $T$. Si un voisinage dans
$H$ d’un sommet de $T$ contient trois arêtes disjointes,
les deux autres voisinages sont indépendants, de
taille au plus 13. Un voisinage de taille $d$ est
sans chemin sur huit sommets. Ses arêtes sont au
plus $3d$ par Erdős–Gallai. Les autres sommets de
$H$ ont degré au plus 13, car leurs voisinages
sont indépendants. D’où $e(H)\le3d+13(h-d)$, où
$h=|H|$. Tout seuil inférieur sur $e(H)$ donne donc
un plafond sur $d$ dans ce cas.
[Article d’Erdős et Gallai](https://combinatorica.hu/~p_erdos/1959-10.pdf)

Si aucun voisinage n’a trois arêtes disjointes, sa
taille est au plus 15 s’il est biparti, par König,
et au plus 16 sinon. À 16, il se compose d’un
pentagone et de onze sommets isolés, comme dans
answer-17. Les onze isolés ne touchent pas ce
pentagone. Les autres $h-16$ sommets le touchent
au plus deux fois. Le majorant sur $H$ privé du
pentagone donne alors un plafond sur $e(H)$.
Un plafond strictement sous le seuil exigé ramène
ces trois voisinages à une taille d’au plus 15.

Le calcul part du plafond brut sur les attaches
par triangle. Il déduit un minimum pour $e(H)$
en soustrayant du seuil $m_b$ les arêtes internes
des triangles, les coupes et les attaches. Ce
minimum resserre le plafond sur les attaches
par les deux arguments précédents. On itère tant
que le plafond diminue.

| Ordre | Majorant pour $e(H)$ à $q=1$ | Majorant total à $q=1$ | Seuil |
| ---: | ---: | ---: | ---: |
| 25 | 83 | 131 | 147 |
| 26 | 90 | 139 | 148 |
| 27 | 97 | 146 | 155 |
| 28 | 104 | 154 | 161 |
| 29 | 112 | 163 | 166 |

Tous les blocs candidats d’ordre 25 à 29 ont donc
au moins deux triangles sommet-disjoints. Les quinze
couples avec $q=2,3,4$ à ces ordres survivent aux
majorants calculés. Si $q\ge5$, les 48 couples
restent ouverts dans ce contrôle. Le majorant pour
$(b,q)=(33,11)$ passe de 278 à 222, toujours au-dessus
du seuil de 176.

## Reproduction

Depuis le répertoire de ce document dans l’archive,
exécuter `python3 -B verify-mixed-cuts.py | cmp - mixed-cuts-certificate.json`.
Le vérificateur parcourt les petits graphes étiquetés
et calcule les majorants en arithmétique entière.
Le problème général sur $C_9$ et le stable de taille
13 restent ouverts.
