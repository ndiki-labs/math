# Exclusion de la maille impaire 5 aux ordres 29 à 33

Soit $B$ un graphe sans $C_3$ ni $C_9$, qui contient un $C_5$ et
satisfait $\alpha(B)\le13$. Pour $b=|V(B)|$ de 29 à 33, on exclut
les seuils d’arêtes suivants.

| Ordre $b$ | 29 | 30 | 31 | 32 | 33 |
| ---: | ---: | ---: | ---: | ---: | ---: |
| Minimum $m$ de la réduction précédente | 166 | 170 | 173 | 175 | 176 |
| Minimum dans $B-C_5$ | 113 | 115 | 116 | 116 | 115 |

Le premier seuil vaut $176-\operatorname{ex}(34-b,C_9)$, comme
dans [answer-7](../mono-extremal/C9-MONO-EXTREMAL.md). Le second
vaut $m-5-2(b-5)$. Il y a au plus deux arêtes d’un sommet vers
un pentagone, puisque ses voisins sur le cycle doivent former un
stable. Les ordres 25 à 28 sont déjà exclus par
[answer-8](../odd-block-c9/C9-ODD-BLOCK.md). En particulier tout
bloc candidat à la réduction monochrome doit contenir un triangle.

## 1. Deux pentagones et leur voisinage

Dans un graphe sans triangle, les pentagones sont induits.
Pour deux pentagones étiquetés, la ligne d’attachements de chaque
sommet du premier est l’un des onze stables du second. Deux lignes
consécutives sur le premier cycle doivent être disjointes, y compris
la dernière et la première. Ces deux conditions couvrent tous les
triangles traversant la coupe. Le vérificateur énumère ces lignes
et rejette les graphes contenant un $C_9$.

| Arêtes de la coupe $w$ | 0 | 1 | 2 | 3 | 4 | 5 |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Graphes étiquetés sans $C_3$ ni $C_9$ | 1 | 25 | 150 | 300 | 150 | 25 |
| Voisins possibles d’un sommet extérieur dans l’union | 4 | 4 | 3 | 2 | 2 | 2 |
| Même borne pour une paire maximisant $w$ | 2 | 3 | 3 | 2 | 2 | 2 |

Il ne reste aucune coupe d’au moins six arêtes. Pour la deuxième
ligne de bornes, le vérificateur ajoute un sommet extérieur $x$.
Son voisinage dans l’union des cycles est indépendant et deux de
ses voisins distincts ne peuvent être les extrémités d’un chemin
simple de longueur 7 dans l’union.

Pour la dernière ligne, supposons que $x$ ait deux voisins sur un
des pentagones. Ils sont à distance 2 et ont un unique milieu sur
le pentagone. On peut remplacer ce milieu par $x$ pour obtenir un
autre pentagone, toujours disjoint de l’autre cycle. La maximalité
de $w$ impose que $x$ ait au plus autant de voisins vers l’autre
cycle que le milieu remplacé.

Pour une paire maximisant $w$, notons $T$ les sommets extérieurs
ayant trois voisins dans l’union. Le même rejeu contrôle tous les
couples ordonnés de voisinages de taille 3, y compris deux
voisinages identiques. Leurs profils ont soit un voisin commun,
soit deux voisins reliés dans les cycles par un chemin simple
de longueur 6. Dans les deux cas une arête entre les deux sommets
de $T$ donnerait un $C_3$ ou un $C_9$. De plus, leurs profils
contiennent toujours deux voisins reliés dans l’union par un
chemin simple de longueur 3. Un chemin de longueur 4 entre deux
sommets de $T$ dans le reste donnerait donc un $C_9$.
Le vérificateur contrôle 900 couples pour $w=1$ et 450 pour $w=2$.

Toutes les longueurs sont mesurées en arêtes. Pour un cycle de
longueur $\ell$, le rejeu fixe son plus petit sommet et cherche
un chemin simple qui y revient après $\ell$ arêtes. Pour un chemin
entre deux extrémités prescrites, ces extrémités sont exclues
de l’ensemble des sommets utilisables à l’intérieur du chemin.

## 2. Trois pentagones disjoints

Supposons qu’il existe trois pentagones disjoints. Choisissons un
triplet qui maximise le nombre total $W$ d’arêtes entre cycles.
Notons $d_i$ le nombre de voisins d’un sommet extérieur $x$ dans
le cycle $i$. Chaque $d_i$ vaut au plus deux. Si $d_i=2$, le
remplacement du milieu impose que $\sum_{j\ne i}d_j$ ne dépasse
pas le nombre de voisins du milieu dans les deux autres cycles.

Si les trois $d_i$ valent deux, la borne pour deux cycles impose
au plus une arête entre toute paire. Le remplacement gagnerait
au moins deux arêtes, ce qui est impossible.

Pour des comptes $(2,2,1)$, les deux cycles visités deux fois ont
au plus une arête entre eux et au plus deux chacun vers le dernier.
La maximalité force chacune de ces trois bornes à être atteinte
et les arêtes à être portées par les milieux remplacés. Les deux
milieux sont reliés. Chacun a deux voisins dans le dernier cycle.
Après avoir fixé les milieux et le voisin de $x$ dans le dernier
cycle par rotation, il reste cinq stables de taille deux pour
chaque milieu. Chacun de ces 25 graphes contient un triangle ou
un $C_9$, ce que rejoue le vérificateur.

Le maximum d’attachements d’un sommet extérieur vaut donc quatre.
S’il vaut au plus trois, avec $r=b-15$ Mantel donne
$e(B)\le 15+15+3r+\lfloor r^2/4\rfloor<m$. S’il vaut quatre,
le tableau des paires donne $W\le11$. En effet, avec $(2,2,0)$
les trois coupes ont au plus $1,5,5$ arêtes, et avec $(2,1,1)$
elles ont au plus $2,2,5$ arêtes. La borne
$15+11+4r+\lfloor r^2/4\rfloor$ ne laisse que $b=33$.

À cet ordre le reste de 18 sommets doit avoir au moins 78 arêtes.
Il est biparti, car un graphe triangle-libre non biparti à $r$
sommets a au plus $\lfloor(r-1)^2/4\rfloor+1$ arêtes. Cette borne
résulte du comptage sur son plus court cycle impair et de Mantel,
comme dans answer-8. Chacune des deux parties a au moins huit
sommets et au plus trois arêtes sont manquantes entre elles.
Toute paire du même côté est reliée par un chemin de longueur 4
et toute paire de côtés opposés par un chemin de longueur 5.
Pour construire ces chemins, on choisit les sommets internes
en dehors des extrémités et des sommets incidents aux arêtes
manquantes.

Deux sommets distincts qui ont chacun deux voisins sur un même
pentagone ne peuvent être reliés dans le reste par un chemin
de longueur 4 ou 5. Le vérificateur contrôle les cinq paires
de labels possibles de chaque sommet. Il ne peut donc y avoir
qu’un double attachement par pentagone. Au plus trois sommets
extérieurs ont quatre voisins dans l’union. La nouvelle borne
$15+11+3r+3+\lfloor r^2/4\rfloor$ est strictement sous 176.

## 3. Comptage des attachements dans un reste biparti

Soit $J$ un reste biparti, de parties de tailles $a,b'$ et
$M$ arêtes manquantes. Les parties ont taille au plus 13.
On borne les arêtes de $J$ vers un pentagone disjoint de $J$.

### Chemins entre les parties

Fixons deux seuils de pertes $x\le b'-3$, $y\le a-3$. Appelons
denses les sommets qui ont au plus $x$ ou $y$ voisins manquants
respectivement. Si
$$
M\le x+y+(a-y-2)(b'-x-2),
$$
toute paire d’extrémités denses de côtés opposés est reliée
dans $J$ par des chemins de longueurs 3 et 5. Voici le comptage.
Avec des pertes réelles $x'\le x,y'\le y$, le membre de droite
ne diminue pas. Pour des extrémités adjacentes, les deux
ensembles de voisins disponibles pour les sommets internes
ont tailles $s=a-y'-1$, $t=b'-x'-1$. Il y manque au plus
$M-x'-y'$ arêtes. Cette borne vaut au plus $(s-1)(t-1)$,
donc il y a au moins $s+t-1$ arêtes entre ces ensembles.
Une forêt d’étoiles avec au moins deux sommets dans chaque
partie a au plus $s+t-2$ arêtes. Tout biparti sans chemin de
trois arêtes est une forêt d’étoiles. On obtient donc un
chemin interne de trois arêtes et une arête interne,
d’où les deux longueurs voulues en ajoutant les extrémités.
Si les extrémités sont non adjacentes, chaque ensemble interne
a un sommet de plus et le budget de pertes augmente d’au plus
un. La même inégalité stricte sur le nombre d’arêtes tient.

Les longueurs 3 et 5 interdisent les distances 1 et 2 entre
leurs étiquettes sur le pentagone. Si les deux extrémités sont
attachées, elles sont donc chacune attachées par un unique
label, identique des deux côtés. Dans ce cas elles ne sont
pas adjacentes, car cela ferait un triangle. Si $p,q$ sommets
denses sont attachés dans les deux parties, leurs $pq$
arêtes croisées manquent et $p+q\le13$. Quand $p,q>0$ les
seuils de pertes imposent aussi $q\le x$ et $p\le y$.

### Chemins dans une même partie

Deux sommets dans la partie de taille $a$ qui manquent
ensemble $z$ voisins, avec multiplicités, ont au moins
$b'-z$ voisins communs. Si ce nombre vaut au moins deux
et si les deux sommets n’ont pas de chemin de longueur 4,
chaque autre sommet de leur partie manque au moins $b'-z-1$
arêtes vers ces voisins communs. Cela donne
$$
M\ge z+(a-2)(b'-z-1).
$$
Pour deux sommets denses, on peut tester cette inégalité avec
$z=2x$, tant que $b'-2x\ge2$. Le membre de droite ne croît pas
avec $z$. Lorsqu’un chemin de longueur 4 existe entre chaque
paire de sommets denses de la partie, leurs labels d’attachement
ne peuvent pas être à distance 2. Les labels des attachements
simples sont alors contenus dans une paire adjacente ou un
singleton. Si un sommet est attaché deux fois, il est le seul
double et tout autre sommet attaché n’a que le milieu de ses
deux labels. Au total, les sommets denses voient au plus deux
labels, ou au plus trois en présence d’un double.

Une variante s’applique à toute une partie. Si $j$ sommets du
côté opposé manquent au moins $y+1$ voisins chacun, il manque
au plus $M-j(y+1)$ arêtes vers les $b'-j$ autres sommets de ce
côté. La même borne de voisins communs dans ces colonnes donne,
lorsqu’elle garantit un chemin de longueur 4 pour chaque paire,
au plus trois labels pour toute la partie.

### Énumération des effectifs

Une partie de taille 13 doit voir les cinq labels, et une
partie de taille 12 doit en voir au moins trois. Sinon une
étiquette ou deux étiquettes indépendantes non vues agrandissent
le stable au-delà de 13.

Le vérificateur énumère les tailles de parties, $M$ et les
seuils $(x,y)$ qui garantissent les chemins entre côtés opposés.
Pour chaque seuil, il compte $i,j$ sommets au-dessus des pertes
permises, puis $p,q$ sommets denses attachés, et les doubles
parmi ces derniers. Les $i,j$ imposent au moins
$$
\max\{i(x+1),j(y+1),i(x+1)+j(y+1)-ij\}
$$
pertes. Elles sont distinctes des $pq$ pertes imposées par les
attachements denses. Les sommets non denses contribuent au plus
$2(i+j)$ attachements et autant de labels. Le calcul maximise
le total sous ces contraintes, puis prend le minimum des bornes
entre les différents seuils. Si une énumération est vide, le
triplet $(a,b',M)$ est impossible.

## 4. Reste après une paire maximale

Puisque trois pentagones disjoints sont exclus, après retrait
de deux le reste $J$ d’ordre $r=b-10$ est sans $C_5$. On a
$e(J)\ge m-15-3r$. Pour un graphe non biparti sans $C_3,C_5,C_9$,
le certificat answer-8 fournit deux calculs. Si le plus court
cycle impair a longueur 7, sa borne vaut
$r+\max_d(d+\lfloor(r-7-d)^2/4\rfloor)$ pour $0\le d\le r-7$.
S’il a longueur au moins 11, on compte le cycle, au plus deux
attachements par sommet et le reste par Mantel. Le maximum de
ces deux calculs est strictement sous $m-15-3r$ aux cinq
ordres. Ainsi $J$ est biparti.

Pour $T$ défini à la section 1, écrivons $t_a,t_b$ ses
effectifs dans les parties. L’indépendance donne $t_at_b\le M$
et $t_a+t_b\le13$. Si une partie contient $d\ge2$ sommets de
$T$, les deux qui manquent le moins de voisins en manquent
ensemble au plus $\lfloor2M/d\rfloor$. Comme aucun chemin de
longueur 4 ne peut les relier dans $J$, la borne de la section
3 impose l’inégalité correspondante sur $M$. Cela borne
$|T|$ exactement à partir des effectifs et de $M$.

Les deux cycles ont au plus $2r+|T|$ arêtes vers $J$.
Chacun satisfait aussi séparément la borne d’attachements de
la section 3. On prend la plus petite de ces deux bornes et
on ajoute les arêtes de $J$ et celles sur les deux cycles.
Le vérificateur écarte ainsi toutes les partitions et tous
les budgets de pertes pour une paire de pentagones.

## 5. Reste après un seul pentagone

Si le nombre maximum de pentagones disjoints vaut un, on fixe
un pentagone $C$ et $H=B-V(C)$ est sans $C_5$. Le reste $H$
doit atteindre les seuils de la première table.

- Si $H$ est biparti, la section 3 clôt directement les
  ordres 29 à 31. Aux ordres 32 et 33, $H$ a 27 ou
  28 sommets, trop pour deux parties de taille au plus 13.
- Si $H$ est de maille impaire au moins 11, le comptage
  sur son plus court cycle impair ne laisse que $b=33$ et
  un cycle de longueur 11. Son reste $J$ a 17 sommets et
  au moins 70 arêtes, donc est biparti. Ses parties ont
  taille au moins sept et il manque au plus deux arêtes.
  Au moins quinze sommets de $J$ ont deux attachements au
  cycle de longueur 11, puisque
  $e(H)\ge115$ et $e(J)\le72$. Dans la plus grande partie,
  de taille au moins neuf, fixons un tel sommet et tournons
  le cycle pour que ses labels soient $0,2$. Toute autre
  extrémité de la même partie est reliée à ce sommet par
  un chemin de longueur 2. L’interdiction des cycles
  impairs de longueurs 3, 5, 7 et 9 limite les labels vus
  par la partie à $\{0,2,4,9\}$. Le stable
  $\{1,3,5,7,10\}$ sur le cycle porte alors l’indépendance
  à au moins 14.
- Si $H$ est de maille impaire 7, fixons un plus court
  cycle impair $C'$ et posons $J=H-V(C')$, d’ordre
  $r=b-12$. D’après answer-8, si $d$ sommets de $J$ ont
  deux attachements à $C'$, on a
  $e(H)\le7+r+d+e(J-D)$, où $D$ est l’ensemble de ces
  sommets. Si $J$ est non biparti, le calcul pour la
  maille impaire au moins 7 de la section 4 donne une
  borne sur $e(J)$. On prend son minimum avec Mantel
  sur $J-D$. Tous les seuils pour $e(H)$ sont alors
  impossibles.

  Si $J$ est biparti, la même inégalité borne $d$ et le
  nombre de pertes $M$ pour chaque partition. Par ailleurs,
  entre $C$ et $C'$ il y a au plus trois arêtes. Pour
  le vérifier, on énumère les onze lignes possibles sur
  le pentagone pour chacun des sept sommets de $C'$. Après
  contrôle des triangles et du $C_9$, toutes les coupes à
  quatre arêtes contiennent deux pentagones disjoints.
  Les arêtes de $C'$ vers $J$ sont au plus $r+d$, et
  les arêtes de $C$ vers $J$ satisfont la section 3.
  Additionner ce budget aux arêtes de $J$ et aux
  $5+7+3$ arêtes sur les cycles donne une borne strictement
  inférieure à $m$ dans chaque cas.

## Rejeu

Le ZIP contient cette démonstration, le certificat JSON et le
vérificateur Python. Après extraction, depuis
pentagon-layers-c9, exécuter `python3 -B verify-pentagon-layers.py | cmp - pentagon-layers-certificate.json`.
Le rejeu emploie uniquement des entiers et les deux modules de
contrôle déjà utilisés dans answer-7 et answer-8. L’argument
dépend du théorème d’extremum de Füredi et Gunderson pour
les seuils de la première table.
[Théorème 1 de Füredi et Gunderson](https://arxiv.org/pdf/1310.6766#page=3).
