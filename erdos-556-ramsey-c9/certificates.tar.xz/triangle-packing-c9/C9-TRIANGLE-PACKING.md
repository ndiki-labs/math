# Routage entre triangles et exclusion d’un noyau biparti

On travaille dans un bloc de la réduction pour $C_9$.
Il est 2-connexe, d’ordre au moins 25, sans $C_9$,
d’indépendance au plus 13, et son nombre de clique est
au plus cinq d’après [answer-11](../clique-closure-c9/C9-K6-CLOSURE.md).

## 1. Relever un cycle de triangles

Soient $T_1,\dots,T_q$ des triangles sommet-disjoints.
Une famille maximale par inclusion laisse un reste sans
triangle. L’absence de triangles dans ce reste n’implique
pas qu’il soit biparti.

Sur un cycle de $s$ triangles, supposons que chaque liaison
utilise une arête entre les deux triangles consécutifs, avec
des sommets d’entrée et de sortie distincts dans chacun.
On peut compléter chaque passage par un chemin interne
de longueur un ou deux. Les triangles sont disjoints, donc
on obtient des cycles simples de toutes les longueurs de
$2s$ à $3s$. En particulier $s=3$ et $s=4$ donnent un $C_9$.

Appelons une coupe entre deux triangles **riche** si elle a
au moins trois arêtes et que ses arêtes ne sont pas toutes
incidentes à un même sommet. Toute coupe d’au moins quatre
arêtes est riche. Nous montrons un résultat plus général.
Sur un cycle de liaisons, supposons que chaque coupe ne
soit pas contenue dans une étoile. S’il existe une coupe
riche, le cycle peut être relevé.

- Si une coupe n’est pas un couplage, on oriente le cycle
  pour qu’un sommet de son côté de départ ait au moins
  deux voisins sur le triangle suivant. On choisit ce
  sommet comme sortie initiale. La prochaine sortie peut
  être n’importe lequel des trois sommets, puisqu’on peut
  choisir une entrée différente parmi les deux voisines.
  À chaque étape suivante, les trois possibilités de
  sortie se propagent intégralement. En effet, une coupe
  qui n’est pas une étoile atteint au moins deux sommets
  du côté d’arrivée. Pour chacune des trois sorties,
  on peut choisir une entrée différente. La dernière
  étape permet donc la sortie initiale et ferme le circuit.
- Si toutes les coupes sont des couplages et qu’une
  coupe est riche, cette coupe est un couplage de taille
  trois. En commençant juste après elle, on choisit les
  arêtes successivement. À chaque passage la compatibilité
  avec l’arête précédente interdit au plus un choix, et
  chaque coupe a au moins deux arêtes. On ferme avec le
  couplage de taille trois, qui subit au plus deux exclusions,
  une à chaque extrémité.

Même avec des couplages de taille deux partout, un cycle
peut être relevé dès que les supports des deux coupes sur
un triangle ne coïncident pas. La relation de compatibilité
entre les deux petits ensembles de choix contient toujours
une permutation valide. Si les deux supports diffèrent,
la relation contient au moins trois des quatre transitions.
Après avoir choisi une permutation de transitions sur chaque
autre triangle, il reste deux possibilités pour fermer le
tour. Au moins une appartient à la relation à trois transitions.

Ainsi le graphe réduit de toutes les coupes riches est
sans $C_3,C_4$. Plus généralement aucune arête riche
n’appartient à un $C_3$ ou un $C_4$ du graphe réduit des
coupes non contenues dans une étoile. Un éventuel cycle
de ce graphe de longueurs trois ou quatre est entièrement
formé de couplages de taille deux, dont les supports
s’accordent à chaque triangle.

## 2. Portée de la borne d’arêtes

Les nombres extrémaux exacts de coupes riches aux ordres
8, 9, 10 et 11 sont au plus 10, 12, 15 et 16.
[Théorème 3.1 de Garnick, Kwong et Lazebnik](https://bpb-us-w2.wpmucdn.com/sites.udel.edu/dist/3/7714/files/2022/02/ex34a_v2.pdf).
Une coupe non riche a au plus trois arêtes. Une coupe
riche en a au plus huit, car neuf formeraient un $K_6$.
La borne qui en résulte sur l’union est
$$
3q+3\binom q2+5\,\operatorname{ex}(q;C_3,C_4).
$$
Pour onze triangles elle vaut 278. Cette contrainte de
routage ne fournit donc pas à elle seule la borne de
175 recherchée. Les coupes en étoile et les attachements
au reste comptent encore dans le problème.

## 3. Un triangle et un noyau biparti dense

Soit $D$ un graphe biparti disjoint d’un triangle $T$.
Supposons qu’il relie toute paire de côtés opposés par
un chemin de longueur cinq et toute paire distincte du
même côté par un chemin de longueur six. Deux arêtes
d’attachement disjointes entre $T$ et $D$ formeraient
un $C_9$ avec un de ces chemins et un chemin interne
au triangle de longueur deux ou un, respectivement.
Une coupe sans deux arêtes disjointes est contenue dans
une étoile. Si une partie de $D$ a treize sommets indépendants
dans $B$, chacun des trois sommets de $T$ doit toucher
cette partie, par $\alpha(B)\le13$. Dans ce cas la
coupe consiste exactement en trois arêtes vers un unique
sommet de cette partie.

## 4. Exclusion d’une coupe 13 par 4 avec au plus deux pertes

Supposons qu’il existe deux ensembles disjoints $A,D$,
de tailles 13 et 4, avec au plus deux arêtes manquantes
entre eux. On autorise des arêtes internes au départ.
Au moins onze sommets de $A$ touchent les quatre sommets
de $D$, et tout sommet de $A$ a au moins deux voisins
dans $D$.

Toute paire distincte de $A$ est reliée dans cette coupe
par des chemins alternés de longueurs six et huit.
On choisit des voisins distincts des deux extrémités dans
$D$ comme première et dernière positions, puis des
sommets intermédiaires de $A$ complets vers $D$. Toute
paire $A$–$D$ est reliée par un chemin de longueur sept.
On part d’un voisin de l’extrémité dans $A$ différent de
l’extrémité dans $D$, puis on traverse les sommets restants
de $D$ à l’aide de sommets complets de $A$.

Le chemin de longueur huit impose que $A$ soit indépendant.
Tout sommet de $R=B-(A\cup D)$ doit alors toucher $A$,
par $\alpha(B)\le13$. Il ne peut toucher aussi $D$, par
le chemin de longueur sept. Si deux sommets de $R$ sont
adjacents, ils ont nécessairement la même attache unique
dans $A$. Deux attaches distinctes fermeraient un $C_9$
avec un chemin de longueur six. Une composante de $R$
avec une arête s’attacherait donc par un seul sommet
de $A$, ce qu’interdit la 2-connexité. Ainsi $R$ est
indépendant. Il est non vide et chacun de ses sommets
voit au moins deux sommets de $A$.

Choisissons $w\in R$ et deux de ses voisins distincts
$x,y\in A$. Pour toute paire prescrite de sommets de
$D$, on construit un chemin de longueur huit entre eux,
alternant entre $D\cup\{w\}$ et $A$. On ordonne les quatre
sommets de $D$ avec les deux extrémités prescrites, puis on
insère $w$ dans un intervalle entre deux sommets consécutifs.
Ceux-ci doivent être adjacents respectivement à $x,y$,
à permutation près. Le vérificateur contrôle les 222
choix de profils et d’extrémités, avec au plus deux pertes
sur les lignes $x,y$. Les deux autres intervalles utilisent
deux sommets de $A$ complets vers $D$, distincts de $x,y$.
Tout bord interne à $D$ ferait donc un $C_9$. Ainsi
$A$ et $D\cup R$ sont des parties indépendantes, ce qui
contredit le triangle de la branche étudiée.

Après extraction du ZIP, depuis le dossier
`triangle-packing-c9`, exécuter
`python3 -B verify-triangle-packing.py | cmp - triangle-packing-certificate.json`.
