# Ordre 31 et huit triangles à l’ordre 32

On reprend le bloc candidat $B$ de la
[réduction monochrome](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est sans $C_9$, a un nombre d’indépendance au plus 13 et
un nombre de clique au plus 5. À l’ordre $b$, le seuil
d’arêtes est $176-\operatorname{ex}(34-b,C_9)$.
Le [jalon précédent](../bipartite-transition-and-eight-c9/C9-BIPARTITE-TRANSITIONS-AND-EIGHT.md)
garantit que la suite des retraits à l’ordre 31 reste
non bipartie jusqu’à 20 sommets et laisse au moins 78
arêtes à cet ordre.

## 1. Clôture de l’ordre 31

Soit $H_n$ le graphe induit en retirant successivement
un sommet de degré minimal. Tant que $H_n$ est non
biparti et de circonférence au moins neuf, le théorème
1.7 de Brandt–Faudree–Goddard impose un degré minimal
au plus $\lfloor(n+1)/3\rfloor$. Sinon une maille de
trois ou quatre et une circonférence d’au moins neuf
donneraient un $C_9$. Les seuils successifs sont les
suivants. [Théorème de Brandt–Faudree–Goddard](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf#page=5).

| Ordre de $H_n$ | 20 | 19 | 18 | 17 | 16 | 15 | 14 | 13 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Minorant d’arêtes | 78 | 71 | 65 | 59 | 53 | 48 | 43 | 38 |

On vérifie par récurrence que chaque graphe a une
circonférence d’au moins neuf et demeure non biparti.

### Exclure le premier passage biparti

Supposons que $H_n$ soit le premier graphe biparti, de
degré minimal exact $d$. Ajouter un sommet de degré
zéro ou un à un graphe biparti conserve la bipartition,
donc $d\ge1$. Dans tout graphe antérieur $H_k$, pour
$k>n$, un sommet de degré $d$ dans $H_n$ a gagné au plus
$k-n$ voisins. Le degré du sommet retiré de $H_k$ est
donc au plus $\min(\lfloor(k+1)/3\rfloor,d+k-n)$.
On soustrait ces degrés du minorant déjà acquis à
chacun des ordres antérieurs $j$. Pour le premier
biparti hypothétique, on obtient
$$
e(H_n)\ \ge\
\max_{n\le j\le31}
\left(m_j-\sum_{k=n+1}^{j}
\min\!\left(\left\lfloor\frac{k+1}{3}\right\rfloor,d+k-n\right)\right),
$$
où $m_j$ est le minorant de la chaîne de retraits.

On compare ce minorant au [plafond biparti conditionné par degré](../order31-and-core-contacts-c9/C9-ORDER-31-AND-CORE-CONTACTS.md).
Pour les tailles de parties et degrés restants, on
applique le test de chemins d’answer-25 ou le critère
suivant. Si les parties contiennent chacune au moins
quatre sommets, si le degré minimal est au moins deux
et s’il manque au plus $n-7$ arêtes, alors toutes les
paires opposées sont reliées par un chemin de longueur
sept. Si tous les codegrés du même côté sont au moins
trois, c’est le critère d’answer-24. Autrement, une
paire du même côté face à une partie de taille $c$
ayant un codegré au plus deux concentre au moins
$c-2$ pertes. Il y a donc au moins
$n-4-(n-7)=3$ sommets universels dans le côté de cette
paire. La construction du chemin impair d’answer-26
avec trois sommets universels demande seulement que les
degrés du côté universel soient au moins deux.

Le vérificateur énumère les paramètres entiers de
$n=19$ à $n=13$. Après comparaison des plafonds, tous
les cas restants possèdent les chemins de longueur
sept. À un premier passage biparti, le sommet retiré
doit toucher les deux côtés de la bipartition de
$H_n$, sinon cette bipartition s’étend à $H_{n+1}$.
Le chemin de longueur sept entre ses deux attaches
donne le $C_9$ interdit.

### Maintenir la circonférence

Dans un graphe de circonférence au plus huit, chaque
bloc d’ordre au plus huit est $K_6$-free et satisfait
la borne de Turán avec cinq parties. Pour un bloc
2-connexe d’ordre $m\ge9$, le plafond de Kopylov est
$$
\max(h(m,9,2),h(m,9,4)),\qquad
h(m,k,a)=\binom{k-a}{2}+a(m-k+a).
$$
On additionne ces plafonds sur chaque décomposition
possible. Avec $c$ composantes, les tailles $s_i$ des
blocs non triviaux vérifient $\sum_i(s_i-1)=n-c$.
Les ponts sont des blocs de taille deux. Les isolés
n’ajoutent aucune arête. Le calcul entier donne les
plafonds **66, 62, 58** aux ordres **19, 18, 17**.
Ils sont strictement inférieurs aux minorants requis.
[Kopylov et sa version de stabilité, théorèmes 1.3 et 2.2](https://users.renyi.hu/~furedi/PUBS3/furedi_238_kostochka_ruthluo_verstraete_Erdos-Gallai-stability_II.pdf).

À partir de 16 sommets, un graphe 2-connexe trop dense
qui aurait encore une circonférence au plus huit
relève de la stabilité de Füredi, Kostochka, Luo et
Verstraëte. Pour $13\le n\le16$, on dépasse
$h(n,9,3)$ et $h(n,9,2)$. Le graphe est donc couvert
par $H_{n,9,4}$, soit $K_4$ joint à un stable. Il
reste les possibilités suivantes pour un graphe
avec plusieurs blocs ou composantes.

| Ordre | Tailles des blocs non triviaux | Nombre de composantes |
|---:|:---|---:|
| 16 | Aucune | |
| 15 | 8 et 8 | 1 |
| 14 | 2 et 13, ou 7 et 8 | 1 |
| 13 | 2 et 12, 6 et 8, ou 7 et 7 | 1 |
| 13 | 12 avec un sommet isolé | 2 |

Pour un graphe couvert par $H_{n,9,4}$ à $n=16$ ou
$n=15$, au moins $n-5$ sommets ont degré au plus
quatre. Si plus de cinq sommets ont ce degré dans
un stade, le sommet réinséré de degré minimal au
stade précédent a degré au plus quatre. Un degré
minimal cinq exigerait qu’il soit adjacent à plus
de cinq sommets et un degré minimal supérieur est
impossible. Après une réinsertion, au plus quatre
de ces sommets perdent cette propriété. À $n=16$,
remonter d’une étape donne $e(H_{17})\le54+4=58$.
À $n=15$, remonter de deux étapes donne
$e(H_{17})\le50+8=58$. Les deux bornes sont sous 59.

Pour deux blocs de tailles au plus huit qui se
rejoignent en un sommet d’articulation, une nouvelle
grande circonférence en réinsérant le dernier sommet
exige qu’il touche l’intérieur des deux blocs.
Autrement tout nouveau cycle a au plus neuf sommets.
Les minorants d’arêtes forcent chaque bloc à être
proche du complet. Il manque au plus deux arêtes
dans le bloc d’ordre six, trois à l’ordre sept,
ou cinq à l’ordre huit. Le vérificateur énumère
toutes les suppressions à ces seuils et trouve des
chemins de longueurs trois et quatre entre toute
paire. On relie les deux attaches au sommet
d’articulation par des chemins de longueurs trois
et quatre, puis on ferme un $C_9$ avec le sommet
réinséré.

Il reste les graphes couverts par $K_4$ joint à
un stable aux ordres 13 et 14, et leurs variantes
avec un pont terminal ou un isolé. Dans un tel
graphe avec au plus quatre arêtes manquantes, deux
sommets reliés par un chemin de longueur au moins
huit le sont aussi par un chemin de longueur sept.
En effet, le chemin de longueur huit alterne les
quatre sommets centraux et des sommets du stable,
en commençant et finissant dans le stable. Une arête
entre deux sommets centraux successifs sur ce chemin
permet de retirer le sommet intermédiaire. Si les
trois arêtes de raccourci manquent, il manque au plus
une autre arête. On prend une arête centrale encore
présente comme passage entre les deuxième et troisième
sommets centraux, puis on ordonne les deux autres
pour joindre les extrémités. On choisit deux sommets
internes distincts du stable sans perte vers les
sommets centraux.

Dans les cas avec pont terminal, le grand bloc
manque d’au plus une arête d’après le nombre total
d’arêtes. Une paire de ce bloc reliée par un chemin
de longueur au moins sept l’est aussi par un chemin
de longueur six. Entre un sommet central et le stable,
un chemin de longueur sept alterne les deux parties et
l’un des trois raccourcis centraux est disponible.
Entre deux sommets du stable, on choisit un chemin
alterné avec trois sommets centraux et deux sommets
internes du stable reliés à tout le centre. Deux
sommets centraux ne peuvent avoir un chemin de
longueur sept. Pour une extrémité sur la feuille,
on ajoute l’arête du pont au chemin de longueur six.
Une extrémité isolée n’appartient à aucun chemin long.
Ainsi, dans toutes les formes courtes restantes,
le sommet réinséré ne peut créer un cycle d’au moins
neuf sommets sans créer un $C_9$.

Ces contrôles propagent les deux propriétés jusqu’à
$n=13$. Le graphe $H_{13}$ est alors non biparti,
sa circonférence est au moins neuf et il a au moins
38 arêtes. Le seuil de Brandt vaut
$\lfloor(13-1)^2/4\rfloor+1=37$, ce qui force un $C_9$.
L’ordre 31 est donc exclu pour toute taille de famille
de triangles. [Article de Brandt](https://www.sciencedirect.com/science/article/pii/S0166218X97000322).

## 2. Couplage complet des projections à l’ordre 32

On reprend les 186 classes résiduelles avec huit
triangles non exclues dans answer-26. Le graphe des
marques encode les sommets du reste ayant au moins
deux voisins dans un triangle. Deux sommets qui
marquent le même triangle peuvent y être reliés
par un chemin de longueur trois ou quatre avec deux
attaches. Ils ont aussi un label commun dans le
triangle, qui fournit une traversée de longueur deux.

- Une paire ne peut marquer le même triangle si les
  sommets sont reliés dans le reste par un chemin de
  longueur cinq, six ou sept.
- Des paires partageant une extrémité ne peuvent
  marquer deux triangles distincts si leurs extrémités
  libres sont reliées par un chemin de longueur un à
  trois dans le reste en évitant l’extrémité commune.
- Pour des paires disjointes, deux liaisons dans le
  reste entre leurs extrémités sont interdites quand
  ce sont deux arêtes disjointes, ou une arête et
  un chemin de longueur deux disjoint de l’arête.
  Les deux traversées des triangles peuvent alors
  compléter un cycle de longueur neuf.

Le vérificateur maximise le nombre de marques sur les
huit masques ordonnés des triangles, en interdisant
ces configurations et les cycles de longueur six du
graphe de marques. On injecte le plafond obtenu dans
le calcul par projections d’answer-26. Cela ferme
107 des 186 classes.

Pour chacune des 79 autres, on conserve les comptes
individuels de marques des trois sommets de chaque
projection. On énumère les vecteurs de huit comptes
encore compatibles avec le seuil dans une partition
qui réalise le meilleur majorant certifié. Tout
coloriage candidat fournit un tel vecteur. Pour un
vecteur, les mêmes comptes doivent convenir dans
toutes les partitions et pour un même déficit global.
Les plafonds d’étoiles se calculent aussi sur les
sous-ensembles qui ont les plus grands comptes. On
utilise enfin les 56 projections sur trois sommets
pour un contrôle supplémentaire. Chaque sommet y
apparaît 21 fois, donc leur somme de plafonds majore
21 fois le nombre réel d’attaches.

Le rejeu élimine les 79 classes sur 39 055 vecteurs
examinés. Les huit triangles à l’ordre 32 impliquent
donc au plus **174 arêtes**, en dessous de 175.

Il reste les ordres 32 et 33, avec au plus respectivement
sept et huit triangles disjoints. Parmi les couples déjà
étudiés avec au moins cinq triangles, sept restent ouverts.
La question générale de $C_9$ demeure ouverte.

## Rejeu

Avec Python 3 et un compilateur C++17, depuis le dossier
de ce document dans le ZIP extrait

~~~sh
python3 -B verify-coupled-marks.py | cmp - coupled-marks-and-order31-certificate.json
~~~
