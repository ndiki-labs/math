# Erdős #556 · Un stable de taille 14 force un C₉

Supposons qu’un 3-coloriage de `K₃₃` évite les `C₉` monochromatiques
et possède un stable rouge `S` de taille 14. Le [résultat précédent](C9-STABLES.md)
montre que tout ensemble de 15 sommets contient au moins une arête
de chaque couleur. Nous utilisons ci-dessous la formulation `α(G_c) ≤ 14`.

**Résultat.** Dans tout contre-exemple sur `K₃₃`, chaque graphe de
couleur a un nombre d’indépendance au plus **13**. Sur tout ensemble de
17 sommets, il y a donc au moins quatre arêtes de chaque couleur.
À exactement quatre arêtes dans une couleur, elles sont disjointes.

L’argument réduit d’abord `S` à deux cliques bleues `A,B`
de tailles 6 et 8. La coupe entre elles est verte, sauf une étoile
bleue éventuellement vide. Son centre est dans `A` avec au plus une
arête bleue, ou dans `B` avec au moins trois voisins verts dans `A`.
Tous les sommets extérieurs à trois voisins bleus ou plus ont exactement
le même triplet `T ⊂ A` de voisins bleus. Tout sommet extérieur qui a
exactement deux voisins bleus dans `A` a cette paire dans `T`. Parmi
les sommets au profil `T`, entre trois et cinq ont au moins deux
voisins verts dans `B`. Ces sommets forment une clique rouge et sont
reliés en rouge à tout le triplet `U = A\T`.

## Ce que force une clique bleue de taille six

Sur les six sommets, fixer un cycle bleu et appeler lacunes les paires
de sommets consécutifs. Trois sommets extérieurs peuvent être insérés
si chacun a deux voisins bleus formant l’une de trois lacunes
distinctes du même cycle. Cette insertion donne un `C₉` bleu.

Le vérificateur énumère les cycles sur six sommets et teste tous les
multiensembles de trois voisinages bleus de taille au moins deux. Il
vérifie deux conséquences pour les triplets qui échappent à l’insertion.

- Si chacun des trois voisinages a taille au moins trois, ils sont
  tous égaux à un même triplet.
- Avec deux voisins bleus exactement au premier sommet et le même
  triplet aux deux autres, la paire est incluse dans le triplet.

Ainsi, dès trois sommets à trois voisins bleus ou plus, la conclusion
sur `T` est forcée. Ce triplet fournit aussi une restriction sur
l’extérieur. Si deux sommets extérieurs `u,v` peuvent choisir deux
voisins bleus distincts dans `A`, un chemin bleu de longueur 5 entre ces
voisins peut passer par les six sommets de `A` et inclure une arête
interne à `T`. Insérer dans cette arête l’un des sommets au profil `T`,
distinct de `u,v`. Le chemin bleu de `u` à `v` a alors longueur 8,
donc `uv` ne peut être bleu. En particulier les sommets au profil
`T` sont deux à deux non adjacents en bleu.

## Exclusion après retrait d’au plus deux sommets

Soient `A,B` deux cliques bleues de tailles `(6,7)` ou `(6,8)`.
On demande à la coupe verte un chemin de longueur 7 pour deux
extrémités opposées, et de longueur 6 pour deux extrémités du même côté.
Ces propriétés valent pour les coupes utilisées plus bas. Pour une
coupe complète dont seules des arêtes incidentes à un sommet `q`
manquent, il suffit que `q` ait au moins deux voisins verts. Si `q`
est une extrémité du chemin, utiliser un voisin vert distinct de
l’autre extrémité quand elle est sur l’autre côté. Puis compléter le
chemin alterné en évitant `q` à l’intérieur. Si `q` est libre, on
peut l’éviter entièrement. Les deux côtés ont suffisamment de sommets.

Nous traitons deux situations.

- Si au plus deux sommets extérieurs ont au moins trois voisins
  bleus dans `A`, les écarter. Pour `|B| = 7`, écarter aussi
  l’éventuel sommet à plus de deux voisins bleus dans `B`.
  Le [résultat précédent](C9-STABLES.md) montre qu’il y en a au plus
  un et que deux voisinages de taille deux dans le `K₇` sont égaux.
- Si `|B| = 8` et qu’au moins trois sommets ont le profil `T`,
  écarter seulement ceux qui ont au moins deux voisins verts dans
  `B`. Nous supposons qu’ils sont au plus deux. Affecter tous les
  sommets restants au profil `T` à `B`.

Vers une clique de huit, chaque sommet a au plus un voisin bleu.
Dans les deux situations, il reste au moins 17 sommets extérieurs.
Nous en retenons exactement 17.

Chacun évite le vert vers au moins une clique, par les chemins verts
de longueur 7 entre côtés opposés. Affecter les sommets qui n’ont pas
déjà été affectés à une clique qu’ils voient sans vert. Appelons
`X` le groupe de taille au moins neuf, `Y` l’autre groupe, `C` la
clique associée à `X` et `D` celle associée à `Y`. Les sommets
associés à `A` n’ont aucun vert et au plus deux bleus dans `A`.
Lorsque `|B| = 8`, les sommets associés à `B` y manquent au plus
deux arêtes rouges. Pour les sommets au profil `T` affectés d’office
à `B`, il peut manquer une arête verte et une arête bleue.

### Chemins rouges dans un groupe

Dans un groupe associé à une clique de sept ou huit, deux sommets
partagent au moins quatre voisins rouges. Dans le groupe associé à
la clique de six, les voisins rouges sont les complémentaires des
profils bleus de taille au plus deux. Le vérificateur énumère les
multiensembles sur quatre et cinq sommets, puis toutes les paires
d’extrémités. Il conserve les profils qui échappent à l’insertion
de trois sommets en bleu. En réordonnant les sommets intermédiaires,
les lacunes du chemin rouge admettent des représentants distincts.
On obtient un chemin de longueur 6 ou 8, respectivement, sur les
sommets extérieurs choisis et des sommets de la clique associée.

Une variante vérifie un chemin de longueur 8 entre un sommet
supplémentaire `w`, avec au moins trois voisins rouges quelconques
sur la clique de six, et un sommet fixé parmi quatre sommets du groupe.
Il suffit de vérifier les triplets rouges de `w`, puisque l’ajout
d’arêtes est monotone. Le vérificateur réordonne les trois sommets
intermédiaires et teste de nouveau les représentants distincts.
Pour un sommet au profil `T` avec seulement deux voisins rouges
dans `U`, il vérifie la même propriété. Il suffit de fixer `T` à
permutation près et de vérifier les trois paires rouges possibles
dans `U`. Les profils bleus de taille deux des quatre autres sommets
sont alors tous inclus dans `T`.

Par conséquent, `X` est un stable rouge, et `Y` aussi si
`|Y| ≥ 5`. Une arête rouge interne fermerait un chemin de longueur 8.

### Arêtes entre les groupes

Soit `W ⊂ X` l’ensemble des sommets qui ont au plus un voisin vert
dans `D`. Tout `w ∈ W` partage au moins un voisin rouge de `D`
avec tout `y ∈ Y`. Si `D` a taille six et `w` a au plus deux
voisins bleus, alors `w` y a au moins trois voisins rouges,
et `y` en manque au plus deux. Si `w` a le profil `T`, il voit
au moins deux sommets de `U` en rouge, et `y` en manque au
plus un, car ses paires bleues éventuelles sont dans `T`. Pour
une taille sept ou huit, l’intersection a au moins deux sommets.

Pour `x ∈ X` distinct de `w`, un chemin rouge de longueur 6 dans
la coupe entre `X` et `C` relie `x` à `w`. En ajoutant deux
arêtes rouges de `w` à `y` via `D`, on obtient un chemin rouge
de longueur 8. Une arête rouge `xy` le fermerait.

Deux sommets de `X\W` ne peuvent être reliés en vert. Chacun a au
moins deux voisins verts dans `D`, ce qui donne deux voisins
distincts. Un chemin vert de longueur 6 entre ces voisins complète
un `C₉`. Donc `X\W` est une clique bleue, de taille au plus huit.

Si `W` est vide, c’est impossible. Si `W = {w}`, alors
`|X| = 9` et `|Y| = 8`. Il reste seulement à exclure les arêtes
rouges de `w` vers `Y`. Pour `|D| = 6`, utiliser le chemin rouge
avec un sommet supplémentaire vérifié ci-dessus. Pour `|D| ≥ 7`,
la première paire partage au moins deux voisins rouges et les
trois suivantes en partagent au moins quatre chacune. Quatre
représentants distincts existent et ferment toute éventuelle
arête rouge. Les 17 sommets formeraient un stable rouge.

Si `|W| ≥ 2`, il n’y a aucune arête rouge entre `X` et `Y`,
car pour chaque paire on peut choisir un `w` distinct de
l’extrémité de `X`. Pour `|Y| ≥ 5`, cela donne un stable rouge
de taille 17. Pour `|Y| ≤ 3`, on obtient un stable rouge de taille
au moins 15 en ajoutant un sommet de `Y` à `X` si nécessaire.
Pour `|Y| = 4`, une paire sans rouge dans `Y` se joint aux 13
sommets de `X` et donne un stable de taille 15. Il reste
`|X| = 13` et un `K₄` rouge sur `Y).

### Dernier cas, quatre sommets extérieurs en rouge

Pour deux sommets distincts `w₁,w₂ ∈ W` et deux sommets distincts
`y₁,y₂ ∈ Y`, supposons qu’on puisse prendre des représentants
rouges distincts `d₁,d₂ ∈ D` entre les paires `(w₁,y₁)` et
`(w₂,y₂)`. Un troisième sommet `x₀ ∈ X` et des représentants
rouges distincts `c₁,c₂ ∈ C` forment le chemin
`y₁,d₁,w₁,c₁,x₀,c₂,w₂,d₂,y₂`. Les deux choix en `C` ont
au moins deux options chacun. L’arête rouge `y₁y₂` ferme un `C₉`.

Comme `Y` est un `K₄` rouge, chaque intersection rouge dans `D`
pour `(w,y)` est donc le même singleton `{d}`. En effet, chaque
intersection est non vide, et la comparaison avec un autre `w`
et un autre `y` force l’égalité des singletons. Pour comparer
deux entrées d’une même ligne, passer par une autre ligne et
une troisième colonne. Les comparaisons entre lignes imposent
alors la même valeur partout.
Cela impose `|D| = 6`. Il y a deux possibilités.

- Si aucun `w` n’a le profil `T`, chacun a exactement trois
  voisins rouges dans `D`. Tous les `y` y ont la même paire
  bleue `Q`, égale aux deux autres voisins rouges de `w`. Chaque
  `w` a deux voisins bleus dans `D\Q` et exactement un voisin
  vert dans `D`. Une arête bleue `wy` fermerait le chemin suivant.
  Commencer par `w` et un voisin bleu `p ∉ Q` dans `D`, traverser
  les six sommets de `D` en finissant par la paire `Q`, et
  prolonger jusqu’à `y`. Insérer un autre sommet de `Y` entre
  les extrémités de `Q`. Le chemin a longueur 8.
- Si un `w` a le profil `T`, il a exactement deux voisins rouges
  dans `U`. Pour que l’intersection soit un singleton, chaque `y`
  a un unique voisin bleu dans `U). Un autre sommet `w'` avec
  trois voisins rouges dans `D` partagerait au moins deux voisins
  rouges avec `y`. Donc tous les sommets de `W` ont le profil `T`
  et exactement un voisin vert dans `D`. Chaque paire `(w,y)`
  peut choisir des voisins bleus distincts, l’un dans `T` et
  l’autre dans `U`. La restriction extérieure prouvée avec le
  triplet interdit une arête bleue `wy`.

Ainsi toutes les arêtes entre `W` et `Y` sont vertes.
Comme `|X\W| ≤ 8`, on a `|W| ≥ 5`. Toute arête verte dans
`W` fermerait un chemin vert de longueur 8 par quatre sommets
de `Y` et trois autres sommets de `W`. Les arêtes entre
`W` et `X\W` ne peuvent être vertes non plus, via les chemins
verts de longueur 6 dans la coupe des cliques `C,D`. On obtient
donc une clique bleue sur `X`, la contradiction recherchée.

## Réduction des deux coupes de départ

Le théorème 2 de Nikiforov–Schelp sur le stable rouge `S` donne
deux cliques bleues réunies par une coupe verte, de tailles
`(5,8)` ou `(6,7)`, après retrait d’un sommet `q`.
Les chemins verts de longueur 7 entre côtés opposés obligent
`q` à voir un côté entièrement en bleu.

- Pour `(5,8)`, `q` se joint à la clique de cinq. Vers le
  `K₈` bleu, il a au plus un voisin bleu. On obtient le premier
  type de coupe `(6,8)`.
- Pour `(6,7)`, si `q` voit au moins quatre sommets de la clique
  de six en bleu, la règle des trois voisinages borne à deux le
  nombre de sommets à au moins trois voisins bleus dans cette
  clique, `q` compris. L’argument avec le noyau `(6,7)` s’applique.
  Sinon `q` se joint à la clique de sept et possède au moins
  trois voisins verts vers la clique de six. Cela donne le second
  type de coupe `(6,8)`.

Dans les deux types de coupe `(6,8)`, il reste au moins trois
sommets au profil `T` ayant au moins deux voisins verts dans `B`.
Appelons `H` cet ensemble. Chacun de ses sommets ne voit aucun
vert dans `A`, donc voit tout `U) en rouge. Les arêtes entre
sommets de `H` sont rouges. Le profil commun écarte le bleu.
Les deux voisins verts ou plus dans `B` à chaque extrémité
permettent d’écarter le vert par un chemin vert de longueur 6
dans la coupe et deux voisins distincts dans `B`. Enfin, six
sommets de cette clique rouge et les trois sommets de `U`
donneraient un `C₉` rouge, en insérant les trois sommets de
`U` dans un cycle sur les six autres. On a donc `3 ≤ |H| ≤ 5`.

Il y a au plus trois autres sommets extérieurs ayant au moins
deux voisins rouges dans `U` et au moins un voisin rouge dans
`T`. Leurs ensembles de voisins rouges dans `T` sont deux à
deux disjoints. Sinon, pour deux de ces sommets `x,y`, choisir
trois sommets distincts `h₁,h₂,h₃ ∈ H`. Sur la suite
`h₁,x,y,h₃,h₂`, relever la paire `(x,y)` avec le voisin rouge
commun dans `T`, et les trois autres paires avec des représentants
distincts dans `U`. Leurs choix ont taille au moins deux,
au moins deux et exactement trois. L’arête rouge `h₁h₂` ferme
ce chemin en `C₉`.

## Exclusion de la branche du triplet commun

Appelons `J` les sommets extérieurs au profil `T` qui ont exactement
un voisin vert dans `B`. Ils voient tout `U` en rouge, comme les
sommets de `H). Toutes les arêtes entre `H` et `J` sont rouges.
Le profil commun interdit le bleu. Une arête verte se fermerait par
un chemin vert de longueur 6 entre deux voisins distincts dans `B),
car le sommet de `H` y a au moins deux voisins verts et celui de
`J` en a un.

Si `|H|+|J| ≥ 6`, choisissons six sommets de leur union en gardant
tout `H`. Avec `U` ils donnent un `C₉` rouge, même sans arêtes
rouges internes à `J` ou à `U`. Voici les ordres cycliques pour
trois, quatre ou cinq sommets de `H`, où `hᵢ,uᵢ,jᵢ` désignent des
sommets de `H,U,J` respectivement.

- `h₁,u₁,j₁,h₂,u₂,j₂,h₃,u₃,j₃`.
- `h₁,u₁,j₁,u₂,h₂,h₃,u₃,j₂,h₄`.
- `h₁,u₁,j₁,u₂,h₂,h₃,u₃,h₄,h₅`.

Ainsi `|H|+|J| ≤ 5`. Tout autre sommet extérieur qui voit du vert
dans `B` évite le vert dans `A` et a au plus deux voisins bleus dans
`A`. S’il a deux voisins bleus, ils appartiennent à `T`. Il voit
donc au moins deux sommets de `U` et au moins un sommet de `T` en
rouge. Nous avons montré qu’il existe au plus trois tels sommets.
Parmi les 19 sommets extérieurs à `S`, il reste donc un ensemble
`Z` de taille **au moins 11** sans aucune arête verte vers `B`.
Chaque sommet de `Z` voit au moins sept sommets de `B` en rouge,
puisqu’un sommet extérieur a au plus un voisin bleu dans le `K₈`.
Toute arête rouge dans `Z` fermerait un chemin alterné rouge de
longueur 8. Les paires de sommets de `Z` ont au moins six voisins
rouges communs dans `B`, d’où quatre représentants distincts.
Ainsi `Z` est un stable rouge.

Posons `F = H ∪ U`. Entre deux sommets distincts de `F`, il existe
un chemin rouge de longueur trois. Si les deux sommets sont dans
`U`, passer par deux sommets de `H`. Si l’un est dans `H`, et
l’autre dans `U`, passer par les deux autres sommets de `H`. Si
les deux sont dans `H`, passer par un sommet de `U` et un troisième
sommet de `H`.

Pour deux sommets distincts de `Z`, on ne peut choisir deux voisins
rouges distincts dans `F`. Le chemin précédent et les deux arêtes
d’attache donnent un chemin rouge de longueur cinq entre les deux
sommets de `Z`. On le ferme par un chemin rouge de longueur quatre
via un troisième sommet de `Z` et deux représentants distincts dans
`B`. Cela ferait un `C₉`. En particulier, il y a au plus un sommet
de `Z` ayant deux voisins rouges ou plus dans `F`. Écartons-le s’il
existe, et appelons `Z₀` l’ensemble restant.

Il y a également au plus un sommet de `H` ayant trois voisins
rouges ou plus dans `B`. Sinon, en prenant trois sommets distincts
de `Z`, on obtient un chemin alterné rouge de longueur 8 entre deux
tels sommets de `H`. Les première et dernière paires partagent au
moins deux voisins rouges dans `B`, et les deux autres en partagent
au moins six. Choisir d’abord les représentants des deux paires
extrêmes, puis ceux des deux autres. L’arête de `H` ferme le
`C₉`. En écartant cet éventuel sommet de `H`, on obtient un
ensemble `H₀` de taille au moins deux. Chacun de ses sommets
voit au moins cinq sommets de `B` en vert, puisqu’il voit `B`
au plus deux fois en rouge et une fois en bleu.

Chaque sommet de `A` a au moins sept voisins verts dans `B`,
dans l’un comme dans l’autre type de coupe `(6,8)`. Toute paire
d’extrémités distinctes dans `A ∪ H₀` est donc reliée par un
chemin vert de longueur 6. Prendre deux nouveaux sommets
intermédiaires de `A`, puis trois représentants distincts de
voisinages verts communs dans `B). Chaque paire consécutive
inclut un sommet de `A`, donnant au moins quatre choix.

Enfin, chaque sommet `z ∈ Z₀` voit au moins deux sommets de
`A ∪ H₀` en vert. Si `z` ne voit aucun sommet bleu dans `A`,
il en voit au moins deux en vert dans `U`, puisqu’il n’a au plus
qu’un voisin rouge dans `F`. Si `z` a un voisin bleu dans
`A`, les arêtes de `z` vers `H₀` sont rouges ou vertes par
la restriction du triplet commun. Si elles sont toutes vertes,
`|H₀| ≥ 2` suffit. Sinon l’unique voisin rouge de `z` dans `F`
est dans `H₀`. Il ne reste aucun voisin rouge dans `U` et
au plus un voisin bleu dans `U`, car tout profil bleu de taille
au moins deux est inclus dans `T`. Ainsi `z` a deux voisins
verts dans `U` dans ce dernier cas aussi.

Une arête verte dans `Z₀` fermerait un chemin vert de longueur 8
en passant par deux voisins verts distincts dans `A ∪ H₀` et
le chemin vert de longueur 6 entre eux. Comme `Z₀ ⊂ Z` est un
stable rouge, il forme une clique bleue de taille au moins dix.
Cette dernière contradiction exclut le stable rouge `S` de
taille 14. L’argument s’applique par permutation aux trois couleurs.

Dans un ensemble de 17 sommets, si une couleur a au plus trois
arêtes, les supprimer en écartant au plus trois sommets laisse un
stable d’au moins 14. Pour quatre arêtes dont deux se touchent,
on couvre encore les arêtes avec au plus trois sommets, d’où la
même contradiction.

La question générale `R₃(C₉) ≤ 33` reste ouverte.

- Nikiforov et Schelp, *Cycles and stability*, théorème 2.
  [Texte](https://arxiv.org/pdf/math/0602627#page=2)
