# Erdős #556 · Réduction des stables de taille 13

On suppose donné un 3-coloriage de `K₃₃` sans `C₉` monochromatique
avec un stable rouge `S) de taille 13. La [preuve précédente](C9-STABLE14.md)
montre que tout ensemble de 14 sommets contient au moins une arête
de chaque couleur.

**Résultat.** Après choix du nom des deux autres couleurs, il reste
deux formes possibles sur `S`.

1. Deux cliques bleues de tailles `(5,8)` avec une coupe verte
   sauf une éventuelle étoile bleue centrée dans le côté de huit.
2. Deux cliques bleues de tailles `(6,7)` avec une étoile bleue
   de six arêtes centrée dans la clique de taille six. Le centre
   a exactement un voisin vert dans la clique de sept.

Dans le premier cas, un sommet extérieur bleu-complet à la clique
de cinq est également contraint. Si la coupe a au plus une arête
bleue, ce sommet extérieur a au plus un voisin vert dans la clique
de huit. Sinon il a au plus un voisin vert dans la clique de huit
privée du centre de l’étoile.

## Du C₁₀ aux deux cliques

Le théorème de Wang–Chen donne
`R({C₉,C₁₀},{C₉,C₁₀}) = 13`, par la formule de Hansson. Le stable
bicolore contient donc un `C₁₀`, que l’on prend vert. D’après le
lemme 14 de Nikiforov–Schelp, sur ces dix sommets on trouve deux
cliques bleues de cinq. La coupe est verte sauf une possible étoile
bleue. Son centre a au moins deux voisins verts, puisque le
`C₁₀` vert est couvrant sur ces dix sommets.

Dans une telle coupe, deux sommets de côtés opposés sont reliés
par un chemin vert de longueur 7, et deux sommets distincts d’un
même côté par un chemin vert de longueur 6. Pour choisir le chemin,
éviter le centre de l’étoile quand il est libre. Si le centre est
une extrémité, choisir son premier voisin sur le chemin distinct de
l’autre extrémité. Le reste de la coupe est complet. Les propriétés
sont vérifiées sur une coupe `(5,5)` avec seulement deux voisins
verts au centre.

Chacun des trois autres sommets de `S` voit donc au moins un côté
entièrement en bleu. Un sommet bleu universel sur le noyau voit
les deux côtés entièrement en bleu. Deux tels sommets donneraient
un `C₉` bleu via un chemin à quatre sommets d’une clique et un
chemin à trois sommets de l’autre.

Deux sommets non universels rattachés à la même clique ont leurs
arêtes vers cette clique bleues. Vers l’autre clique, chacun a un
voisin vert. Si leur arête mutuelle était verte, ils devraient avoir
le même voisin vert unique dans la clique opposée, par le chemin
vert de longueur 6. Mais ils auraient alors quatre voisins bleus
chacun de l’autre côté. Deux voisins distincts permettent de
construire un `C₉` bleu via ces deux sommets, un chemin à quatre
sommets dans leur clique et un chemin à trois sommets dans la
clique opposée. Leur arête mutuelle est donc bleue.

S’il y a un sommet universel sur le noyau, rattacher d’abord
les deux sommets non universels. Toute arête bleue entre les
cliques élargies donnerait un `C₉` bleu. Partir de chacune de
ses extrémités par un chemin de longueur 3 dans sa clique, jusqu’à
un sommet du noyau, puis relier ces deux bouts au sommet universel.
La coupe des cliques élargies est donc verte. Le sommet universel
ne peut avoir des voisins verts de part et d’autre dans cette
coupe. On le rattache à une clique qu’il voit entièrement en bleu.

On obtient ainsi deux cliques bleues de tailles `(5,8)` ou
`(6,7)`. Deux arêtes bleues disjointes entre les cliques
donneraient un `C₉` bleu par un chemin de longueur 3 dans une
clique et un de longueur 4 dans l’autre. Les arêtes bleues de la
coupe sont donc deux à deux incidentes. Dans une coupe bipartie,
une telle famille est une étoile, éventuellement vide.
Dans une coupe `(5,8)`, un centre du côté de cinq a au plus un
voisin bleu dans la clique de huit. Deux voisins fermeraient
un chemin bleu de longueur 7 dans cette clique. Si l’étoile
se réduit à une arête, on peut prendre son centre du côté de huit.

## Une coupe de six par sept qui force un C₉

Soient `A,B` deux cliques bleues de tailles 6 et 7, où la coupe
verte vérifie l’une des conditions suivantes.

- Elle est complète sauf une étoile, et le centre de l’éventuelle
  étoile garde au moins deux voisins verts de l’autre côté.
- Au moins quatre sommets de `A` voient tout `B` en vert, et
  les autres ont au moins deux voisins verts dans `B`.

Dans les deux conditions, il y a des chemins verts de longueur 7
entre côtés opposés et de longueur 6 entre sommets distincts d’un
même côté. Pour la seconde condition, la construction utilise les
quatre sommets verts-complets pour les sommets intermédiaires de
`A`. Un départ dans un sommet exceptionnel utilise d’abord
l’un de ses deux voisins verts différent de l’extrémité d’arrivée.

Nous utiliserons aussi un chemin vert de longueur 6 entre deux
sommets distincts de `A ∪ H` si chaque sommet de `H`, extérieur
aux cliques, a au moins deux voisins verts dans `B`. Prendre deux
sommets intermédiaires distincts dans `A`. Si les défauts de la
coupe sont répartis sur au plus deux sommets de `A`, on choisit
ces deux intermédiaires parmi les verts-complets, hors extrémités.
Si le centre de l’étoile est dans `B`, il y a au moins deux
sommets de `A` verts-complets. Lorsqu’une extrémité est dans `H`,
choisir l’intermédiaire qui lui est adjacent parmi eux. Si les
deux extrémités sont dans `H`, deux intermédiaires verts-complets
distincts conviennent. Les deux paires extrêmes ont au moins
deux voisins verts communs dans `B`, et la paire centrale en
a au moins six. Des représentants distincts donnent le chemin.
Le vérificateur couvre les deux types de coupe, y compris les
voisinages extérieurs verts de taille minimale deux.

### Profils retenus et chemins rouges

Sur la clique de six, le [certificat précédent](C9-STABLE14.md)
vérifie que si au moins trois sommets extérieurs y ont au moins
trois voisins bleus, ils voient tous exactement le même triplet
`T ⊂ A` en bleu. Il vérifie aussi que tout profil bleu de taille
deux appartient alors à `T`. Écrivons `U = A\T`.

Dans la clique de sept, d’après le [résultat sur les attaches
bleues](C9-STABLES.md), on peut écarter au plus un sommet pour
que tous les profils bleus aient taille au plus deux et que
ceux de taille deux coïncident sur une paire fixe `P ⊂ B`.

S’il y a au plus deux sommets à au moins trois voisins bleus
dans `A`, écartons-les et écartons aussi l’exception éventuelle
pour `B`. Sinon, le triplet `T` existe. Soit `H` l’ensemble des
sommets au profil `T` qui ont au moins deux voisins verts dans
`B`. Si `|H| ≤ 2`, écartons `H` et l’exception éventuelle pour
`B`, et affectons les autres sommets au profil `T` à `B`. Ils y
ont au plus un voisin vert. Dans les deux situations il reste
au moins 17 des 20 sommets extérieurs, dont nous retenons 17.

Chaque sommet qui n’est pas déjà affecté évite le vert vers au
moins une clique, par la propriété des chemins verts de longueur 7.
Affectons-le à un tel côté. Appelons `X` le groupe d’au moins
neuf sommets, `Y` l’autre, et `C,D` leurs cliques respectives.
Les sommets affectés à `A` y ont au plus deux voisins bleus
et aucun voisin vert. Pour ceux de `B`, l’ensemble des sommets
de `B` qui ne sont pas rouges vers le sommet extérieur a taille
au plus deux, ou est une paire `P` plus un sommet.

Pour les profils de `A`, le certificat sur le stable de taille 14
donne un chemin alterné rouge de longueur 6 ou 8 pour quatre
ou cinq sommets du groupe, en fixant les deux extrémités et en
réordonnant les autres. Sur `B`, les profils maximaux d’arêtes
manquantes sont les dix paires disjointes de `P` et les cinq
triples contenant `P`. Tout autre profil s’agrandit en un
profil maximal. Le nouveau vérificateur énumère leurs
multiensembles à quatre et cinq profils et toutes les paires
d’extrémités. Les représentants distincts existent après
réordonnancement. Agrandir un profil enlève des choix rouges,
donc le contrôle couvre aussi les profils plus petits.

Par conséquent `X` est un stable rouge, comme `Y` s’il a au
moins cinq sommets. Une arête rouge interne fermerait le
chemin alterné rouge de longueur 8.

### Arêtes entre les deux groupes

Soit `W` l’ensemble des sommets de `X` qui ont au plus un
voisin vert dans `D`. Pour tout `w ∈ W` et `y ∈ Y`, les deux
partagent au moins un voisin rouge dans `D`. Pour `D=B`, chacun
a au moins quatre voisins rouges dans les sept sommets. Pour
`D=A`, un `w` à au plus deux voisins bleus a au moins trois voisins rouges
face à un `y` qui en manque au plus deux. Un `w` au profil `T`
a au moins deux voisins rouges dans `U`. Un `y) affecté à `A`
manque au plus un voisin rouge dans `U`, puisqu’un profil bleu
de taille deux se trouve dans `T`.

Pour tout `x ∈ X\{w}`, un chemin rouge de longueur 6 relie
`x` et `w` en passant par `C` et deux autres sommets de `X`.
Avec deux arêtes rouges de `w` à `y` via `D`, il interdit
une arête rouge `xy`. D’autre part, `X\W` est une clique
bleue. Il est sans rouge et deux de ses sommets ont chacun au
moins deux voisins verts dans `D`. Un choix distinct à chaque
bout et un chemin vert de longueur 6 dans la coupe excluent
une arête verte.

Si `W` est vide, `X\W` a au moins neuf sommets. Si `W = {w}`,
il reste seulement la possibilité `|X|=9` et `|Y|=8`. Pour
exclure une arête rouge `wy`, prendre trois autres sommets
de `Y` et construire le chemin rouge de longueur 8 entre
`w` et `y`. Dans `D=B`, le profil de `w` est lui aussi de
la forme testée pour les sept sommets. Dans `D=A`, utiliser
le contrôle du certificat précédent avec une extrémité
supplémentaire à trois voisins rouges, ou à deux voisins
rouges dans `U` si elle a le profil `T`. Les 17 sommets
formeraient alors un stable rouge.

S’il y a au moins deux sommets de `W`, pour toute paire
`x ∈ X,y ∈ Y` on peut choisir un `w ≠ x`. Aucune arête
entre `X` et `Y` n’est donc rouge. Si `|Y| ≥ 5`, cela
donne un stable rouge de taille 17. Si `|Y| ≤ 4`, le stable
`X` a taille au moins 13 et peut être complété par un
sommet de `Y` si nécessaire. Cela contredit la borne 13.

### Le triplet commun avec au moins trois grands voisinages verts

Il reste le cas `|H| ≥ 3`. Les sommets de `H` ne voient
aucun vert dans `A`, donc voient tout `U` en rouge.
Leur arête mutuelle ne peut être bleue. Plus généralement,
chaque paire extérieure qui peut choisir deux voisins bleus
distincts dans `A` est privée de bleu. Dans le chemin bleu
couvrant les six sommets de `A` entre ces voisins, on peut
insérer un troisième sommet au profil `T` entre deux membres
consécutifs de `T`. Le chemin obtenu, avec les deux attaches
des extrémités, a longueur 8. C’est la restriction du triplet
du certificat précédent.

Les arêtes de `H` ne peuvent être vertes non plus, par le
chemin vert de longueur 6 entre voisins distincts dans `B` :
chacun des deux sommets de `H` possède au moins deux tels
voisins. Ainsi `H` est une clique rouge. Six sommets de
`H` avec `U` donneraient un `C₉` rouge. Appelons `J`
les sommets au profil `T` avec exactement un voisin vert dans
`B`. Ils sont aussi rouges vers `U` et tout `H`, par
la même exclusion du bleu et du vert. On en déduit
`|H|+|J| ≤ 5` par les trois cycles sur six sommets de
`H ∪ J` et les trois sommets de `U` donnés au certificat
précédent.

Tout autre sommet extérieur qui voit du vert dans `B` a au
moins deux voisins rouges dans `U` et au moins un dans `T`.
Les ensembles de voisins rouges dans `T` de tels sommets
sont deux à deux disjoints. En effet, une paire `x,y` avec
un voisin rouge commun dans `T` donnerait un chemin rouge
de longueur 8 sur la suite `h₁,x,y,h₃,h₂`. Utiliser ce
voisin de `T` pour la paire `x,y`, et trois représentants
distincts dans `U` pour les autres paires. L’arête rouge
`h₁h₂` le ferme. Il y a donc au plus trois tels sommets.

Parmi les 20 sommets extérieurs, au moins 12 voient `B` sans
vert. Après retrait de l’exception éventuelle de la clique
de sept, il en reste au moins 11, formant `Z`. Deux sommets
de `Z` ont au moins quatre voisins rouges communs dans
`B`. Ainsi `Z` est un stable rouge par les chemins alternés.

Dans `F=H ∪ U`, deux sommets distincts sont reliés par un
chemin rouge de longueur 3, comme dans le certificat
précédent. Deux sommets distincts de `Z` ne peuvent donc
choisir deux voisins rouges distincts dans `F`. Cela donnerait
un chemin de longueur 5, que l’on fermerait en `C₉` par un
chemin rouge de longueur 4 via un autre sommet de `Z` et deux
représentants de `B`. On écarte au plus un sommet de `Z`, pour
que tous les autres aient au plus un voisin rouge dans `F`.

Chacun des sommets restants a deux voisins verts dans
`A ∪ H`. S’il voit un sommet bleu dans `A`, il ne voit pas
`H` en bleu par la restriction du triplet, et au plus un
sommet de `H` en rouge. Puisque `|H| ≥ 3`, deux voisins verts
restent. S’il ne voit aucun bleu dans `A`, il y a au moins
deux voisins verts dans `U`, où il a au plus un voisin rouge.
Les chemins verts de longueur 6 sur la coupe augmentée
excluent toute arête verte entre les sommets restants. Ils
forment alors une clique bleue d’au moins dix sommets. Cela
termine l’exclusion de la coupe de six par sept sous les
deux conditions annoncées.

## Le centre de l’étoile avec zéro ou un voisin vert

Supposons que le centre soit du côté de sept dans une
partition de `S` de tailles `(6,7)`. Le retirer laisse
deux cliques bleues de taille six avec une coupe entièrement
verte. Le centre avait au moins quatre voisins bleus dans
chacune. Le contrôle de la clique de six implique qu’il
y a, pour chaque clique, au plus deux sommets extérieurs
avec trois voisins bleus ou plus. Les deux listes partagent
le centre, donc on écarte au plus trois des 21 sommets
extérieurs et on en garde 17. La preuve des deux groupes
ci-dessus s’applique à deux cliques de six. Les chemins
rouges, y compris ceux qui partent d’une extrémité à trois
voisins rouges, sont ceux du certificat précédent pour la
clique de six. Le cas d’un centre du côté de sept est exclu.

Si le centre est du côté de six et n’a aucun voisin vert
de l’autre côté, le déplacer vers la clique de sept produit
une partition de tailles `(5,8)`, avec étoile bleue centrée
au sommet déplacé. Il reste donc seulement les deux formes
de départ énoncées au début.

## Contrainte d’extension pour la clique de cinq

Dans la partition de tailles `(5,8)`, notons `A₅,B₈` les
cliques bleues. Si un sommet extérieur `x` est bleu-complet
à `A₅`, il forme avec elle une clique bleue de taille six.

Si la coupe a au plus une arête bleue, alors `x` ne peut
avoir au moins deux voisins verts dans `B₈`. En effet, on
pourrait enlever de `B₈` un sommet qui laisse au moins
deux voisins verts à `x`. Il suffit d’éviter ses deux voisins
s’il en a exactement deux. L’éventuel défaut initial est
incident à un seul sommet du côté de cinq, et ce sommet
garde au moins six voisins verts.
Il reste une coupe de six par sept où au moins quatre
sommets du côté de six sont verts-complets et les deux
autres voient au moins deux sommets verts.

Si l’étoile a au moins deux arêtes, son centre est du côté de
huit. Le retirer de `B₈`
laisse une coupe entièrement verte sur le noyau de départ.
Deux voisins verts de `x` sur les sept restants donneraient
une coupe de six par sept avec un seul sommet exceptionnel
et au moins deux voisins verts au centre. Elle est exclue
par le même argument.

Dans la seconde forme, supprimer le centre du côté de six
laisse aussi une coupe complète entre cliques de tailles
cinq et sept. Tout autre sommet bleu-complet à la clique
de cinq a donc au plus un voisin vert dans la clique de sept.

Le stable de taille 13 reste ouvert dans les formes indiquées,
comme la borne générale `R₃(C₉) ≤ 33`.
Le vérificateur fournit aussi un contrôle local pour les sept modèles
bicolores, six pour le découpage `(5,8)` selon le nombre d’arêtes
de l’étoile et un pour le découpage `(6,7)`. Chacun évite un
`C₉` sur ses 13 sommets.

- Wang et Chen, *The Ramsey numbers of two sets of cycles*.
  [Texte](https://doi.org/10.1002/jgt.22564)
- Hansson, *Generalised Ramsey numbers for two sets of cycles*.
  [Formule](https://arxiv.org/pdf/1605.04301#page=3)
- Nikiforov et Schelp, *Cycles and stability*, lemme 14.
  [Texte](https://arxiv.org/pdf/math/0602627#page=14)
