# Retrait de sommets à l’ordre 31 et attaches aux noyaux bipartis

On considère le bloc candidat $B$ sans $C_9$ de la
[réduction monochrome](../mono-extremal/C9-MONO-EXTREMAL.md).
Il a ordre $b\in\{31,32,33\}$, $\alpha(B)\le13$ et
$e(B)\ge m_b=176-\operatorname{ex}(34-b,C_9)$.
Par answer-14 à answer-16, il ne contient aucun noyau
biparti induit d’ordre au moins $b-12$.
Un noyau a des parties d’au moins quatre sommets et
des chemins simples de longueurs $2,4,6$ entre paires
distinctes du même côté et $3,5,7$ entre côtés opposés.
[Certificat sur les noyaux](../twelve-exterior-c9/C9-TWELVE-EXTERIOR.md).

## 1. Retraits à l’ordre 31

On retire successivement un sommet de degré minimal
pour obtenir les graphes induits $H_n$ à $n$ sommets.
À chaque étape étudiée, le minorant d’arêtes dépasse
$4(n-1)$. Erdős–Gallai donne une circonférence d’au
moins neuf. Sur un graphe non biparti,
Brandt–Faudree–Goddard impose alors
$\delta(H_n)\le\lfloor(n+1)/3\rfloor$, puisque le graphe
est sans $C_9$. Pour $n>26$, la bipartition est impossible
par $\alpha\le13$. [Erdős–Gallai](https://web.vu.lt/mif/s.jukna/tropical/Erdos-Gallai-1959.pdf)
et [Brandt–Faudree–Goddard, théorème 1.7](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf#page=5).

### Plafond biparti avec degré minimal prescrit

On renforce le plafond d’[answer-24](../degree-peeling-and-nine-c9/C9-ORDER-30-AND-NINE-TRIANGLES.md)
en tenant compte du degré minimal $d$ d’un graphe biparti
de parties $4\le a\le c$ et d’ordre au moins $b-12$.
L’absence de noyau donne une paire de voisins communs
de codegré au plus deux, donc $d\le\lfloor(c+2)/2\rfloor$.
Si $d\ge2$, il manque au moins $a$ arêtes par le lemme des
quatre sommets universels d’answer-24. Sinon il en manque
au moins $a-1$.

Si $a\ge8$ et $2d>a$, on peut demander au moins $a+1$
arêtes manquantes. En effet, avec au plus $a$ pertes,
une paire de codegré au plus deux dans une partie
concentre à elle seule au moins la taille de la partie
opposée moins deux. Il reste au plus deux pertes sur les
autres sommets de son côté, donc au moins quatre sommets
universels de ce côté. Une paire ne peut pas avoir de
voisinages disjoints. Il faudrait qu’il manque au moins
la taille de la partie opposée, égale à $a$ dans ce cas,
et les deux degrés s’additionneraient en au plus $a$.
La seconde condition de noyau d’answer-24 s’applique.

On combine ces plafonds avec le retrait d’un sommet
de degré minimal exact $d$. Le graphe obtenu a un
sommet de moins dans l’une des parties et un degré
minimal au moins $d-1$. La récurrence maximise sur les
degrés autorisés et les deux sens du retrait. Les
cas de base reprennent le produit des tailles, ou
l’impossibilité lorsque la plus petite taille est
sous le degré minimal requis.

### Chemins entre côtés opposés

Voici le test arithmétique utilisé pour obtenir des chemins
de longueur sept dans un graphe biparti de parties $A,C$
de tailles $a,c$, de degré minimal au moins $s\ge4$ et
d’au moins $E$ arêtes. Fixer $x\in A,y\in C$. Soit
$d$ le plus grand degré dans $A\setminus\{x\}$ et
prendre $u$ de degré $d$ dans cet ensemble.

On cherche d’abord un chemin $x,b_1,v,b_2,u$ de longueur
quatre évitant $y$. Prendre $b_1\in N(x)\setminus\{y\}$.
Un intermédiaire $v\in N(b_1)\setminus\{x,u\}$ de degré
au moins $t=c-d+3$ possède un voisin commun avec $u$
hors $\{b_1,y\}$. Pour compléter ensuite le chemin, on peut
choisir $v$ différent de tout sommet prescrit
$w\in N(y)\setminus\{x,u\}$ dès que deux intermédiaires
sont disponibles. En l’absence de chemin de longueur sept,
un tel $w$ doit éviter tous les voisins de $u$ hors
$\{b_1,b_2,y\}$ et a donc degré au plus $t$.

Pour contrôler la disponibilité de deux intermédiaires,
le déficit total de degrés à la référence $d$ dans
$A\setminus\{x\}$ est au plus $D=c+(a-1)d-E$. Si $s<t$,
au plus $L=\lfloor D/(d-t+1)\rfloor$ sommets de cet
ensemble ont un degré inférieur à $t$, pour $d\ge t$.
Si $s\ge t$, poser $L=0$. La condition $s-2-L\ge2$
suffit. Lorsqu’elle échoue, un second test permet de choisir
$u$ après $b_1$. Si $s\ge t-1$ et que $N(x)\setminus\{y\}$
contient un $b_1$ de degré au moins $L+4$, ce $b_1$
fournit deux intermédiaires pour tout $u$ de degré $d$.
Sinon chaque $b_1$ de cet ensemble a degré au plus $L+3$.
En présence d’au moins un sommet de degré inférieur à $t$,
le nombre de sommets de degré $d$ hors $x$ est au moins
$a-1-D+(d-t)$. Si ce nombre dépasse $L+3$, on peut prendre
$u$ non adjacent à $b_1$. Le seuil de degré pour les
intermédiaires descend alors à $t-1$, et tous les
intermédiaires conviennent. Sans sommet de degré inférieur
à $t$, les deux intermédiaires sont déjà disponibles.

Sous l’un de ces tests de disponibilité, l’absence d’un
chemin implique donc au moins $s-2$ sommets de degré au
plus $t$ dans $A\setminus\{x,u\}$. Si $t<s$, c’est
impossible. Sinon la somme des degrés dans $A$ est au
plus $c+(a-1)d-(s-2)\max(0,d-t)$. Quand le premier
test s’applique et que $t=s<d$, on affine. Tout choix de
$u$ de degré $d$ doit toucher $y$ et tous les
$b_1\in N(x)\setminus\{y\}$, faute de quoi un voisin
de plus de $u$ serait disponible et la borne pour $w$
tomberait à $s-1$. D’où $\deg(x)\le d$. Il ne peut y
avoir deux choix de $u$ de degré $d$, car chacun
appartiendrait à $N(y)$ et servirait de sommet $w$
pour l’autre choix. Le plafond de degrés devient alors
$2d+(a-2)(d-1)-(s-2)\max(0,d-1-s)$.
Le vérificateur essaie chaque valeur possible de $d$
dans les deux orientations du graphe.

### Premier passage biparti

Si $H_{n+1}$ est non biparti et $H_n$ biparti, le
sommet retiré doit toucher les deux parties de toute
bipartition choisie de $H_n$. Il n’a donc pas pu être
retiré à un degré inférieur à deux. Si le degré minimal
de $H_n$ vaut $s$, celui de $H_{n+1}$ est au plus $s+1$.
On résout l’inégalité entre le minorant d’arêtes résultant
et les plafonds bipartis, y compris celui obtenu en
retirant un sommet de degré $s$ de $H_n$. Si le test de
chemins donne la longueur sept pour toutes les paires
opposées, les deux attaches du sommet retiré ferment
un $C_9$.

Ce calcul exclut les premiers passages bipartis aux
ordres 26, 25, 24, 23 et 22 à partir d’un bloc d’ordre
31. À 21 sommets, il reste conditionnellement les tailles
$(8,13),(9,12),(10,11)$ avec degré minimal 3 et 88 à
89 arêtes. La branche où les retraits laissent encore
un graphe non biparti à 21 sommets reste également ouverte.
Pour les blocs d’ordres 32 et 33, un premier passage à
26 sommets impose un degré du dernier sommet retiré
d’au plus 6 et 8 respectivement.

## 2. Attaches des triangles à un noyau dans le reste

On fixe $q$ triangles sommet-disjoints en nombre maximum
et on note $J$ leur reste. Il est sans triangle.
Si $J$ contient un noyau, on en choisit un maximal par
inclusion dans $J$, de parties $A,C$ de tailles $a\le c$.
Il reste $s$ sommets de $J$ hors du noyau.

### Attaches au noyau et pertes entre triangles

Chaque triangle touche au plus une partie du noyau.
Deux attaches opposées portées par le même sommet du
triangle fermeraient un chemin de longueur sept.
Portées par deux sommets différents, elles fermeraient
un chemin de longueur cinq, en passant par deux
arêtes du triangle. Du même côté du noyau, deux
attaches à des labels distincts portées par deux sommets
différents du triangle fermeraient un chemin de
longueur six avec une arête du triangle. Ainsi les
attaches d’un triangle forment une étoile. Lorsqu’il y
en a au moins quatre, le centre est dans le triangle.
On note $x,y$ les nombres de ces grands attachements
respectivement vers $A,C$.

Entre deux triangles ayant de grands attachements du
même côté, la coupe est vide. Choisir des labels
distincts dans le noyau. Pour une arête entre les
centres, un chemin de longueur six ferme le cycle.
Dans les autres cas, un chemin de longueur quatre
laisse deux arêtes à parcourir à l’intérieur des
triangles. Si les triangles sont attachés de côtés
opposés, seule une arête entre leurs centres est
possible. Une arête avec un seul décalage donne un
$C_9$ via un chemin de longueur cinq et une arête
interne. Avec deux décalages, un chemin de longueur
trois donne un $C_9$ avec des passages internes de
longueurs un et deux.

Le déficit des coupes par rapport à deux arêtes par
paire augmente donc d’au moins
$2\binom{x}{2}+2\binom{y}{2}+xy$. Les sommets hors
centres de ces $x+y$ triangles n’ont pas de voisins
dans le noyau. Choisir un de ces sommets par triangle
et toute la partie $C$ donne un stable.
On a $c+x+y\le13$.

### Les sommets du reste hors du noyau

Un tel sommet touche au plus une partie. S’il touche
$A$ en au moins deux points et que chaque sommet de $C$
a un voisin dans son ensemble d’attaches, on peut
l’ajouter à la partie $C$ du noyau, en conservant tous
les chemins requis. Pour les chemins impairs vers
$A$, on préfixe une attache différente de l’arrivée à
un chemin pair du noyau. Vers $C$, le voisin commun
donne le chemin de longueur deux et on préfixe une
attache aux chemins de longueurs trois et cinq pour
obtenir quatre et six. La maximalité exclut donc ce
cas. Si $M$ arêtes manquent dans le noyau, chacune des
$u$ attaches de sommets extérieurs vers la partie $A$
désigne ici un sommet touchant $A$, avec au plus
$\max(1,\min(a-2,M))$ arêtes vers le noyau. En effet une
grande attache évite tout le voisinage d’un sommet de
$C$, qui a au moins deux voisins. On utilise la borne
symétrique pour les $v$ sommets touchant $C$.
Le budget d’arêtes du noyau et de ces attaches est
maximisé sur $0\le M\le c-2$. Au-delà, le gain
d’attaches est constant et le terme $-M$ décroît.

Un sommet qui touche le même côté du noyau qu’un
triangle à grand attachement n’a aucune arête vers ce
triangle. On peut choisir deux labels distincts dans
le noyau, puis fermer par un chemin de longueur six
si l’arête arrive au centre ou de longueur quatre
sinon. Si le sommet touche le côté opposé, seule
une arête vers le centre est possible, par le chemin
de longueur cinq et une arête interne si l’arrivée
est décalée. On obtient au plus
$$
3q(s-u-v)+3(q-x-y)(u+v)+yu+xv
$$
arêtes de ces $s$ sommets vers les triangles. On prend
le minimum avec le plafond par marques d’answer-23,
$q s+2\sum_i m_i$, où $m_i$ compte les triangles dans
lesquels le sommet $i$ a au moins deux voisins. Le
vérificateur maximise sur les vecteurs de marques,
en combinant le plafond des étoiles sur les unions
avec les plus grands comptes de marques et le déficit
de coupes. Les pertes par marques et par attache au
noyau sont combinées par maximum, pour éviter de
compter deux fois une même perte. Les arêtes entre
les $s$ sommets du reste sont au plus $\lfloor s^2/4\rfloor$.
Les coupes entre triangles utilisent la table entière
d’answer-22, issue d’answer-20. [Bornes sur les coupes](../triangle-packing-frontier-c9/C9-TRIANGLE-PACKING-FRONTIER.md)
et [budget des étoiles et des marques](../nine-triangles-c9/C9-NINE-TRIANGLES.md).

### Portée du calcul

| Ordre de $B$ | Plus grand noyau encore permis dans le reste, selon $q=4,5,6,7,8$ |
|---:|:---|
| 31 | 14, 10, aucun, aucun, aucun |
| 32 | 16, 12, 9, aucun, aucun |
| 33 | 20, 14, 11, 8, aucun |

Un $K_{4,4}$ dans $J$ serait induit, puisque $J$ est
sans triangle. C’est un noyau. Les entrées « aucun »
l’excluent également. À $q=8$, cela exclut les
graphes restants contenant $K_{4,4}$, tandis que des
graphes sans un tel noyau restent à traiter.
Les ordres candidats 31, 32 et 33 demeurent ouverts,
ainsi que le cas général de $C_9$.

## Rejeu

Depuis le dossier de ce document dans le ZIP extrait

~~~sh
python3 -B verify-order31-and-core-contacts.py | cmp - order31-and-core-contacts-certificate.json
~~~
