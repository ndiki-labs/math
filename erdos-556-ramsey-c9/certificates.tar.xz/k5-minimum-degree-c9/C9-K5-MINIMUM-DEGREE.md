# Fermeture du K₅ dans la réduction héréditaire

Soit $H$ un contre-exemple d’ordre minimal à la borne d’answer-47,
d’ordre $23\le n\le33$. Il est sans $C_9$ ni $K_6$, de degré
minimal au moins 8, et vérifie $e(H)\ge7n-55$. On montre qu’il
est sans $K_5$.

## Arêtes incidentes à un ensemble

Pour $1\le|S|\le n-17$, la minimalité donne
$e(H-S)\le7(n-|S|)-56$. Par soustraction,
$$e(S)+e(S,H-S)\ge7|S|+1.$$
Pour $|S|=n-16$, la borne 57 à l’ordre 16 donne $7|S|$.
Les coupes pour un $K_5$, un $K_4$ et un $K_3$ sont donc au
moins 26, 23 et 19, respectivement. Si $|S|=8$, le minimum
incident est 57 aux ordres 25 à 33 et 56 à l’ordre 24.
À l’ordre 23, on applique la borne à sept des huit sommets,
ce qui garantit au moins 49 arêtes incidentes à $S$.

## Un K₅ impose une oreille de longueur 4

Fixons $Q=K_5$ et écrivons $R=H-Q$, $r=|R|\le28$.
Les attaches d’un sommet de $R$ sont ses voisins dans $Q$.
Il a au plus quatre attaches, car $H$ est sans $K_6$.
Un chemin simple de longueur $\ell$ dans $R$ entre deux
sommets qui peuvent choisir des attaches distinctes forme
une oreille de longueur $\ell+2$. Les oreilles de longueurs
5 à 8 sont interdites, car elles se ferment par un chemin
complémentaire dans $Q$.

Supposons qu’il n’y ait aucune oreille de longueur 4.
Les chemins de longueurs 2 à 6 dans $R$ sont alors tous
interdits entre deux sommets qui peuvent choisir des
attaches distinctes. Notons $D$ les sommets à au moins
deux attaches et $Z$ ceux sans attache.

Pour chaque $x\in D$, choisissons un voisin $y_x$ dans $R-D$.
Ce choix est possible car $x$ a au moins quatre voisins
dans $R$ et au plus un dans $D$. Deux voisins dans $D$
donneraient un chemin interdit de longueur deux. Tous
les voisins dans $R$ de $y_x$ autres que $x$ sont dans $Z$,
car tout sommet attaché permet un choix distinct d’une
des attaches de $x$. Ainsi $y_x$ fournit au moins six
sommets de $Z$. Pour deux sommets de $D$ distincts, les
$y_x$ sont distincts, et ces ensembles de sommets de $Z$
sont disjoints. Sinon on trouverait un chemin de longueur
deux ou quatre entre les deux sommets de $D$.
Par suite $|Z|\ge6|D|$, et
$$26\le e(Q,R)\le r-|Z|+3|D|\le r-3|D|.$$
Comme $r\le28$, il faut $D=\varnothing$ et $|Z|\le2$.

Les cinq groupes de simples attaches sont non vides, par le
degré des sommets de $Q$. Une arête entre deux groupes
forcerait chaque voisin attaché de chacune de ses extrémités
à être du groupe opposé, par l’interdiction de longueur 2.
Cette règle se propage dans la composante des sommets
attachés qui contient l’arête. Elle est bipartie entre
ces deux groupes. Un chemin de longueur trois dans la
composante serait interdit, donc c’est une étoile.
Une de ses feuilles aurait au plus $1+|Z|\le3$ voisins
dans $R$, alors qu’il lui en faut au moins sept.

Il n’y a donc aucune arête entre groupes. Un sommet de $Z$
ne peut pas non plus toucher deux groupes, par l’interdiction
de longueur 2. Chaque groupe, réuni aux sommets de $Z$ qui
le touchent, contient au moins huit sommets pour offrir
sept voisins à ses sommets attachés. Ces cinq ensembles
sont disjoints, d’où $r\ge40$. Cette contradiction impose
une oreille de longueur 4.

## Noyau à huit sommets

Posons $S=Q\cup\{u,v,w\}$ où l’oreille est $a-u-v-w-b$
avec $a,b\in Q$. On ordonne $u,v,w$. Chaque sommet de $Q$
a un profil d’attaches dans ces trois sommets. Les cinq
profils forment un multiensemble de masques de trois bits.
On parcourt leurs listes triées, ce qui quotient par les
permutations de $Q$. On conserve les deux arêtes $uv,vw$,
teste l’absence ou la présence de $uw$, impose au plus
quatre voisins dans $Q$ à chacun de $u,v,w$, et exige que
$u,w$ puissent choisir deux attaches distinctes. Cela
donne 1 094 noyaux sur huit sommets. On calcule toutes les
longueurs de chemins simples entre deux labels de $S$,
par le vérificateur des oreilles d’answer-10 et par une
seconde méthode à sous-ensembles.

Soit $W=H-S$ et $h=|W|\le25$. Le profil d’un sommet de $W$
est un sous-ensemble de $S$. Deux labels d’un même profil
ne peuvent pas être reliés par un chemin de longueur 7
dans $S$. Plus généralement, pour deux sommets de $W$
reliés par un chemin simple de longueur $d$ dans $W$,
aucune paire de leurs labels distincts ne peut être
reliée par un chemin de longueur $7-d$ dans $S$.

Dans 815 noyaux, tous les profils extérieurs ont taille au
plus un. Alors $e(S)+e(S,W)\le25+h$, sous le minimum à
chaque ordre.

Pour un label $i$, notons $m_i$ la taille du plus grand
profil permis qui le contient. Il existe un sommet de $W$
qui voit $i$, car $|S|=8$ et $\delta(H)\ge8$. La réunion
des sommets de $W$ qui voient $i$ et de leurs voisins dans
$W$ a taille au moins $9-m_i$. Si deux labels de $S$ sont
reliés par chacun des chemins de longueurs 5, 6 et 7,
ces réunions sont disjointes. En effet, une intersection
donnerait une double attache sur un même sommet ou un
chemin extérieur de longueur 1 ou 2. Pour chaque noyau,
on maximise la somme des $9-m_i$ sur un ensemble de
labels deux à deux reliés aux trois longueurs. Le
plafond $h\le25$ écarte ainsi 278 noyaux.

## Dernier noyau

Le seul noyau restant contient exactement les dix arêtes
de $Q$ et les quatre arêtes de l’oreille $a-u-v-w-b$.
Distinguons les profils exactement égaux à $\{a,b\}$,
de nombre $b_0$, et les autres profils multiples, de
nombre $g$. Le calcul des chemins donne les faits
suivants, y compris pour les paires de profils égaux.

- Les profils ont taille au plus trois. Tout profil
  contient au plus deux labels de $S\setminus\{a,b\}$.
- Aucun profil multiple autre que $\{a,b\}$ ne peut être
  relié à un profil non vide par un chemin extérieur de
  longueur deux. Il ne peut pas non plus être adjacent à
  un profil $\{a,b\}$.
- Deux profils multiples quelconques ne peuvent pas être
  reliés par un chemin extérieur de longueur quatre.

Un sommet portant un profil multiple autre que $\{a,b\}$
a donc au plus un voisin de profil multiple. Il a au
moins cinq voisins dans $W$, donc on peut choisir un
voisin de profil vide ou simple. Ce voisin fournit au
moins six voisins de profil vide autres que le sommet
initial. Comme dans le comptage sur $R$, ces ensembles
sont disjoints pour les $g$ sommets, par les interdictions
de chemins de longueurs deux et quatre. Il y a au moins
$6g$ profils vides et
$$e(S,W)\le h+b_0+2g-6g\le h+b_0.$$

Les trois sommets de $Q\setminus\{a,b\}$ ont chacun besoin
d’au moins quatre voisins dans $W$. Les sommets $u,v,w$
en ont chacun besoin d’au moins six. Au total, ces six
labels reçoivent au moins 30 attaches. Les $b_0$ profils
$\{a,b\}$ n’y contribuent pas et tous les autres profils
y contribuent au plus deux fois. On a donc $b_0\le h-15$
et $e(S,W)\le2h-15$. Avec $e(S)=14$, cette borne est
strictement sous le minimum incident pour chacun des
ordres 23 à 33.

## Portée et rejeu

Le nombre de clique d’un contre-exemple minimal est donc
3 ou 4, puisqu’answer-48 impose déjà un triangle. Le cas
général de $R_3(C_9)=33$ reste ouvert. L’exclusion du $K_5$
porte sur le contre-exemple minimal à la borne ascendante.

Le vérificateur rejoue les spectres de chemins, la
classification des 1 094 noyaux et les bornes entières
à chaque ordre. Depuis ce dossier dans le ZIP extrait,
avec Python 3.

```sh
python3 -B verify-k5-minimum-degree.py | cmp - k5-minimum-degree-certificate.json
```
