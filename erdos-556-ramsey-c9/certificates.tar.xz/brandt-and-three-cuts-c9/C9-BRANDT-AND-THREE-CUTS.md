# Exclusion de l’ordre 25 et coupes entre trois triangles

Soit $B$ le plus grand bloc dans la
[réduction monochrome](../mono-extremal/C9-MONO-EXTREMAL.md).
Le bloc est 2-connexe, non biparti et sans $C_9$. Il
satisfait $\alpha(B)\le13$, $\omega(B)\le5$ et
$e(B)\ge m_b=176-\operatorname{ex}(34-b,C_9)$, où $b=|B|$.
Sa circonférence est au moins 14 par
[answer-8](../odd-block-c9/C9-ODD-BLOCK.md).

## 1. Brandt et le degré minimal

Le théorème de Brandt de 1997 s’applique à un graphe non
biparti d’ordre $n$ ayant strictement plus de
$(n-1)^2/4+1$ arêtes. Il contient alors tous les cycles
de longueur de 3 jusqu’à sa circonférence. Pour $b=25$,
le seuil strict est 145 alors que $e(B)\ge147$. La
circonférence est au moins 16 à cet ordre. Le bloc
contient donc un $C_9$, ce qui exclut **tout l’ordre 25**.
[Article de Brandt](https://doi.org/10.1016/S0166-218X(97)00032-2)

Brandt, Faudree et Goddard montrent qu’un graphe non
biparti d’ordre $n$ et de degré minimal au moins
$(n+2)/3$ contient tous les cycles entre sa maille et
sa circonférence, avec maille 3 ou 4. On en déduit
$\delta(B)\le\lfloor(b+1)/3\rfloor$. Les plafonds sont
9 pour $26\le b\le28$, 10 pour $29\le b\le31$ et 11
pour $32\le b\le33$.
[Théorème 1.7 dans le manuscrit des auteurs](https://people.computing.clemson.edu/~goddard/papers/weakpanFinal.pdf#page=5)

### Taille des cœurs aux ordres 26 à 29

Answer-8 donne un $d$-cœur non vide avec $d=9$ aux
ordres 26 à 28 et $d=8$ à l’ordre 29. Chaque composante
de ce cœur a degré minimal au moins $d$. Une composante
bipartie induite aurait chaque partie de taille au plus
13 et tout couple d’une même partie aurait au moins
$2d-13\ge3$ voisins communs. C’est un noyau au sens
d’[answer-17](../packing-bridges-c9/C9-PACKING-BRIDGES.md),
comme le montrent les constructions suivantes.

- Pour les chemins de longueur 2, 4 ou 6 entre
  extrémités d’une même partie, on choisit les sommets
  internes de ce côté, puis jusqu’à trois voisins communs
  distincts pour les couples successifs.
- Pour un chemin de longueur 3 ou 5 de $x$ à $y$,
  dans des parties opposées, on choisit un dernier
  voisin de $y$ distinct de $x$. Deux voisins communs
  par couple du même côté restent disponibles après
  exclusion de $y$.
- Pour la longueur 7, si $y$ manque un voisin $w$ de
  l’autre partie, on place $w$ parmi les quatre sommets
  de cette partie, dans la suite qui démarre en $x$ et
  s’achève chez un voisin de $y$. Si $w=x$, il est déjà
  placé. Au moins un des trois couples successifs a
  trois voisins communs autres que $y$, et les deux
  autres en ont au moins deux. Hall permet d’en
  prendre trois distincts. Si $y$ voit toute la partie,
  on choisit les deux premiers voisins communs hors
  $y$, puis un troisième voisin du dernier sommet de
  la suite déjà construite, hors $y$ et hors des deux
  premiers voisins communs. Ce troisième voisin a
  au moins huit voisins parmi lesquels on prend le
  dernier sommet avant $y$ en évitant ceux déjà utilisés.

Chaque composante du $d$-cœur est donc non bipartie par
answer-17. Elle a une circonférence au moins $d+1$, en
fermant un plus long chemin par l’arête entre sa première
extrémité et son voisin le plus éloigné sur ce chemin.
Comme $d\ge8$, le théorème de degré minimal exclut les
composantes d’ordre au plus $3d-2$. On obtient un unique
$9$-cœur d’ordre au moins 26 aux ordres 26 à 28, et
un unique $8$-cœur d’ordre au moins 23 à l’ordre 29.
En particulier, un bloc candidat à l’ordre 26 aurait
$\delta(B)=9$.

## 2. Deux coupes successives sur trois triangles

Prenons des triangles disjoints $T_1,T_2,T_3$ et des
coupes successives de tailles $x,y\ge4$. Par
[answer-18](../mixed-cuts-c9/C9-MIXED-CUTS.md), une
coupe de taille au moins sept ne peut pas partager
un triangle avec une autre coupe d’au moins quatre.
Il reste donc $4\le x,y\le6$.

Après avoir fixé les trois triangles, le contrôle
parcourt les $\binom9x\binom9y$ choix étiquetés des
deux coupes. Il cherche d’abord un cycle hamiltonien
sur les neuf sommets avec coupe $T_1,T_3$ vide.
Sur chaque survivant, les deux coupes atteignent
exactement les **deux mêmes sommets** de $T_2$.
On essaie ensuite les neuf fermetures par une
arête. S’il y a plusieurs arêtes individuellement
possibles, on essaye toutes leurs paires. Toute
fermeture plus grande contiendrait une de ces paires.

| Coupes successives | Choix sans $C_9$ avant fermeture | Fermetures par une arête sans $C_9$ |
| --- | ---: | ---: |
| $4,4$ | 675 | 54 |
| $4,5$ | 270 | 0 |
| $4,6$ | 45 | 0 |
| $5,5$ | 108 | 0 |
| $5,6$ | 18 | 0 |
| $6,6$ | 3 | 0 |

Il n’y a jamais deux arêtes de fermeture. Même dans
le cas $4,4$, la fermeture est vide dès qu’une des
coupes successives contient un $K_{2,2}$. Le certificat
contient un exemple qui permet une arête. Les masques
binaires des coupes $12,23,13$ sont respectivement
$75,15,1$, avec le bit $3i+j$ pour l’arête de la
ligne $i$ vers la colonne $j$ et des indices de 0 à 2.

### Aucune chaîne de trois coupes d’au moins quatre arêtes

Construisons le graphe réduit qui relie deux triangles
si leur coupe a au moins quatre arêtes. Il n’a pas de
triangle par answer-12. Supposons qu’il ait un chemin
$T_1,T_2,T_3,T_4$ sur quatre triangles distincts.
La coupe $T_2,T_3$ n’utilise que les deux labels
imposés à chacune de ses extrémités par le contrôle
précédent. Avec au moins quatre arêtes, c’est un
$K_{2,2}$.

Dans $T_1$, on relie les deux labels de $T_2$
par un détour de longueur 3. Il suffit de deux
arêtes de la coupe à extrémités distinctes et d’une
arête de $T_1$. Un couplage de taille deux existe
car la coupe comporte au moins quatre arêtes.
De l’autre côté, on relie les deux labels de $T_3$
par un détour de longueur 4 traversant $T_4$.
Deux arêtes du $K_{2,2}$ relient ces deux détours
en un cycle de longueur $3+4+2=9$. Ainsi, chaque
composante du graphe réduit est une étoile, en
comptant aussi les arêtes isolées et les sommets
isolés.

## 3. Arêtes entre les composantes d’étoiles

Une composante à deux triangles possède deux
propriétés vérifiées sur toutes les coupes de
tailles 4 à 8. Chaque paire de sommets est reliée
par un chemin de longueur 3 ou 4. Les paires
auxquelles manque l’une de ces longueurs forment
ensemble un couplage sur les six sommets. Deux
paires différentes de cette liste sont donc
disjointes.

Dans une composante à $s\ge3$ triangles, tout
couple de sommets est relié par un chemin de
longueur 4. Pour le voir, on choisit trois triangles
comprenant le centre et deux feuilles ainsi que
les deux extrémités voulues. Le contrôle sur
trois triangles garantit le chemin. Il établit
aussi que si une paire n’a pas de chemin de
longueur 3, ses deux extrémités sont dans des
feuilles distinctes et n’ont pas d’attache au
triangle central. Il y a au plus un sommet de
ce type par feuille. Notons $Z$ leur ensemble,
de taille au plus $s-1$.

Deux arêtes disjointes entre deux composantes
formeraient un $C_9$ avec des chemins internes
de longueurs 3 et 4 dans un ordre ou dans
l’autre. On en déduit les plafonds suivants.

- Entre deux composantes à deux triangles,
  si un couplage de taille deux existe dans
  la coupe, ses deux paires d’extrémités ne
  peuvent manquer que la même longueur, 3
  ou 4. Toute nouvelle arête hors du rectangle
  $2$ par $2$ de ces extrémités est disjointe
  de l’une des deux arêtes du couplage. Dans
  au moins une composante, le nouveau couple
  partage un sommet avec une paire
  exceptionnelle sans lui être égal. Il
  possède donc les deux longueurs et donne
  le $C_9$. La coupe a au plus quatre arêtes
  si elle a un couplage de taille deux, et
  au plus six si elle est en étoile.
- Entre une composante à deux triangles
  et une de taille $s\ge3$, tout couplage
  de taille deux impose une paire sans
  longueur 3 du côté à deux triangles et
  deux sommets de $Z$ de l’autre côté.
  Une arête hors du rectangle ainsi fixé
  du petit côté, ou hors de $Z$ du grand côté,
  donne un $C_9$ avec une arête du couplage,
  par le même raisonnement. La coupe a donc
  au plus $\max(6,3s,2(s-1))=3s$ arêtes.
- Entre deux composantes de tailles $s,t\ge3$,
  tout couplage de taille deux exige que
  ses deux paires n’aient pas de chemin
  de longueur 3. Toutes les arêtes doivent
  alors joindre les ensembles $Z$ des deux
  composantes. Sinon une arête extérieure à
  ce produit est disjointe d’une des deux
  arêtes du couplage et rétablit un chemin
  de longueur 3. On obtient le plafond
  $\max(3s,3t,(s-1)(t-1))$.

À l’intérieur d’une étoile à $d\ge2$ feuilles,
aucune de ses coupes ne dépasse six arêtes.
Si $u$ de ces coupes ont au moins cinq arêtes,
les seules paires de feuilles susceptibles
d’être reliées sont parmi les $d-u$ autres
feuilles, à raison d’au plus une arête.
Le total des arêtes entre triangles de cette
composante est donc au plus
$6u+4(d-u)+\binom{d-u}{2}$. Par convexité, on
prend le maximum de $6d$ et $4d+\binom d2$.
Dans une composante à deux triangles, le
plafond est huit, par $\omega(B)\le5$.

Pour les paires de triangles dont au moins un
est isolé dans le graphe réduit, la coupe a
au plus trois arêtes. Cette borne inclut les
coupes non étoilées à trois arêtes. On combine
le majorant par composantes avec un décompte
qui distingue ces coupes des étoiles saturées.

Notons $h$ le nombre de coupes d’au moins quatre
arêtes, $i$ le nombre parmi elles de tailles
sept ou huit, $r$ le nombre de coupes riches au
sens d’answer-12, donc d’au moins trois arêtes
et non étoilées, et $N=\binom q2$. Deux coupes
riches successives imposent une coupe de
fermeture d’au plus deux arêtes par
[answer-18](../mixed-cuts-c9/C9-MIXED-CUTS.md).
Leurs paires d’extrémités sont distinctes car
le graphe riche ne contient pas de $C_4$.
Il y en a au moins $D(q,r)$, obtenu en équilibrant
les degrés entiers de somme $2r$. Les coupes
de trois arêtes sont soit riches, au nombre
de $r-h$, soit des étoiles saturées, au nombre
d’au plus $\lfloor q^2/3\rfloor$ par answer-17
et Turán. Ainsi le total d’arêtes entre triangles
est au plus
$$
2N+4h+2i+\min\{\lfloor q^2/3\rfloor+r-h,\ N-h-D(q,r)\}.
$$
Pour chaque partition en ordres de composantes,
on fixe $h$ et on parcourt $i$ et $r$.
On prend le plus petit des deux majorants.
Le plafond de $r$ est donné par les nombres de
Garnick, Kwong et Lazebnik pour les graphes
sans $C_3$ ni $C_4$.
[Table du théorème 3.1](https://bpb-us-w2.wpmucdn.com/sites.udel.edu/dist/3/7714/files/2022/02/ex34a_v2.pdf#page=4)

On obtient les plafonds de coupes
$35,50,67,88,112,139,168$ pour $q=5,\ldots,11$.
Le décompte d’answer-18 omettait la contribution
possible des coupes non étoilées à trois arêtes
dans son plafond de 222 pour onze triangles.
Le même calcul révisé avec le terme $r-h$
donne 223. L’argument par composantes ci-dessus
ramène le plafond à 201. Les résultats
d’answer-18 aux petits ordres avec $q=1$ sont
indépendants de ce terme.

## 4. Un sommet extérieur et des triangles entièrement vus

Pour $b=28,q=9$, soit $v$ le seul sommet
hors des triangles. Appelons entier un triangle
dont $v$ voit les trois sommets. Si $v$ voit
entièrement $t$ triangles, il a au plus $2q+t$
voisins. Le plafond $112$ sur les coupes
impose $t\ge161-27-18-112=4$. Le sommet $v$
a au moins 22 voisins et manque donc au
plus cinq des 27 sommets des triangles.

Une chaîne de deux coupes non vides sur trois
triangles entiers ne peut pas utiliser deux
labels distincts sur son triangle médian.
Sinon, on traverse les deux triangles
extrêmes par des chemins de longueur 2, le
triangle médian par une arête, et les deux
coupes par une arête chacune. Ce chemin
sur huit sommets se ferme en $C_9$ via $v$.

Dans le graphe des coupes non vides entre
triangles entiers, tout triangle de degré
au moins deux utilise donc un seul label
pour toutes ces coupes. Après avoir extrait
les $p$ composantes qui sont des arêtes
isolées, les $\ell$ feuilles restantes
contribuent au plus $3\ell$ et les autres
coupes au plus $\binom{t-2p-\ell}{2}$.
Les arêtes isolées apportent au plus $8p$.
Pour les autres coupes de la famille
entière de neuf triangles, on prend la
borne brute de trois par paire et on ajoute
un supplément pour les coupes d’au moins
quatre. Si $i$ coupes ont sept ou huit
arêtes, elles sont isolées parmi les
coupes d’au moins quatre. Sur les $q-2i$
triangles restants, le graphe de ces
coupes est une forêt, donnant au plus
$5i+3\max(0,q-2i-1)$ arêtes de
supplément.

On retranche aussi des coupes nécessairement
vides dans le majorant par composantes. Soient
$D$ une composante qui relie toute paire de
sommets par un chemin de longueur 4, et $T$
un triangle isolé du graphe réduit. Si $v$
voit au moins deux sommets de chacun, toute
arête de $D$ à $T$ permettrait de relier deux
voisins de $v$ par un chemin simple de longueur 7.
On prend les extrémités distinctes des deux
bouts de cette arête, puis un chemin de
longueur 4 dans $D$, l’arête de coupe et un
chemin de longueur 2 dans $T$. Avec $v$ cela
donne un $C_9$.

Toute composante d’au moins trois triangles
a la propriété de chemins voulue et contient
au moins quatre voisins de $v$. Une composante
de deux triangles reliés par sept ou huit
arêtes a aussi ces chemins, par le contrôle
sur six sommets. Quand $t\le6$, elle contient
au moins deux voisins de $v$. Sinon au moins
cinq sommets manqueraient dans cette seule
composante et les sept autres triangles
seraient vus entièrement. Au plus deux
triangles isolés peuvent être vus par $v$
sur un sommet ou zéro, puisqu’ils coûtent
chacun au moins deux des cinq absences.
Pour chaque partition, on retranche les
coupes vers les autres triangles isolés
pour une composante éligible de taille
maximale. En maximisant sur $t=4,\dots,9$,
on obtient $e(B)\le159<161$.

## 5. Bilan exact

Pour chaque ordre et taille de famille, on
ajoute aux plafonds des coupes les $3q$ arêtes
internes, les attaches au reste et la borne
sur le reste sans triangle. À $b=25$, Brandt
exclut tous les cas. Les nouveaux plafonds
excluent aussi $(b,q)=(27,9),(28,9),(30,10)$,
avec respectivement 139, 159 et 169 arêtes.
À $(33,11)$ le plafond corrigé passe de 223 à 201,
au-dessus du seuil de 176. Sur les 48 couples
de paramètres précédemment ouverts avec
$q\ge5$, il en reste 41 dans ce contrôle.
Le cas général de $C_9$ et le stable de taille
13 restent ouverts.

## Rejeu

Depuis le dossier de ce document après
extraction du ZIP, lancer

~~~sh
python3 -B verify-three-cuts.py | cmp - three-cuts-certificate.json
~~~

Le rejeu traite les graphes étiquetés par
parcours de chemins simples et fait les
comparaisons en arithmétique entière.
