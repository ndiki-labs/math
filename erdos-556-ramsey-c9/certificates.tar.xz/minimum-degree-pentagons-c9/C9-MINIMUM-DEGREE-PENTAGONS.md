# Exclusion de la maille impaire 5 sous un degré minimal de 8

Soit $G$ un graphe d’ordre $24\le n\le33$, sans $C_3$ ni $C_9$,
d’indépendance au plus 12, sans $K_{4,4}$ induit, avec
$\delta(G)\ge8$. On démontre qu’il ne contient aucun pentagone.
Les contraintes d’indépendance et de biclique sont celles
d’answer-33 et d’answer-35. La preuve applique les tables
d’answer-9 et la géométrie d’answer-8, avec le degré minimal
d’answer-47.

## Deux pentagones disjoints

S’il existe deux pentagones disjoints, on choisit une paire qui
maximise le nombre $w$ d’arêtes entre eux. Le catalogue des coupes
d’[answer-9](../pentagon-layers-c9/C9-PENTAGON-LAYERS.md) donne
$0\le w\le5$. Un sommet extérieur a au plus 2 attaches pour
$w\in\{0,3,4,5\}$, et au plus 3 pour $w\in\{1,2\}$. L’échange
du milieu d’un arc de longueur deux avec un sommet doublement
attaché est permis par la maximalité de $w$. Le vérificateur
rejoue les 651 coupes étiquetées et les tests des profils issus
de cet échange.

Posons $R$ le reste, $r=n-10$, et $D\subseteq R$ l’ensemble
des sommets ayant exactement trois attaches. Pour $w=1$ ou 2,
les extrémités de deux profils de $D$ partagent un voisin dans
la paire ou ont des voisins reliés par un chemin de longueur 6
dans la paire. Une arête dans $D$ donnerait donc un triangle
ou un $C_9$. Les profils ont aussi toujours des voisins reliés
par un chemin de longueur 3 dans la paire. Ainsi deux sommets
distincts de $D$ ne peuvent être reliés par un chemin de longueur
4 dans $R$. Ces propriétés couvrent aussi deux profils identiques.

Chaque sommet de $D$ a au moins cinq voisins dans $Z=R-D$.
Pour $z\in Z$ tel que $d_D(z)>0$, répartissons une unité
entre ses voisins dans $D$. Si un sommet $v\in D$ touche un $z$
avec $d_D(z)\ge3$, tous ses autres voisins $z'\in Z$ ont
$d_D(z')=1$. En effet, avec un autre voisin $u'\in D$ de $z'$,
on peut prendre un voisin $u\in D$ de $z$ distinct de $v,u'$,
ce qui donne le chemin $u-z-v-z'-u'$ interdit. Dans ce cas $v$
reçoit au moins quatre unités via ses autres voisins. Si tous
ses voisins ont $d_D\le2$, il reçoit au moins $5/2$. Par double
comptage, $|Z|\ge(5/2)|D|$, donc $|D|\le\lfloor2r/7\rfloor$.

La coupe vers $R$ doit avoir au moins $60-2w$ arêtes. Les
dix sommets de la paire ont un degré total d’au moins 80 et
les arêtes internes contribuent $2(10+w)$. Son plafond est
$2r+\lfloor2r/7\rfloor$ pour $w=1,2$ et $2r$ sinon.
À $r=23$, ces plafonds valent 52 et 46, sous les seuils
respectifs d’au moins 56 et 50. Les plafonds diminuent
pour les plus petits ordres. Deux pentagones disjoints
sont donc impossibles.

## Un pentagone et son reste

Fixons un pentagone $P$ et posons $R=G-V(P)$, $r=n-5\le28$.
Tout sommet voit au plus deux sommets de $P$, car son voisinage
sur $P$ est stable. Donc $\delta(R)\ge6$. Le graphe $R$ est
sans $C_3,C_5,C_9$. Le $C_5$ est exclu par l’étape précédente.

Supposons $R$ non biparti. Son plus court cycle impair $C$ est
induit. Si sa longueur $g$ est au moins 7, deux voisins d’un
sommet extérieur dans $C$ sont à distance circulaire 2. Sinon
l’arc impair donnerait un cycle impair plus court. Aucune
triple marque ne satisfait cette distance pour chaque paire.
Ainsi $g\delta(R)\le2r$. Cette inégalité exclut $g\ge11$.

Pour $g=7$, on réutilise les classes $D,S,Z$ d’answer-8 pour
les sommets ayant deux, un ou zéro voisins sur $C$. Un sommet
de $D$ évite $D\cup S$, et un sommet de $Z$ touche au plus un
sommet de $D$. Les deux labels d’un sommet de $D$, que l’on peut
fixer à $0,2$, n’ont aucune étiquette compatible commune pour
un chemin extérieur de longueur 1 ou 2. Les ensembles pour
la longueur 2 sont $\{0,3,4\}$ et $\{2,5,6\}$. Si un sommet
de $Z$ voyait deux sommets de $D$, il fournirait précisément
un chemin de longueur 2. Écrivons $d,s,z$ pour les effectifs.
Le degré dans $R$ d’un sommet de $D$ impose $z\ge4d$.
Le degré des sommets de $C$ impose $2d+s\ge28$. Or
$$2d+s=r-7+d-z\le r-7-3d\le21.$$
Cette contradiction force $R$ à être biparti.

## Le reste biparti

Les deux côtés de $R$ ont au plus 12 sommets. En particulier
$r\le24$. Montrons que deux sommets distincts $x,y$ d’un même
côté sont reliés dans $R$ par un chemin de longueur 4.

Notons $A$ leur côté, $B$ l’autre et $U=N_R(x),V=N_R(y)$.
Supposons le chemin absent.

- Si $U\cap V=\varnothing$, alors $|U|=|V|=6$ et $U\cup V=B$.
  Aucun sommet de $A$ ne touche les deux ensembles. Au moins
  six sommets de $A$ touchent $U$, et au moins six touchent $V$,
  par degré minimum de leurs voisins dans $B$. Comme $|A|\le12$,
  cela force deux $K_{6,6}$, donc un $K_{4,4}$ induit.
- Si $c\in U\cap V$, un autre voisin $z\in A\setminus\{x,y\}$
  de $c$ ne peut avoir de second voisin dans $U\cup V$.
  Sinon ce second voisin et $c$ donneraient le chemin voulu.
  Dès lors $|B\setminus(U\cup V)|\ge5$, donc $|U\cup V|\le7$
  et $|U\cap V|\ge5$. Chacun des voisins communs exige au
  moins quatre tels sommets $z$, deux à deux disjoints selon
  $c$. Il faudrait alors $|A|\ge2+4\cdot5=22$.

Si deux sommets ont chacun deux attaches à $P$, ils ne peuvent
être reliés par un chemin extérieur de longueur 4. En effet,
leurs paires de labels contiennent deux labels à distance 2
sur $P$. L’arc de longueur 3 et les deux attaches fermeraient
ce chemin en $C_9$. Les deux doubles ne peuvent donc appartenir
au même côté du reste biparti. Il y a au plus deux doubles
en tout, et la coupe de $P$ vers $R$ a au plus $r+2\le26$
arêtes. Le degré minimal 8 en exige au moins $5(8-2)=30$.

## Portée et rejeu

La maille impaire 5 est exclue à chacun des ordres 24 à 33 dans
la classe ci-dessus. En combinant avec answer-47, un
contre-exemple minimal à la borne ascendante contient
nécessairement un triangle. Les nombres de clique 3, 4 et 5
restent à traiter. Le cas général de $R_3(C_9)=33$ reste ouvert.

Le programme rejoue les tables finies de coupes et d’attaches
de la preuve, les relations de longueur sur les cycles et
les comparaisons entières pour chacun des dix ordres. Le ZIP
contient les sources des vérificateurs dont il dépend.
Depuis ce dossier dans le ZIP extrait, avec Python 3.

```sh
python3 -B verify-minimum-degree-pentagons.py | cmp - minimum-degree-pentagons-certificate.json
```
