# Exclusion des noyaux laissant onze sommets à l’extérieur

Soit $B$ un bloc candidat de la
[réduction monochrome d’Erdős #556](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est 2-connexe, non biparti, sans $C_9$, et $\alpha(B)\le13$.
Son ordre $b$ est compris entre 25 et 33 et
$e(B)\ge m_b=176-\operatorname{ex}(34-b,C_9)$.

Supposons que $B$ contienne un noyau biparti induit $D$ laissant
onze sommets à l’extérieur. On conserve la condition sur les
chemins d’[answer-13](../star-cut-attachments-c9/C9-STAR-CUT-ATTACHMENTS.md).
Dans $D$, toute paire distincte de la même partie est reliée par
des chemins simples de longueurs $2,4,6$, et toute paire de
parties opposées l’est par des chemins simples de longueurs
$3,5,7$. Les parties ont donc chacune au moins quatre sommets.

Le résultat ci-dessous exclut ce cas aux neuf ordres. Combiné
à [answer-14](../exterior-ear-closure-c9/C9-EXTERIOR-EAR-CLOSURE.md),
il impose que tout noyau biparti induit répondant à cette
condition laisse au moins douze sommets à l’extérieur.

## 1. Une oreille minimale dans le bloc entier

Une oreille de $D$ est un chemin simple à extrémités distinctes
dans $D$ et dont les sommets intérieurs sont hors de $D$.
Sa parité est correcte quand elle est paire entre sommets d’une
même partie ou impaire entre sommets de parties opposées.

Le lemme d’answer-13 garantit l’existence d’une oreille de
parité incorrecte. Il utilise la 2-connexité et la
non-bipartition de $B$. Si une composante hors du noyau
contient un cycle impair, deux chemins disjoints de ce cycle
vers le noyau donnent deux oreilles de parités différentes.
Sinon chacune des composantes extérieures se colorie en
deux couleurs. Si une composante ne peut aligner ses couleurs
sur celles du noyau, deux attaches de labels distincts
produisent une oreille de parité incorrecte.

Choisissons une oreille de parité incorrecte de longueur
**minimale dans tout $B$**, notée
$$
P=(x=v_0,v_1,\ldots,v_{\ell-1},v_\ell=y).
$$
Une oreille de longueur au plus sept et de parité
incorrecte se complète en $C_9$ à l’aide d’un des chemins
du noyau. Ainsi $8\le\ell\le12$, la borne supérieure
venant des onze sommets hors de $D$.
Les ancres $x,y$ sont de côtés opposés si $\ell$ est paire
et du même côté si $\ell$ est impaire.

## 2. Contacts au noyau et sommets hors de l’oreille

Appelons label supplémentaire un sommet de $D$ distinct
de $x$ et $y$. Supposons qu’un sommet intérieur $v_i$ de
l’oreille touche un label supplémentaire $z$. Cette
attache et les deux segments de $P$ donnent des
oreilles vers $x$ et $y$ de longueurs $i+1$ et
$\ell-i+1$. Leur somme a la même parité que $\ell$,
donc les deux oreilles ne peuvent être simultanément
de parité correcte. En effet, la somme des deux
parités correctes serait la parité de la relation
de côtés entre $x$ et $y$, qui est opposée à celle
de $\ell$.

Pour $2\le i\le\ell-2$, les deux oreilles
seraient strictement plus courtes, ce qui est
impossible. Aux deux positions restantes, l’oreille
de longueur deux impose que le label supplémentaire
soit du même côté que l’ancre adjacente sur $P$.
Seuls $v_1$ et $v_{\ell-1}$ peuvent donc rencontrer
des labels supplémentaires, sur les côtés de $x$
et de $y$ respectivement.

Soit $w$ un sommet hors de $D\cup P$. Si $w$ touche
un label supplémentaire $z$ et est adjacent à $v_i$,
on obtient des oreilles vers $x,y$ de longueurs
$i+2$ et $\ell-i+2$. Pour $3\le i\le\ell-3$,
leur somme a encore la même parité que $\ell$ et les
deux sont plus courtes. Parmi $v_1,v_2$, la condition
de parité sur les longueurs trois et quatre en
laisse au plus un. Elle en laisse au plus un aussi
parmi $v_{\ell-2},v_{\ell-1}$. Ainsi $w$ a au plus
deux voisins intérieurs sur $P$. Tous ses voisins
dans $D$ sont dans une même partie, puisqu’une
attache à chaque côté ferait une oreille de
longueur deux et de parité incorrecte.

Pour des tailles de parties $a,c$, un sommet hors
de $D\cup P$ envoie donc au plus
$$
\max\{\ell+1,\max(a,c)+2\}
$$
arêtes vers $D\cup P$. Le premier terme couvre le cas
où les seuls contacts possibles dans $D$ sont les deux
ancres. Il y a $12-\ell$ sommets de ce type, qui peuvent
en outre porter au plus $\binom{12-\ell}{2}$ arêtes
entre eux.

## 3. Le graphe sur l’oreille et les deux ancres

Le programme énumère les graphes induits possibles sur
les positions $0,1,\ldots,\ell$, en gardant toutes les
arêtes de $P$ et en réservant l’éventuelle arête $xy$
pour le budget du noyau. Il écarte tout ajout qui
crée entre $x,y$ un chemin simple plus court de même
parité que $P$ et dont les sommets intérieurs sont
hors de $D$. La propriété interdite est monotone sous
ajout d’arêtes. Un ajout déjà incompatible avec
$P$ peut être écarté d’entrée et les autres sont
énumérés par inclusion et exclusion successives.

Les seuls sommets intérieurs qui peuvent rencontrer une
partie de $D$ sont ses voisins aux ancres et les sites de
contact supplémentaires parmi $v_1,v_{\ell-1}$, déterminés
en section 2. On calcule exactement l’indépendance du
graphe induit sur tous les autres sommets intérieurs,
séparément pour chaque partie. Un stable de taille $s$
ainsi obtenu s’ajoute à la partie entière. Chaque
partie doit donc avoir taille au plus $13-s$.

Pour chaque graphe compatible et chaque choix de tailles
$a+c=b-11$, on additionne les budgets d’arêtes. On note
$e_P$ le nombre d’arêtes du graphe sur l’oreille avec
ses ancres, sans compter $xy$.

- Si $\ell=8$, $xy$ est une arête manquante. Toute
  attache supplémentaire de $v_1$ force en outre
  une arête manquante vers $y$, par l’oreille de même
  longueur allant du nouveau label à $y$. Toute attache
  supplémentaire de $v_{\ell-1}$ force symétriquement
  une arête manquante vers $x$. Ces pertes sont
  distinctes et ne comptent pas $xy$. On borne donc
  le noyau, les arêtes de l’oreille et ces attaches
  supplémentaires par $ac+e_P-1$.
- Pour les longueurs $\ell\ge9$, on utilise $ac+e_P$
  plus le nombre de contacts supplémentaires possibles.
  Cela ajoute au plus $a+c-2$ quand les ancres sont
  opposées, ou $2(a-2)$ si elles sont dans la partie
  de taille $a$.

On ajoute dans les deux cas la contribution des sommets
hors de $D\cup P$ donnée à la section 2. On ne suppose
pas que toutes ces arêtes peuvent être réalisées ensemble.
Ce majorant suffit au seuil du problème.

Une autre conséquence de la minimalité est que toute
corde de $P$ joint deux positions de même parité. De
plus, les intervalles de deux cordes doivent se
chevaucher sans simplement se toucher. Sinon on pourrait
utiliser les deux raccourcis successivement et
raccourcir $P$ en conservant sa parité. Les intervalles
des cordes ont donc tous un intervalle commun dès
qu’il y a au moins une corde. Le vérificateur utilise
directement l’interdiction des chemins plus courts.

## 4. Comparaison exacte

| Longueur de l’oreille | Arêtes facultatives retenues au départ | Graphes exempts de raccourci de même parité |
| ---: | ---: | ---: |
| 8 | 15 | 216 |
| 9 | 20 | 864 |
| 10 | 24 | 1 296 |
| 11 | 30 | 5 184 |
| 12 | 35 | 7 776 |

| Ordre $b$ | Seuil $m_b$ | Majorant ou exclusion |
| ---: | ---: | ---: |
| 25 | 147 | 112 |
| 26 | 148 | 122 |
| 27 | 155 | 132 |
| 28 | 161 | 142 |
| 29 | 166 | 152 |
| 30 | 170 | 162 |
| 31 | 173 | 167 |
| 32 | 175 | Indépendance incompatible |
| 33 | 176 | Indépendance incompatible |

Les longueurs 8 à 12 donnent ainsi 15 336 graphes
sur l’oreille à contrôler. Les bornes sont sous les
seuils aux ordres 25 à 31. Aux deux derniers ordres,
aucune répartition des tailles des parties ne survit
au contrôle des stables.

## Rejeu

Depuis `eleven-exterior-c9` dans le ZIP extrait, exécuter
`python3 -B verify-eleven-exterior.py | cmp - eleven-exterior-certificate.json`.
Le vérificateur compile le calculateur sous
`c++` avec C++17, contrôle les positions d’attachement
en Python et compare le tableau aux seuils certifiés.
