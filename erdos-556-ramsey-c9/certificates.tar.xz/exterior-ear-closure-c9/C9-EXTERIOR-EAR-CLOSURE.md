# Clôture des douze placements et exclusion des grands noyaux bipartis

Soit $B$ un bloc candidat dans la
[réduction monochrome d’Erdős #556](../mono-extremal/C9-MONO-EXTREMAL.md).
Il est 2-connexe, sans $C_9$, non biparti, d’indépendance au plus
13 et d’ordre $25\le b\le33$. Il doit avoir au moins
$m_b=176-\operatorname{ex}(34-b,C_9)$ arêtes.

Soit $D$ un sous-graphe biparti induit de $B$. On suppose que
deux sommets distincts d’une même partie de $D$ sont reliés
dans $D$ par des chemins simples de chacune des longueurs
$2,4,6$, et que deux sommets de parties opposées sont reliés
par des chemins simples de chacune des longueurs $3,5,7$.
Cette condition est satisfaite si la taille de la plus
petite partie dépasse d’au moins quatre le nombre d’arêtes
manquantes entre les parties, comme dans
[answer-13](../star-cut-attachments-c9/C9-STAR-CUT-ATTACHMENTS.md).
On montre qu’un tel $D$ ne peut laisser au plus dix
sommets à l’extérieur.

Cela ferme les douze placements qui subsistaient avec deux
triangles et deux autres sommets hors de $D$. Après retrait
de 1, 2 ou 3 triangles disjoints, on peut désormais exclure
un tel noyau obtenu après retrait d’au plus 7, 4 ou 1 autres
sommets, respectivement. Le nombre de triangles n’est pas
utilisé dans l’exclusion générale.

## 1. Les douze placements d’une oreille de longueur huit

Une oreille de $D$ est un chemin dont les extrémités sont dans
$D$ et distinctes, et dont les sommets intérieurs sont hors
de $D$. Sa parité est incorrecte si elle est impaire du même
côté ou paire entre côtés opposés. Une oreille incorrecte de
longueur au plus sept formerait un $C_9$ avec un chemin dans
$D$. Entre parties opposées, une oreille de longueur huit
impose que ses extrémités $x,y$ soient non adjacentes.

Dans les douze placements de [answer-13](../star-cut-attachments-c9/C9-STAR-CUT-ATTACHMENTS.md),
on a huit sommets hors de $D$, dont sept sur une oreille de
longueur huit et un hors de l’oreille. Le vérificateur reprend
les arêtes de cette oreille et les arêtes des deux triangles.
Il contrôle les ajouts d’arêtes dans le graphe sur les huit
sommets extérieurs et $x,y$. Il écarte tout ajout qui fournit
un chemin simple de longueur $2,4$ ou $6$ entre $x,y$.
Pas plus de 20 arêtes peuvent subsister, même en gardant
simultanément tous les ajouts qui passent ce contrôle individuel.

Pour chaque sommet extérieur et chaque côté de $D$, le
vérificateur teste aussi une attache vers un sommet de $D$
distinct de $x,y$. Les seuls cas possibles sont le premier
sommet intérieur de l’oreille, vers le côté de $x$, et le
dernier sommet intérieur, vers le côté de $y$. En effet,
depuis chacun des autres sommets extérieurs, un chemin vers
$x$ ou $y$ complète la nouvelle attache en une oreille de
parité incorrecte et de longueur au plus sept. Les deux
cas possibles, eux, donnent une oreille de longueur huit vers
l’ancre opposée. Chaque arête d’attachement ainsi permise
force donc une arête manquante distincte dans $D$.
Les deux familles de pertes sont disjointes et n’incluent
pas la non-arête $xy$.

Par suite, avec $h=b-8$,
$$
e(B)\le \lfloor h^2/4\rfloor +20-1.
$$
Le terme $-1$ compte $xy$. Les autres attaches hors
des ancres sont compensées par leurs pertes respectives.
À $b=33$, la borne vaut 175, sous le seuil 176. Le même
calcul est strictement sous $m_b$ aux huit ordres précédents.
Ces douze placements sont donc exclus indépendamment
de l’énumération plus générale qui suit.

## 2. Énumération du graphe extérieur avec deux ancres

La 2-connexité et la non-bipartition garantissent au moins
une oreille de parité incorrecte, par le lemme d’answer-13.
Elle emploie au moins sept sommets extérieurs. Notons $r$
le nombre total de sommets extérieurs et $\ell$ la
longueur de l’oreille. On fixe son chemin sur les étiquettes
$0,1,\dots,\ell$, avec $x=0$ et $y=\ell$. Pour $\ell$
paire, les ancres sont de côtés opposés. Pour $\ell$
impaire, elles sont du même côté. Les autres sommets
extérieurs reçoivent les étiquettes $\ell+1,\dots,r+1$.

On énumère les arêtes du graphe $F$ induit par les
sommets extérieurs et les deux ancres, en réservant
l’arête $xy$ au comptage dans $D$. Chaque graphe doit
contenir le chemin retenu. Un ajout est rejeté dès qu’il
crée entre les ancres un chemin simple formant une oreille
de parité incorrecte de longueur au plus sept. Cette
interdiction est monotone sous ajout d’arêtes, donc le
rejet d’un ajout permet de rejeter toutes les extensions
qui le contiennent. On énumère tous les autres sous-ensembles.
Les chemins simples sont contrôlés en retirant à chaque
étape le sommet intérieur visité.

Pour chaque graphe $F$ retenu, voici les deux contrôles
appliqués à chaque choix des tailles des parties de $D$.

1. **Contacts et stables.** Pour chaque sommet extérieur $u$
   et chaque partie de $D$, on teste une arête vers un
   sommet de cette partie différent de $x,y$. Les chemins
   dans $F$ entre $u$ et une ancre, sans passer par l’autre,
   déterminent les longueurs d’oreille produites. Si l’une
   est courte et de parité incorrecte, ce contact est exclu.
   Les sommets extérieurs dont tous les contacts avec
   une partie sont exclus, y compris les contacts directs
   avec ses ancres, sont non adjacents à cette partie entière.
   On calcule exactement leur nombre d’indépendance dans
   $F$. Il ne peut dépasser 13 moins la taille de la partie.
2. **Arêtes payées par des pertes.** Un contact qui fournit une
   oreille de longueur huit vers une ancre du côté opposé
   force une arête manquante dans $D$. On utilise au plus
   un site extérieur par ancre pour cette compensation.
   À ce site, chaque arête d’attachement force une perte
   distincte. Les deux ancres donnent deux familles de
   pertes disjointes, puisque seules les étiquettes de $D$
   différentes des ancres sont ainsi comptées. Pour les
   autres sites, on borne les contacts possibles par le
   nombre de sommets de la partie hors des ancres.
   Le total est majoré par les arêtes du biparti complet
   correspondant, les arêtes de $F$ et ces contacts non
   compensés. Lorsque $\ell=8$, on retire en outre la
   non-arête $xy$ du budget du noyau.

Les contraintes utilisées sont nécessaires. Un graphe
extérieur retenu par l’énumération peut avoir d’autres
obstructions à un prolongement. Cela suffit pour une
borne supérieure et évite d’énumérer les arêtes du noyau.

Le contrôle entier traite les cas suivants.

| Sommets hors de $D$ | Longueur retenue | Graphes extérieurs retenus avant les contrôles d’indépendance et de budget |
| ---: | ---: | ---: |
| 7 | 8 | 216 |
| 8 | 8 | 9 896 |
| 8 | 9 | 864 |
| 9 | 8 | 724 252 |
| 9 | 9 | 44 584 |
| 9 | 10 | 131 304 |
| 10 | 11 | 577 856 |

## 3. Dix sommets extérieurs et une oreille plus courte

À $r=10$ et $8\le\ell\le10$, on retire un sommet $w$
hors de l’oreille et hors du noyau. Le graphe induit
de taille $b-1$ contient toujours le même noyau et la
même oreille. L’énumération de la section précédente
s’applique. Elle utilise une oreille donnée et ne
suppose pas que ce graphe induit soit 2-connexe. Le
programme inclut la taille 24 pour le cas $b=25$.

Si $w$ ne touche aucun label de $D$ autre que $x,y$,
son degré est au plus $2+9=11$. Sinon il touche un
label $z$ distinct des ancres. Tous les voisins de
$w$ dans $D$ sont du même côté, puisque deux attaches
de côtés opposés via $w$ donneraient une oreille de
longueur deux. Ils sont au plus 13. Un voisin sur
la position $i$ de l’oreille donne, avec l’attache
$wz$, deux chemins vers les ancres de longueurs
$i+2$ et $\ell-i+2$. Les longueurs de parité incorrecte
et trop courtes excluent certaines positions.
On ajoute les autres sommets hors de l’oreille,
au nombre de $10-\ell$ au plus. Pour les trois longueurs
$\ell$ et les deux côtés possibles de $z$, le vérificateur
trouve un degré d’au plus 18.

On obtient une borne pour $B$ en ajoutant 18 à la
borne de l’énumération à neuf sommets extérieurs.
Si aucune configuration n’est compatible avec
$\alpha\le13$ à la taille $b-1$, le cas est exclu
directement. Le cas $\ell=11$ est couvert par
l’énumération de la section 2.

## 4. Comparaison aux seuils

Les bornes ci-dessous maximisent sur les longueurs et
sur les tailles possibles des deux parties. Un tiret
signale que les contraintes d’indépendance excluent
tous les graphes extérieurs considérés.

| $b$ | Seuil $m_b$ | 7 extérieurs | 8 extérieurs | 9 extérieurs | 10 extérieurs |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 25 | 147 | 94 | 109 | 113 | 121 |
| 26 | 148 | 103 | 119 | 124 | 131 |
| 27 | 155 | 113 | 130 | 135 | 142 |
| 28 | 161 | – | 131 | 147 | 153 |
| 29 | 166 | – | – | 150 | 165 |
| 30 | 170 | – | – | – | 168 |
| 31 | 173 | – | – | – | – |
| 32 | 175 | – | – | – | – |
| 33 | 176 | – | – | – | – |

Un reste de taille au plus six est déjà exclu par
l’oreille de parité incorrecte. Tous les cas jusqu’à
dix sont donc exclus. La réduction ne garantit pas
encore qu’un bloc candidat possède un noyau biparti
du type considéré couvrant au moins $b-10$ sommets.
La question générale reste ouverte.

## Rejeu

Depuis `exterior-ear-closure-c9` dans le ZIP extrait, exécuter
`python3 -B verify-exterior-ear-closure.py | cmp - exterior-ear-closure-certificate.json`.
Le script demande un compilateur C++17 accessible sous
`c++`. Il compile dans un dossier temporaire, vérifie
les douze placements séparément en Python, puis rejoue
les 1 488 972 graphes extérieurs de la section 2 et les
comparaisons d’arêtes.
